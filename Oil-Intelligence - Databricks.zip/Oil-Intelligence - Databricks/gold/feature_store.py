# Databricks notebook source
# =============================================================================
# Notebook: 12_gold_feature_store.py
# Purpose : Join all Silver tables into a single flat feature matrix.
#           One row per trading day, 2017-2023. ~1,761 rows × 35 features.
# Runtime : ~5 minutes
# =============================================================================
# ── CELL 1 (UPDATED): Imports and paths ───────────────────────────────────

import builtins
from pyspark.sql import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import (
    col, lag, lead,                          # ← lead added
    avg, stddev, when, lit, coalesce,
    round as spark_round, min as spark_min,
    max as spark_max, year as spark_year,
    month as spark_month, isnull, count
)
from pyspark.sql.window import Window

spark = SparkSession.builder.getOrCreate()

VOL_BASE = "/Volumes/workspace/oil_intel/project_data"

SILVER_DATE_SPINE      = f"{VOL_BASE}/silver/date_spine"
SILVER_VESSEL_DAILY    = f"{VOL_BASE}/silver/ais_vessel_daily"
SILVER_LOITERING_DAILY = f"{VOL_BASE}/silver/ais_loitering_daily"
SILVER_GAPS_DAILY      = f"{VOL_BASE}/silver/ais_gaps_daily"
SILVER_MARKET_DAILY    = f"{VOL_BASE}/silver/market_daily"
SILVER_EIA_DAILY       = f"{VOL_BASE}/silver/eia_daily"
SILVER_MACRO_DAILY     = f"{VOL_BASE}/silver/macro_daily"
SILVER_OPEC_FLAGS      = f"{VOL_BASE}/silver/opec_flags"

GOLD_FEATURE_STORE     = f"{VOL_BASE}/gold/feature_store"
EXPORTS_DIR            = f"{VOL_BASE}/exports"

dbutils.fs.mkdirs(GOLD_FEATURE_STORE)
dbutils.fs.mkdirs(EXPORTS_DIR)

print("All paths configured.")
print(f"  Gold output : {GOLD_FEATURE_STORE}")

# COMMAND ----------

# ── CELL 2: Load all Silver tables ────────────────────────────────────────

print("Loading Silver tables...")

df_spine    = spark.read.format("delta").load(SILVER_DATE_SPINE)
df_vessel   = spark.read.format("delta").load(SILVER_VESSEL_DAILY)
df_loiter   = spark.read.format("delta").load(SILVER_LOITERING_DAILY)
df_gaps     = spark.read.format("delta").load(SILVER_GAPS_DAILY)
df_market   = spark.read.format("delta").load(SILVER_MARKET_DAILY)
df_eia      = spark.read.format("delta").load(SILVER_EIA_DAILY)
df_macro    = spark.read.format("delta").load(SILVER_MACRO_DAILY)
df_opec     = spark.read.format("delta").load(SILVER_OPEC_FLAGS)

print(f"  date_spine       : {df_spine.count():>6,} rows")
print(f"  ais_vessel_daily : {df_vessel.count():>6,} rows")
print(f"  ais_loiter_daily : {df_loiter.count():>6,} rows")
print(f"  ais_gaps_daily   : {df_gaps.count():>6,} rows")
print(f"  market_daily     : {df_market.count():>6,} rows")
print(f"  eia_daily        : {df_eia.count():>6,} rows")
print(f"  macro_daily      : {df_macro.count():>6,} rows")
print(f"  opec_flags       : {df_opec.count():>6,} rows")

# COMMAND ----------

# ── CELL 3: Select columns from each Silver table ─────────────────────────

# Spine — base join key
df_base = df_spine.select(
    "trade_date", "year", "month", "quarter",
    "yyyymm", "day_of_week", "day_name",
    "is_trading_day", "is_weekend", "is_holiday"
)

# Vessel daily — AIS supply features
df_v = df_vessel.select(
    "trade_date",
    "middle_east_vessel_count",
    "west_africa_vessel_count",
    "us_gulf_vessel_count",
    "black_sea_vessel_count",
    "north_sea_vessel_count",
    "total_oil_region_vessel_count",
    "global_vessel_count",
    "global_visit_count",
)

# Loitering daily — congestion features
df_l = df_loiter.select(
    "trade_date",
    "global_loitering_count",
    "global_loitering_vessels",
    "middle_east_loitering_count",
    "west_africa_loitering_count",
    "total_oil_region_loitering_count",
)

# Gaps daily — dark fleet features
df_g = df_gaps.select(
    "trade_date",
    "global_gap_count",
    "global_dark_events",
    "black_sea_gap_count",
    "total_oil_dark_fleet_index",
)

# Market daily — price and technical features
df_m = df_market.select(
    "trade_date",
    "brent_close",
    "brent_return_1d",
    "brent_ma5",
    "brent_ma10",
    "brent_ma20",
    "brent_vol_20d",
    "brent_momentum_5d",
    "brent_momentum_20d",
    "brent_rsi14_proxy",
    "brent_52w_position",
    "brent_intraday_range",
    "contango_flag",
    "dxy_close",
    "dxy_return_1d",
    "next_day_return",
    "next_day_direction",
)

# EIA daily — inventory features
df_e = df_eia.select(
    "trade_date",
    "us_crude_stocks",
    "total_petroleum_stocks",
    "us_production",
    "refinery_utilisation",
    "imports",
    "exports",
    "net_supply_flow",
    "inventory_surprise",
)

# Macro daily — risk-free rate
df_mac = df_macro.select(
    "trade_date",
    "tb3ms_pct",
    "rf_daily",
)

# OPEC flags
df_o = df_opec.select(
    "trade_date",
    "days_to_next_opec",
    "days_since_opec",
    "opec_week_flag",
    "post_opec_flag",
    "opec_cut_flag",
    "opec_hold_flag",
    "opec_hike_flag",
    "last_opec_outcome",
    "last_cut_size_mbbld",
)

print("Column selection complete.")
print(f"  Vessel cols   : {len(df_v.columns) - 1}")
print(f"  Loiter cols   : {len(df_l.columns) - 1}")
print(f"  Gap cols      : {len(df_g.columns) - 1}")
print(f"  Market cols   : {len(df_m.columns) - 1}")
print(f"  EIA cols      : {len(df_e.columns) - 1}")
print(f"  Macro cols    : {len(df_mac.columns) - 1}")
print(f"  OPEC cols     : {len(df_o.columns) - 1}")

# COMMAND ----------

# ── CELL 4: Join all tables to date spine ─────────────────────────────────

print("Joining all Silver tables to date spine...")

df_joined = (df_base
    .join(df_v,   on="trade_date", how="left")
    .join(df_l,   on="trade_date", how="left")
    .join(df_g,   on="trade_date", how="left")
    .join(df_m,   on="trade_date", how="left")
    .join(df_e,   on="trade_date", how="left")
    .join(df_mac, on="trade_date", how="left")
    .join(df_o,   on="trade_date", how="left")
)

total = df_joined.count()
print(f"Joined rows : {total:,}  (expected: 2,556 calendar days)")
print(f"Columns     : {len(df_joined.columns)}")

# COMMAND ----------

# ── CELL 5: Engineer additional Gold-level features ───────────────────────

w_date = Window.orderBy("trade_date")
w_7d   = Window.orderBy("trade_date").rowsBetween(-6, 0)
w_14d  = Window.orderBy("trade_date").rowsBetween(-13, 0)
w_28d  = Window.orderBy("trade_date").rowsBetween(-27, 0)

df_gold = (df_joined

    # ── AIS rolling features ──────────────────────────────────────────────
    # 7-day and 28-day moving averages of vessel counts
    .withColumn("me_vessel_7d_ma",
        avg("middle_east_vessel_count").over(w_7d))
    .withColumn("me_vessel_28d_ma",
        avg("middle_east_vessel_count").over(w_28d))

    # Supply flow momentum — ratio of short to long term vessel activity
    # > 1 means recent activity above trend = supply increasing
    .withColumn("supply_flow_momentum",
        when(col("me_vessel_28d_ma") > 0,
             col("me_vessel_7d_ma") / col("me_vessel_28d_ma"))
        .otherwise(lit(1.0)))

    # Total oil region vessel 7d MA
    .withColumn("total_oil_vessel_7d_ma",
        avg("total_oil_region_vessel_count").over(w_7d))

    # Week-over-week vessel count change at Middle East terminals
    .withColumn("me_vessel_wow_change",
        col("middle_east_vessel_count") -
        lag("middle_east_vessel_count", 7).over(w_date))

    # ── Loitering rolling features ────────────────────────────────────────
    .withColumn("loitering_7d_ma",
        avg("global_loitering_count").over(w_7d))
    .withColumn("loitering_14d_ma",
        avg("global_loitering_count").over(w_14d))

    # Congestion index — loitering relative to vessel activity
    # High loitering per vessel = port congestion / waiting
    .withColumn("congestion_index",
        when(col("global_vessel_count") > 0,
             col("global_loitering_count") /
             col("global_vessel_count"))
        .otherwise(lit(0.0)))

    # ── Dark fleet index rolling ──────────────────────────────────────────
    .withColumn("dark_fleet_7d_ma",
        avg("total_oil_dark_fleet_index").over(w_7d))

    # ── EIA derived features ──────────────────────────────────────────────
    # Inventory level as % of 52-week range
    # Tells the model whether stocks are historically high or low
    .withColumn("crude_stocks_52w_max",
        spark_max("us_crude_stocks").over(
            Window.orderBy("trade_date").rowsBetween(-364, 0)))
    .withColumn("crude_stocks_52w_min",
        spark_min("us_crude_stocks").over(
            Window.orderBy("trade_date").rowsBetween(-364, 0)))
    .withColumn("crude_stocks_52w_pct",
        when(
            (col("crude_stocks_52w_max") -
             col("crude_stocks_52w_min")) > 0,
            (col("us_crude_stocks") - col("crude_stocks_52w_min")) /
            (col("crude_stocks_52w_max") - col("crude_stocks_52w_min"))
        ).otherwise(lit(0.5)))

    # Refinery utilisation 4-week MA
    .withColumn("refinery_util_4w_ma",
        avg("refinery_utilisation").over(w_28d))

    # ── Market regime features ────────────────────────────────────────────
    # Volatility regime — is current vol above its 28-day average?
    .withColumn("vol_regime",
        when(col("brent_vol_20d") >
             avg("brent_vol_20d").over(w_28d), lit(1))
        .otherwise(lit(0)))

    # Brent 14-day return for medium-term momentum
    .withColumn("brent_return_14d",
        when(lag("brent_close", 14).over(w_date) > 0,
             (col("brent_close") -
              lag("brent_close", 14).over(w_date)) /
             lag("brent_close", 14).over(w_date))
        .otherwise(lit(None).cast("double")))

    # ── Calendar features ─────────────────────────────────────────────────
    # Month-end flag — last 3 trading days of month
    # Position squaring / rebalancing happens here
    .withColumn("is_month_end_week",
        when(col("day_of_week").isin(2, 3, 4) &
             (col("month") != lead("month", 3).over(w_date)),
             lit(1))
        .otherwise(lit(0)))
)

print(f"Gold features computed.")
print(f"  Total rows   : {df_gold.count():,}")
print(f"  Total columns: {len(df_gold.columns)}")

# COMMAND ----------

# ── CELL 6: Filter to trading days only and select final schema ───────────

df_final = (df_gold
    .filter(col("is_trading_day") == 1)
    .select(
        # ── Identity ──────────────────────────────────────────────────────
        "trade_date", "year", "month", "quarter",
        "yyyymm", "day_of_week", "day_name",

        # ── AIS vessel features ───────────────────────────────────────────
        "middle_east_vessel_count",
        "west_africa_vessel_count",
        "us_gulf_vessel_count",
        "black_sea_vessel_count",
        "north_sea_vessel_count",
        "total_oil_region_vessel_count",
        "me_vessel_7d_ma",
        "me_vessel_28d_ma",
        "me_vessel_wow_change",
        "supply_flow_momentum",
        "total_oil_vessel_7d_ma",

        # ── Loitering / congestion features ──────────────────────────────
        "global_loitering_count",
        "middle_east_loitering_count",
        "loitering_7d_ma",
        "loitering_14d_ma",
        "congestion_index",
        "total_oil_region_loitering_count",

        # ── Dark fleet features ───────────────────────────────────────────
        "global_dark_events",
        "total_oil_dark_fleet_index",
        "black_sea_gap_count",
        "dark_fleet_7d_ma",

        # ── Price features ────────────────────────────────────────────────
        "brent_close",
        "brent_return_1d",
        "brent_return_14d",
        "brent_ma5",
        "brent_ma20",
        "brent_vol_20d",
        "brent_momentum_5d",
        "brent_rsi14_proxy",
        "brent_52w_position",
        "contango_flag",
        "vol_regime",

        # ── DXY features ──────────────────────────────────────────────────
        "dxy_close",
        "dxy_return_1d",

        # ── EIA inventory features ────────────────────────────────────────
        "us_crude_stocks",
        "crude_stocks_52w_pct",
        "inventory_surprise",
        "net_supply_flow",
        "refinery_utilisation",
        "refinery_util_4w_ma",

        # ── Macro features ────────────────────────────────────────────────
        "rf_daily",
        "tb3ms_pct",

        # ── OPEC features ─────────────────────────────────────────────────
        "days_to_next_opec",
        "opec_week_flag",
        "post_opec_flag",
        "opec_cut_flag",
        "last_cut_size_mbbld",

        # ── Target variable ───────────────────────────────────────────────
        "next_day_return",
        "next_day_direction",
    )
    .orderBy("trade_date")
)

total       = df_final.count()
feature_cols = [c for c in df_final.columns
                if c not in ["trade_date","year","month","quarter",
                              "yyyymm","day_of_week","day_name",
                              "next_day_return","next_day_direction"]]

print(f"Final Gold feature store:")
print(f"  Trading day rows : {total:,}  (expected ~1,761)")
print(f"  Feature columns  : {len(feature_cols)}")
print(f"  Total columns    : {len(df_final.columns)}")

# COMMAND ----------

# ── CELL 7: Null audit before writing ─────────────────────────────────────
# Any feature with >10% nulls on trading days needs investigation.

print("Null audit on feature columns:\n")
print(f"  {'Feature':<40} {'Nulls':>7}  {'%':>6}  Status")
print(f"  {'─'*60}")

null_issues = []
for c in feature_cols:
    n_null = df_final.filter(isnull(col(c))).count()
    pct    = builtins.round(n_null / total * 100, 1)
    status = "WARN" if pct > 10 else "ok"
    if pct > 10:
        null_issues.append((c, pct))
    if pct > 0:
        print(f"  {c:<40} {n_null:>7,}  {pct:>5.1f}%  {status}")

if not null_issues:
    print("  All features under 10% null threshold.")
else:
    print(f"\n  {len(null_issues)} features above 10% null threshold:")
    for c, pct in null_issues:
        print(f"    {c} — {pct}% null")
    print("  These will be filled with 0 before writing.")

# Fill remaining nulls
for c in feature_cols:
    df_final = df_final.fillna({c: 0})

# COMMAND ----------

# ── CELL 8: Write Gold feature store ──────────────────────────────────────

print("Writing Gold feature store...")

df_final.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .save(GOLD_FEATURE_STORE)

count = spark.read.format("delta").load(GOLD_FEATURE_STORE).count()
print(f"Written: {count:,} rows → {GOLD_FEATURE_STORE}")

# COMMAND ----------

# ── CELL 9: Validation ────────────────────────────────────────────────────

df = spark.read.format("delta").load(GOLD_FEATURE_STORE)

print("=" * 65)
print("  GOLD FEATURE STORE — VALIDATION")
print("=" * 65)

total = df.count()
print(f"\n  Total rows (trading days) : {total:,}")
print(f"  Total columns             : {len(df.columns)}")

# Date range
dr = df.agg(
    spark_min("trade_date").alias("first"),
    spark_max("trade_date").alias("last")
).collect()[0]
print(f"  Date range                : {dr['first']} → {dr['last']}")

# Target distribution
print(f"\n  Target distribution:")
(df.groupBy("next_day_direction").count()
    .orderBy("next_day_direction").show(truncate=False))

# Sample rows
print(f"  Sample rows (first 5 trading days):")
(df.select(
    "trade_date",
    "middle_east_vessel_count",
    "supply_flow_momentum",
    "brent_close",
    "brent_return_1d",
    "inventory_surprise",
    "opec_week_flag",
    "next_day_direction"
).orderBy("trade_date").limit(5).show(truncate=False))

# Feature summary stats
print(f"  Key feature statistics (trading days):")
(df.select(
    "middle_east_vessel_count",
    "congestion_index",
    "brent_close",
    "brent_vol_20d",
    "inventory_surprise",
    "rf_daily",
).summary("min","mean","max").show(truncate=False))

print("=" * 65)
print("  Gold feature store COMPLETE.")
print("  Proceed to Cell 10 — export to CSV for Colab training.")
print("=" * 65)

# COMMAND ----------

# ── CELL 10: Export to CSV for Google Colab ───────────────────────────────

print("Exporting Gold feature store to CSV...")

export_path = f"{EXPORTS_DIR}/gold_features_csv"

(df_final
    .coalesce(1)
    .write
    .format("csv")
    .option("header", "true")
    .mode("overwrite")
    .save(export_path))

# Find the actual CSV file
csv_files = [
    f.path for f in dbutils.fs.ls(export_path)
    if f.path.endswith(".csv")
]
csv_path = csv_files[0]

print(f"\nExported to: {csv_path}")
print(f"\nTo download:")
print(f"  Catalog → workspace → oil_intel → project_data")
print(f"  → exports → gold_features_csv")
print(f"  → click the .csv file → Download")
print(f"\nFile size estimate: ~500 KB ({total:,} rows × {len(df_final.columns)} cols)")
print(f"\nUpload to Colab:")
print(f"  from google.colab import files")
print(f"  uploaded = files.upload()")
print(f"  df = pd.read_csv(list(uploaded.keys())[0])")

# COMMAND ----------

# ── Quick CSV check — run after Cell 10 ──────────────────────────────────

import pandas as pd

# Read directly from the volume to verify
csv_files = [
    f.path for f in dbutils.fs.ls(f"{EXPORTS_DIR}/gold_features_csv")
    if f.path.endswith(".csv")
]

# Read via pandas using the dbfs path
local_path = csv_files[0].replace(
    "/Volumes/workspace/oil_intel/project_data",
    "/Volumes/workspace/oil_intel/project_data"
)

df_check = pd.read_csv(
    csv_files[0].replace("dbfs:", "")
    if csv_files[0].startswith("dbfs:") else
    f"/dbfs{csv_files[0]}" if not csv_files[0].startswith("/dbfs")
    else csv_files[0]
)

print(f"Rows    : {len(df_check):,}")
print(f"Columns : {len(df_check.columns)}")
print(f"Nulls   : {df_check.isnull().sum().sum():,} total")
print(f"\nColumn list:")
for i, c in enumerate(df_check.columns):
    print(f"  {i+1:>2}. {c}")
print(f"\nTarget distribution:")
print(df_check["next_day_direction"].value_counts())
print(f"\nDate range: {df_check['trade_date'].min()} → "
      f"{df_check['trade_date'].max()}")

# COMMAND ----------

