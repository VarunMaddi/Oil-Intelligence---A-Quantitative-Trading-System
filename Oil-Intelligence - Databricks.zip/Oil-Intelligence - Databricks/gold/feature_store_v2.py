# Databricks notebook source
# =============================================================================
# Notebook: 14_gold_feature_store_v2.py
# Purpose : Updated Gold feature store with equity targets (XLE, XOM, CVX,
#           SLB, VLO, FRO, STNG), SPY beta stripping, corrected RSI,
#           ternary vol regime, rig count, and crack spread proxy.
#           Drops old Brent-direction targets. Brent is now a feature only.
# Runtime : ~8 minutes
# =============================================================================

# COMMAND ----------

# ── CELL 1: Imports and paths ─────────────────────────────────────────────

import subprocess
subprocess.run(["pip", "install", "yfinance", "-q"], capture_output=True)

import builtins
import pandas as pd
import numpy as np
import yfinance as yf
from pyspark.sql import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import (
    col, lag, lead, avg, stddev, when, lit, coalesce,
    round as spark_round, min as spark_min,
    max as spark_max, isnull, count,
    year as spark_year, month as spark_month
)
from pyspark.sql.window import Window

spark = SparkSession.builder.getOrCreate()

VOL_BASE = "/Volumes/workspace/oil_intel/project_data"

SILVER_DATE_SPINE      = f"{VOL_BASE}/silver/date_spine"
SILVER_VESSEL_DAILY    = f"{VOL_BASE}/silver/ais_vessel_daily"
SILVER_LOITERING_DAILY = f"{VOL_BASE}/silver/ais_loitering_daily"
SILVER_GAPS_DAILY      = f"{VOL_BASE}/silver/ais_gaps_daily"
SILVER_MARKET_DAILY    = f"{VOL_BASE}/silver/market_daily"
SILVER_EIA_DAILY       = f"{VOL_BASE}/silver/eia_daily"
SILVER_MACRO_DAILY     = f"{VOL_BASE}/silver/macro_daily"
SILVER_OPEC_FLAGS      = f"{VOL_BASE}/silver/opec_flags"

GOLD_FEATURE_STORE_V2  = f"{VOL_BASE}/gold/feature_store_v2"
EXPORTS_DIR            = f"{VOL_BASE}/exports"

dbutils.fs.mkdirs(GOLD_FEATURE_STORE_V2)
dbutils.fs.mkdirs(EXPORTS_DIR)

START = "2017-01-01"
END   = "2023-12-31"

print("Paths and imports ready.")
print(f"Gold output: {GOLD_FEATURE_STORE_V2}")

# COMMAND ----------

# ── CELL 2: Fetch equity and SPY data via yfinance ────────────────────────
# XLE, XOM, CVX, SLB, VLO, FRO, STNG = targets
# SPY = beta stripping feature
# All prices 2017-01-01 → 2023-12-31

EQUITY_TICKERS = {
    "XLE":  "xle",   # Energy Select Sector ETF (primary target)
    "XOM":  "xom",   # ExxonMobil
    "CVX":  "cvx",   # Chevron
    "SLB":  "slb",   # Schlumberger (oil services)
    "VLO":  "vlo",   # Valero (refiner)
    "FRO":  "fro",   # Frontline (VLCC tanker)
    "STNG": "stng",  # Scorpio Tankers (product tanker)
    "SPY":  "spy",   # S&P 500 — beta stripping only, not a target
}

print("Downloading equity data from Yahoo Finance...")
equity_dfs = []

for ticker, name in EQUITY_TICKERS.items():
    try:
        raw = yf.download(
            ticker, start=START, end=END,
            auto_adjust=True, progress=False
        )
        raw = raw.reset_index()

        # Flatten MultiIndex if present
        if isinstance(raw.columns, pd.MultiIndex):
            raw.columns = [c[0].lower() if c[1] == "" else c[0].lower()
                           for c in raw.columns]
        else:
            raw.columns = [c.lower().replace(" ", "_") for c in raw.columns]

        date_col = [c for c in raw.columns if "date" in c.lower()]
        if date_col:
            raw = raw.rename(columns={date_col[0]: "trade_date"})

        raw["trade_date"] = raw["trade_date"].astype(str)
        raw = raw[["trade_date", "close"]].rename(
            columns={"close": f"{name}_close"}
        )
        equity_dfs.append(raw)
        print(f"  {ticker:<5} ({name:<5}): {len(raw):,} rows "
              f"({raw['trade_date'].min()} → {raw['trade_date'].max()})")

    except Exception as e:
        print(f"  {ticker:<5} FAILED: {e}")

# Merge all equity data on trade_date
from functools import reduce
df_equity_pd = reduce(
    lambda a, b: pd.merge(a, b, on="trade_date", how="outer"),
    equity_dfs
)
df_equity_pd = df_equity_pd.sort_values("trade_date").reset_index(drop=True)

print(f"\nEquity DataFrame: {df_equity_pd.shape}")
print(df_equity_pd.head(3))

# COMMAND ----------

# ── CELL 3: Compute equity returns, 5d forward returns, vol, beta ──────────

print("Computing equity features...")

df_eq = df_equity_pd.copy()
df_eq["trade_date"] = pd.to_datetime(df_eq["trade_date"])
df_eq = df_eq.sort_values("trade_date").reset_index(drop=True)

EQUITY_NAMES = [v for v in EQUITY_TICKERS.values()]  # xle, xom, cvx...
TARGET_NAMES = [v for v in EQUITY_TICKERS.values()
                if v != "spy"]  # everything except spy

for name in EQUITY_NAMES:
    close_col = f"{name}_close"
    if close_col not in df_eq.columns:
        continue

    # 1-day log return
    df_eq[f"{name}_return_1d"] = np.log(
        df_eq[close_col] / df_eq[close_col].shift(1)
    )

    # 5-day forward return — computed here, used as target label in Colab
    # shift(-5) ensures no leakage — today's row uses future price
    df_eq[f"{name}_return_5d_fwd"] = (
        df_eq[close_col].pct_change(5).shift(-5)
    )

    # 10-day forward return
    df_eq[f"{name}_return_10d_fwd"] = (
        df_eq[close_col].pct_change(10).shift(-10)
    )

    # 20-day realized vol (annualised)
    df_eq[f"{name}_vol_20d"] = (
        df_eq[f"{name}_return_1d"].rolling(20).std() * np.sqrt(252)
    )

# ── SPY-based beta features ───────────────────────────────────────────────
# Rolling 60-day beta of each equity to SPY
# beta = cov(equity, spy) / var(spy)
for name in TARGET_NAMES:
    ret_col = f"{name}_return_1d"
    if ret_col not in df_eq.columns:
        continue
    cov_roll = (
        df_eq[ret_col]
        .rolling(60)
        .cov(df_eq["spy_return_1d"])
    )
    var_spy = df_eq["spy_return_1d"].rolling(60).var()
    df_eq[f"{name}_beta_60d"] = cov_roll / (var_spy + 1e-10)

# ── XLE-Brent spread ─────────────────────────────────────────────────────
# We don't have Brent in this df yet — add it via merge after Silver join.
# Placeholder column added post-join in Spark.

# ── SPY 5-day return ─────────────────────────────────────────────────────
df_eq["spy_return_5d"] = df_eq["spy_close"].pct_change(5).shift(-5)

df_eq["trade_date"] = df_eq["trade_date"].dt.strftime("%Y-%m-%d")

print(f"Equity features computed.")
print(f"  Rows    : {len(df_eq):,}")
print(f"  Columns : {len(df_eq.columns)}")
print(f"  Cols    : {list(df_eq.columns)}")

# COMMAND ----------

# ── CELL 4: Fetch Baker Hughes rig count (weekly) ─────────────────────────
# Public CSV from Baker Hughes, updated every Friday.
# Forward-fill to daily — same pattern as EIA data.

print("Fetching Baker Hughes US rig count...")

import requests

BH_URL = "https://rigcount.bakerhughes.com/static-files/7240366e-61cc-4a35-a4b6-b04c8f517ae5"

try:
    resp = requests.get(BH_URL, timeout=30)
    if resp.status_code == 200:
        from io import BytesIO
        df_rig = pd.read_excel(BytesIO(resp.content), skiprows=6)
        # Find the US total column
        print(f"  Rig count columns: {list(df_rig.columns[:10])}")
    else:
        raise Exception(f"HTTP {resp.status_code}")
except Exception as e:
    print(f"  Baker Hughes direct download failed: {e}")
    print("  Using fallback: constructing from known trend data")
    # Fallback — approximate US rig count trend 2017-2023
    # Source: Baker Hughes published data, approximated as monthly anchors
    # This is a reasonable proxy if the direct download fails
    rig_anchors = [
        ("2017-01-06", 659), ("2017-06-30", 941), ("2017-12-29", 931),
        ("2018-06-29", 1052),("2018-12-28", 1075),("2019-06-28", 971),
        ("2019-12-27", 805), ("2020-06-26", 263), ("2020-12-31", 351),
        ("2021-06-25", 470), ("2021-12-31", 586), ("2022-06-24", 753),
        ("2022-12-30", 779), ("2023-06-30", 680), ("2023-12-29", 619),
    ]
    rig_pd = pd.DataFrame(rig_anchors, columns=["trade_date","rig_count_us"])
    rig_pd["trade_date"] = pd.to_datetime(rig_pd["trade_date"])

    # Interpolate to weekly
    full_dates = pd.date_range(START, END, freq="W-FRI")
    rig_full   = pd.DataFrame({"trade_date": full_dates})
    rig_full   = rig_full.merge(rig_pd, on="trade_date", how="left")
    rig_full["rig_count_us"] = (
        rig_full["rig_count_us"]
        .interpolate(method="linear")
        .round(0)
        .astype(int)
    )
    rig_full["trade_date"] = rig_full["trade_date"].dt.strftime("%Y-%m-%d")
    print(f"  Fallback rig count: {len(rig_full)} weekly rows")
    print(f"  Range: {rig_full['rig_count_us'].min()} – "
          f"{rig_full['rig_count_us'].max()} rigs")

# COMMAND ----------

# ── CELL 5 (REPLACE) ─────────────────────────────────────────────────────
# Changes: new split uses gold_features_v2.csv, fixed beta formula,
# fixed xle_vol_20d (daily not annualised), fixed xle_brent_spread_5d,
# drop 11 NaN rows from US equity holidays in forward targets.

DATA_PATH = '/Volumes/workspace/oil_intel/project_data/exports/gold_features_v2_csv/part-00000-tid-1409710185348047746-bc950bd8-f679-4942-85ed-acb92e086f9e-3699-1-c000.csv'
df = pd.read_csv(DATA_PATH)
df['trade_date'] = pd.to_datetime(df['trade_date'])
df = df.sort_values('trade_date').reset_index(drop=True)

# ── Brent-based targets (kept for 1d baseline model) ─────────────────────
df['next_day_return']    = df['brent_close'].pct_change().shift(-1)
df['next_day_direction'] = (df['next_day_return'] > 0).astype(int)
for h in [3, 5, 10]:
    df[f'return_{h}d']    = df['brent_close'].pct_change(h).shift(-h)
    df[f'direction_{h}d'] = (df[f'return_{h}d'] > 0).astype(int)

# ── FIX 1: xle_vol_20d — daily std, not annualised ───────────────────────
# v2 CSV may have annualised version; recompute as daily std
df['xle_vol_20d_daily'] = df['xle_return_1d'].rolling(20).std()
df['brent_vol_20d_daily'] = df['brent_vol_20d']  # already daily std

# ── FIX 2: brent_xle_vol_ratio — recompute with same units ───────────────
df['brent_xle_vol_ratio'] = np.where(
    df['xle_vol_20d_daily'] > 0,
    df['brent_vol_20d_daily'] / df['xle_vol_20d_daily'],
    1.0
)

# ── FIX 3: xle_brent_spread_5d — correct formula ─────────────────────────
# 5-day return of XLE minus 5-day return of Brent
df['xle_brent_spread_5d'] = (
    df['xle_close'].pct_change(5) - df['brent_close'].pct_change(5)
)

# ── FIX 4: Rolling betas — equity vs BRENT (not SPY) ─────────────────────
# beta = cov(equity_ret, brent_ret) / var(brent_ret)
BETA_WINDOW = 60
EQUITY_TARGETS = ['xle', 'xom', 'cvx', 'slb', 'vlo', 'fro', 'stng']

for name in EQUITY_TARGETS:
    ret_col = f'{name}_return_1d'
    if ret_col not in df.columns:
        continue
    cov_roll = df[ret_col].rolling(BETA_WINDOW).cov(df['brent_return_1d'])
    var_brent = df['brent_return_1d'].rolling(BETA_WINDOW).var()
    df[f'{name}_beta_brent_60d'] = cov_roll / (var_brent + 1e-10)
    df[f'{name}_beta_brent_60d'] = df[f'{name}_beta_brent_60d'].clip(-5, 5)

# ── FIX 5: crack_spread_z — rolling expanding window to avoid leakage ─────
# z-score normalised only using data available up to each point
df['crack_spread_proxy'] = np.where(
    df['brent_close'] > 0,
    df['refinery_utilisation'] / df['brent_close'],
    0.0
)
roll_mean = df['crack_spread_proxy'].expanding(min_periods=20).mean()
roll_std  = df['crack_spread_proxy'].expanding(min_periods=20).std()
df['crack_spread_z'] = (df['crack_spread_proxy'] - roll_mean) / (roll_std + 1e-10)

# ── Cross-source interaction features (unchanged from v4.1) ───────────────
df['vessel_price_diverge']    = (df['supply_flow_momentum'].rolling(5).mean()
    - df['brent_return_1d'].rolling(5).mean() / (df['brent_vol_20d'] + 1e-8))
df['inventory_vessel_confirm'] = df['inventory_surprise'] * df['me_vessel_wow_change']
df['ais_price_momentum_ratio'] = df['supply_flow_momentum'] / (df['brent_momentum_5d'].abs() + 1e-8)
df['congestion_vol_interaction'] = df['congestion_index'] * df['brent_vol_20d']
df['dark_fleet_opec_interaction'] = df['total_oil_dark_fleet_index'] * df['opec_cut_flag']
df['return_5d_pctile'] = df['brent_return_1d'].rolling(60).apply(
    lambda x: pd.Series(x).rank(pct=True).iloc[-1], raw=False)
df['vessel_acceleration']   = df['total_oil_region_vessel_count'].diff().diff()
ss = np.sign(df['inventory_surprise'])
df['surprise_streak']       = (ss.groupby((ss != ss.shift()).cumsum()).cumcount() + 1) * ss
df['dxy_oil_corr_20d']      = df['dxy_return_1d'].rolling(20).corr(df['brent_return_1d'])
df['me_usg_ratio_change']   = (df['middle_east_vessel_count'] /
    (df['us_gulf_vessel_count'] + 1)).pct_change(5)
df['loitering_ratio_change'] = (df['total_oil_region_loitering_count'] /
    (df['total_oil_region_vessel_count'] + 1)).pct_change(5)
df['opec_vol_interaction']  = df['opec_week_flag'] * df['brent_vol_20d']
df['refinery_util_momentum'] = df['refinery_utilisation'] - df['refinery_util_4w_ma']
df['blacksea_share_change'] = (df['black_sea_vessel_count'] /
    (df['total_oil_region_vessel_count'] + 1)).pct_change(5)
df['contango_momentum']     = df['contango_flag'].rolling(10).mean()
df['stock_vessel_ratio']    = df['crude_stocks_52w_pct'] * df['supply_flow_momentum']

# ── New equity-based interactions ────────────────────────────────────────
df['xle_vol_regime_interact'] = df['xle_vol_20d_daily'] * df['vol_regime_3']
df['tanker_opec_interact']    = df['tanker_demand_roc'] * df['opec_cut_flag']
df['fro_dark_fleet_confirm']  = df['fro_return_1d'] * df['total_oil_dark_fleet_index']

NEW_FEATURES = [
    'vessel_price_diverge', 'inventory_vessel_confirm', 'ais_price_momentum_ratio',
    'congestion_vol_interaction', 'dark_fleet_opec_interaction', 'return_5d_pctile',
    'vessel_acceleration', 'surprise_streak', 'dxy_oil_corr_20d', 'me_usg_ratio_change',
    'loitering_ratio_change', 'opec_vol_interaction', 'refinery_util_momentum',
    'blacksea_share_change', 'contango_momentum', 'stock_vessel_ratio',
    'xle_vol_regime_interact', 'tanker_opec_interact', 'fro_dark_fleet_confirm',
    'brent_xle_vol_ratio', 'xle_brent_spread_5d', 'crack_spread_z',
]
for c in NEW_FEATURES:
    if c in df.columns:
        df[c] = df[c].fillna(0).replace([np.inf, -np.inf], 0)

# ── Drop 11 NaN rows from US equity holidays ──────────────────────────────
df = df.dropna(subset=['return_5d']).reset_index(drop=True)

# ── Drop rows where equity close is 0 or NaN (market closed) ─────────────
equity_close_cols = [f'{n}_close' for n in EQUITY_TARGETS]
for c in equity_close_cols:
    if c in df.columns:
        df = df[df[c] > 0]
df = df.reset_index(drop=True)

print(f'Shape after cleaning: {df.shape}')
print(f'Date range: {df.trade_date.min().date()} → {df.trade_date.max().date()}')
print(f'NaN in forward targets: {df[[f"{n}_return_5d_fwd" for n in EQUITY_TARGETS if f"{n}_return_5d_fwd" in df.columns]].isnull().sum().to_dict()}')

# COMMAND ----------

# ── CELL 6: Load all Silver tables ───────────────────────────────────────

print("Loading Silver tables...")

df_spine   = spark.read.format("delta").load(SILVER_DATE_SPINE)
df_vessel  = spark.read.format("delta").load(SILVER_VESSEL_DAILY)
df_loiter  = spark.read.format("delta").load(SILVER_LOITERING_DAILY)
df_gaps    = spark.read.format("delta").load(SILVER_GAPS_DAILY)
df_market  = spark.read.format("delta").load(SILVER_MARKET_DAILY)
df_eia     = spark.read.format("delta").load(SILVER_EIA_DAILY)
df_macro   = spark.read.format("delta").load(SILVER_MACRO_DAILY)
df_opec    = spark.read.format("delta").load(SILVER_OPEC_FLAGS)

# ── Column selections from Silver ────────────────────────────────────────

df_base = df_spine.select(
    "trade_date", "year", "month", "quarter",
    "day_of_week", "is_trading_day", "is_weekend", "is_holiday"
)

df_v = df_vessel.select(
    "trade_date",
    "middle_east_vessel_count", "west_africa_vessel_count",
    "us_gulf_vessel_count", "black_sea_vessel_count",
    "north_sea_vessel_count", "total_oil_region_vessel_count",
    "global_vessel_count", "global_visit_count",
)

df_l = df_loiter.select(
    "trade_date",
    "global_loitering_count", "global_loitering_vessels",
    "middle_east_loitering_count", "west_africa_loitering_count",
    "total_oil_region_loitering_count",
)

df_g = df_gaps.select(
    "trade_date",
    "global_gap_count", "global_dark_events",
    "black_sea_gap_count", "total_oil_dark_fleet_index",
)

# Market — Brent is now a FEATURE, remove old targets
df_m = df_market.select(
    "trade_date",
    "brent_close", "brent_open", "brent_high", "brent_low",
    "brent_return_1d", "brent_ma5", "brent_ma10", "brent_ma20",
    "brent_vol_20d", "brent_momentum_5d", "brent_momentum_20d",
    "brent_52w_position", "brent_intraday_range",
    "contango_flag",
    "dxy_close", "dxy_return_1d",
    # NOTE: next_day_return and next_day_direction DROPPED here
)

df_e = df_eia.select(
    "trade_date",
    "us_crude_stocks", "total_petroleum_stocks",
    "us_production", "refinery_utilisation",
    "imports", "exports", "net_supply_flow", "inventory_surprise",
)

df_mac = df_macro.select(
    "trade_date", "tb3ms_pct", "rf_daily",
)

df_o = df_opec.select(
    "trade_date",
    "days_to_next_opec", "days_since_opec",
    "opec_week_flag", "post_opec_flag",
    "opec_cut_flag", "opec_hold_flag", "opec_hike_flag",
    "last_opec_outcome", "last_cut_size_mbbld",
)

print("All Silver tables loaded and columns selected.")

# COMMAND ----------

# ── CELL 7 (REPLACE) ─────────────────────────────────────────────────────
# Changes: add equity features, fixed columns, remove old brent_rsi14_proxy
# and vol_regime, use brent_rsi14 and vol_regime_3 from v2 CSV.

ORIG_FEATURES = [
    # AIS vessel (unchanged)
    'middle_east_vessel_count', 'west_africa_vessel_count', 'us_gulf_vessel_count',
    'black_sea_vessel_count', 'north_sea_vessel_count', 'total_oil_region_vessel_count',
    'me_vessel_7d_ma', 'me_vessel_28d_ma', 'me_vessel_wow_change',
    'supply_flow_momentum', 'total_oil_vessel_7d_ma',
    # Loitering (unchanged)
    'global_loitering_count', 'middle_east_loitering_count',
    'loitering_7d_ma', 'loitering_14d_ma', 'congestion_index',
    'total_oil_region_loitering_count',
    # Dark fleet (unchanged)
    'global_dark_events', 'total_oil_dark_fleet_index',
    'black_sea_gap_count', 'dark_fleet_7d_ma',
    # Brent — now a feature not target
    'brent_close', 'brent_return_1d', 'brent_return_14d',
    'brent_ma5', 'brent_ma20', 'brent_vol_20d',
    'brent_momentum_5d',
    'brent_rsi14',       # FIXED: replaces brent_rsi14_proxy
    'brent_52w_position',
    'contango_flag',
    'vol_regime_3',      # FIXED: ternary replaces binary vol_regime
    # DXY (unchanged)
    'dxy_close', 'dxy_return_1d',
    # EIA (unchanged)
    'us_crude_stocks', 'crude_stocks_52w_pct', 'inventory_surprise',
    'net_supply_flow', 'refinery_utilisation', 'refinery_util_4w_ma',
    # Macro (unchanged)
    'rf_daily', 'tb3ms_pct',
    # OPEC (unchanged)
    'days_to_next_opec', 'opec_week_flag', 'post_opec_flag',
    'opec_cut_flag', 'last_cut_size_mbbld',
    # New equity features
    'xle_close', 'xle_return_1d', 'xle_vol_20d_daily',
    'xom_return_1d', 'cvx_return_1d',
    'slb_return_1d', 'vlo_return_1d',
    'fro_return_1d', 'stng_return_1d',
    'spy_return_1d',
    # Rolling betas (equity vs Brent — FIXED formula)
    'xle_beta_brent_60d', 'fro_beta_brent_60d', 'stng_beta_brent_60d',
    'vlo_beta_brent_60d', 'slb_beta_brent_60d',
    # New cross-asset features
    'brent_xle_vol_ratio',       # FIXED: same units now
    'xle_brent_spread_5d',       # FIXED: correct formula
    'crack_spread_z',             # FIXED: expanding window z-score
    'tanker_demand_roc',
    'rig_count_us',
]

# Only keep columns that actually exist in df
ORIG_FEATURES = [c for c in ORIG_FEATURES if c in df.columns]
ALL_FEATURES  = ORIG_FEATURES + [c for c in NEW_FEATURES if c in df.columns]

# Deduplicate preserving order
seen = set()
ALL_FEATURES = [c for c in ALL_FEATURES
                if not (c in seen or seen.add(c))]

print(f'Total features: {len(ALL_FEATURES)}')
print(f'  Original/base : {len(ORIG_FEATURES)}')
print(f'  Interactions  : {len([c for c in ALL_FEATURES if c in NEW_FEATURES])}')
print(f'\nMissing from df:')
missing = [c for c in ALL_FEATURES if c not in df.columns]
print(f'  {missing if missing else "none"}')

# COMMAND ----------

# ── CELL 8: Engineer Gold-level features ──────────────────────────────────

w_date = Window.orderBy("trade_date")
w_7d   = Window.orderBy("trade_date").rowsBetween(-6, 0)
w_14d  = Window.orderBy("trade_date").rowsBetween(-13, 0)
w_20d  = Window.orderBy("trade_date").rowsBetween(-19, 0)
w_28d  = Window.orderBy("trade_date").rowsBetween(-27, 0)
w_60d  = Window.orderBy("trade_date").rowsBetween(-59, 0)

df_gold = (df_joined

    # ── AIS rolling features ──────────────────────────────────────────────
    .withColumn("me_vessel_7d_ma",
        avg("middle_east_vessel_count").over(w_7d))
    .withColumn("me_vessel_28d_ma",
        avg("middle_east_vessel_count").over(w_28d))
    .withColumn("supply_flow_momentum",
        when(col("me_vessel_28d_ma") > 0,
             col("me_vessel_7d_ma") / col("me_vessel_28d_ma"))
        .otherwise(lit(1.0)))
    .withColumn("total_oil_vessel_7d_ma",
        avg("total_oil_region_vessel_count").over(w_7d))
    .withColumn("me_vessel_wow_change",
        col("middle_east_vessel_count") -
        lag("middle_east_vessel_count", 7).over(w_date))

    # ── Loitering rolling ─────────────────────────────────────────────────
    .withColumn("loitering_7d_ma",
        avg("global_loitering_count").over(w_7d))
    .withColumn("loitering_14d_ma",
        avg("global_loitering_count").over(w_14d))
    .withColumn("congestion_index",
        when(col("global_vessel_count") > 0,
             col("global_loitering_count") / col("global_vessel_count"))
        .otherwise(lit(0.0)))

    # ── Dark fleet rolling ────────────────────────────────────────────────
    .withColumn("dark_fleet_7d_ma",
        avg("total_oil_dark_fleet_index").over(w_7d))

    # ── EIA derived ───────────────────────────────────────────────────────
    .withColumn("crude_stocks_52w_max",
        spark_max("us_crude_stocks").over(
            Window.orderBy("trade_date").rowsBetween(-364, 0)))
    .withColumn("crude_stocks_52w_min",
        spark_min("us_crude_stocks").over(
            Window.orderBy("trade_date").rowsBetween(-364, 0)))
    .withColumn("crude_stocks_52w_pct",
        when(
            (col("crude_stocks_52w_max") - col("crude_stocks_52w_min")) > 0,
            (col("us_crude_stocks") - col("crude_stocks_52w_min")) /
            (col("crude_stocks_52w_max") - col("crude_stocks_52w_min"))
        ).otherwise(lit(0.5)))
    .withColumn("refinery_util_4w_ma",
        avg("refinery_utilisation").over(w_28d))

    # ── FIXED: Proper Wilder RSI-14 for Brent ────────────────────────────
    # Step 1: price change
    .withColumn("_brent_chg",
        col("brent_close") - lag("brent_close", 1).over(w_date))
    # Step 2: up/down moves
    .withColumn("_brent_up",
        when(col("_brent_chg") > 0, col("_brent_chg")).otherwise(lit(0.0)))
    .withColumn("_brent_dn",
        when(col("_brent_chg") < 0, -col("_brent_chg")).otherwise(lit(0.0)))
    # Step 3: 14-period average of ups and downs
    .withColumn("_avg_up",
        avg("_brent_up").over(
            Window.orderBy("trade_date").rowsBetween(-13, 0)))
    .withColumn("_avg_dn",
        avg("_brent_dn").over(
            Window.orderBy("trade_date").rowsBetween(-13, 0)))
    # Step 4: RSI = 100 - 100/(1 + avg_up/avg_dn)
    .withColumn("brent_rsi14",
        when(col("_avg_dn") == 0, lit(100.0))
        .otherwise(
            lit(100.0) - (lit(100.0) / (lit(1.0) + col("_avg_up") / col("_avg_dn")))
        ))

    # ── FIXED: Ternary vol regime (0=low, 1=mid, 2=high) ─────────────────
    # Breakpoints from training-period quantiles (2017-2019)
    # Low  < 0.01 (1% daily vol = ~16% annual)
    # High > 0.025 (2.5% daily vol = ~40% annual)
    .withColumn("vol_regime_3",
        when(col("brent_vol_20d") < 0.010, lit(0))   # low vol
        .when(col("brent_vol_20d") > 0.025, lit(2))  # high vol
        .otherwise(lit(1)))                            # mid vol

    # ── Market momentum features ──────────────────────────────────────────
    .withColumn("brent_return_14d",
        when(lag("brent_close", 14).over(w_date) > 0,
             (col("brent_close") -
              lag("brent_close", 14).over(w_date)) /
             lag("brent_close", 14).over(w_date))
        .otherwise(lit(None).cast("double")))
    .withColumn("brent_52w_high",
        spark_max("brent_close").over(
            Window.orderBy("trade_date").rowsBetween(-251, 0)))
    .withColumn("brent_52w_low",
        spark_min("brent_close").over(
            Window.orderBy("trade_date").rowsBetween(-251, 0)))

    # ── Vol ratio: Brent vs XLE ───────────────────────────────────────────
    # When Brent vol >> XLE vol: physical market moving faster than equities
    # Predictive of equity catch-up
    .withColumn("brent_xle_vol_ratio",
        when(col("xle_vol_20d") > 0,
             col("brent_vol_20d") / col("xle_vol_20d"))
        .otherwise(lit(1.0)))

    # ── XLE-Brent 5-day return spread ────────────────────────────────────
    # xle_return_1d is already in df from equity_daily
    # 5-day rolling sum of (xle_return_1d - brent_return_1d)
    .withColumn("_daily_spread",
        col("xle_return_1d") - col("brent_return_1d"))
    .withColumn("xle_brent_spread_5d",
        avg("_daily_spread").over(
            Window.orderBy("trade_date").rowsBetween(-4, 0)) * 5)

    # ── Crack spread proxy ────────────────────────────────────────────────
    # True 3-2-1: 2 * RBOB + 1 * HO - 3 * Brent (all in $/bbl)
    # We don't have RBOB/HO directly, so proxy using:
    # refinery_utilisation as refiner demand pressure
    # brent_close as crude cost
    # High refinery utilisation + low crude = high crack spread environment
    # Normalised to z-score so it's model-friendly
    .withColumn("crack_spread_proxy",
        when(col("brent_close") > 0,
             col("refinery_utilisation") / col("brent_close"))
        .otherwise(lit(0.0)))
    .withColumn("crack_spread_proxy_20d_ma",
        avg("crack_spread_proxy").over(w_20d))
    .withColumn("crack_spread_z",
        when(stddev("crack_spread_proxy").over(w_60d) > 0,
             (col("crack_spread_proxy") -
              avg("crack_spread_proxy").over(w_60d)) /
             stddev("crack_spread_proxy").over(w_60d))
        .otherwise(lit(0.0)))

    # ── FRO-specific: tanker demand proxy ────────────────────────────────
    # Rate-of-change of total oil region vessel count * 20d MA
    # Approximates ton-mile demand changes
    .withColumn("tanker_demand_roc",
        col("total_oil_region_vessel_count") -
        lag("total_oil_region_vessel_count", 5).over(w_date))
    .withColumn("tanker_demand_roc_20d_ma",
        avg("tanker_demand_roc").over(w_20d))

    # ── Calendar ──────────────────────────────────────────────────────────
    .withColumn("is_month_end_week",
        when(
            col("day_of_week").isin(2, 3, 4) &
            (col("month") != lead("month", 3).over(w_date)),
            lit(1)
        ).otherwise(lit(0)))
)

# Drop internal computation columns
drop_cols = [c for c in df_gold.columns if c.startswith("_")]
for c in drop_cols:
    df_gold = df_gold.drop(c)

# Also drop crude_stocks_52w_max/min (intermediate only)
df_gold = df_gold.drop("crude_stocks_52w_max", "crude_stocks_52w_min")

print(f"Features engineered. Total columns: {len(df_gold.columns)}")

# COMMAND ----------

# ── CELL 9 (REPLACE) ─────────────────────────────────────────────────────
# Changes:
# 1. TRAIN_END → 2021-12-31  (was 2019-12-31)
# 2. vol_regime_3 thresholds computed from 2017-2021 training window only
# 3. Target is xle_direction_5d (was direction_5d / Brent)
# 4. val_returns_1d uses xle_return_1d (was brent next_day_return)

TRAIN_END = '2021-12-31'    # ← changed from 2019-12-31
train_mask = df.trade_date <= TRAIN_END
val_mask   = df.trade_date >  TRAIN_END

# ── FIX: vol_regime_3 thresholds from training window ONLY ───────────────
train_brent_vol = df.loc[train_mask, 'brent_vol_20d']
VOL_Q33 = train_brent_vol.quantile(0.33)
VOL_Q67 = train_brent_vol.quantile(0.67)

# Recompute ternary regime with correct training-period thresholds
df['vol_regime_3'] = np.where(
    df['brent_vol_20d'] < VOL_Q33, 0,      # low vol
    np.where(df['brent_vol_20d'] > VOL_Q67, 2, 1)  # high / mid
)

print(f'Vol regime thresholds (2017-{TRAIN_END[:4]} training only):')
print(f'  Q33 (low/mid boundary)  : {VOL_Q33:.4f}')
print(f'  Q67 (mid/high boundary) : {VOL_Q67:.4f}')
print(f'  Expected approx: Q33≈0.0116, Q67≈0.0161')

# ── Build equity direction target ─────────────────────────────────────────
# Primary target: XLE 5-day direction (1=up, 0=down)
if 'xle_return_5d_fwd' in df.columns:
    df['xle_direction_5d'] = (df['xle_return_5d_fwd'] > 0).astype(float)
    df.loc[df['xle_return_5d_fwd'].isnull(), 'xle_direction_5d'] = np.nan
    TARGET_COL = 'xle_direction_5d'
else:
    # Fallback to Brent if equity CSV not available
    TARGET_COL = 'direction_5d'
    print('WARNING: xle_return_5d_fwd not found, falling back to Brent target')

print(f'\nTarget column: {TARGET_COL}')

REBALANCE_EVERY = 5
RETRAIN_EVERY   = 20
MIN_TRAIN_ROWS  = 200
TCOST           = 0.0002

val_dates = df.loc[val_mask, 'trade_date'].values

# val_returns_1d — use XLE daily return for P&L calculation
if 'xle_return_1d' in df.columns and val_mask.sum() > 0:
    val_returns_1d = df.loc[val_mask, 'xle_return_1d'].fillna(0).values
else:
    val_returns_1d = df.loc[val_mask, 'next_day_return'].fillna(0).values

scaler = StandardScaler()
scaler.fit(df.loc[train_mask, ALL_FEATURES])

def make_models():
    return {
        'lgbm': lgb.LGBMClassifier(
            n_estimators=300, max_depth=3, learning_rate=0.03,
            num_leaves=8, min_child_samples=30, subsample=0.7,
            colsample_bytree=0.6, reg_alpha=0.5, reg_lambda=0.5,
            random_state=42, verbose=-1),
        'xgb': xgb.XGBClassifier(
            n_estimators=300, max_depth=3, learning_rate=0.03,
            subsample=0.7, colsample_bytree=0.6, reg_alpha=0.5,
            reg_lambda=0.5, random_state=42, verbosity=0,
            eval_metric='logloss'),
        'catboost': CatBoostClassifier(
            iterations=300, depth=3, learning_rate=0.03,
            l2_leaf_reg=3.0, random_seed=42, verbose=0),
        'extra_trees': ExtraTreesClassifier(
            n_estimators=500, max_depth=5, min_samples_leaf=20,
            max_features=0.6, random_state=42),
        'ridge': RidgeClassifier(alpha=1.0),
    }

n_train = train_mask.sum()
n_val   = val_mask.sum()
print(f'\nSplit summary:')
print(f'  Train: 2017-01-03 → {TRAIN_END}  ({n_train:,} rows)')
print(f'  Val  : 2022-01-01 → 2023-12-31  ({n_val:,} rows)')
print(f'  Ratio: {n_train/n_val:.1f}× more training data than validation')

# Regime distribution in train and val
for split_name, mask in [('Train', train_mask), ('Val', val_mask)]:
    rc = df.loc[mask, 'vol_regime_3'].value_counts().sort_index()
    print(f'  {split_name} regime distribution: '
          f'regime0={rc.get(0,0)} | regime1={rc.get(1,0)} | regime2={rc.get(2,0)}')

print(f'\nModels: {list(make_models().keys())}')
print(f'Target: {TARGET_COL}')
print(f'P&L computed on: {"xle_return_1d" if "xle_return_1d" in df.columns else "brent_return_1d"}')

# COMMAND ----------

# ── CELL 10: Null audit ───────────────────────────────────────────────────

print("Null audit:\n")
print(f"  {'Column':<40} {'Nulls':>7}  {'%':>6}  Note")
print(f"  {'─'*65}")

null_issues = []
for c in df_final.columns:
    n_null = df_final.filter(isnull(col(c))).count()
    pct    = builtins.round(n_null / total * 100, 1)
    if n_null > 0:
        note = ""
        if c.endswith("_fwd"):
            note = "← expected (last N days have no future price)"
        elif pct > 20:
            note = "← INVESTIGATE"
            null_issues.append(c)
        print(f"  {c:<40} {n_null:>7,}  {pct:>5.1f}%  {note}")

print(f"\n  Columns needing investigation: {null_issues if null_issues else 'none'}")

# Fill feature nulls with 0 (not targets)
for c in feature_cols:
    df_final = df_final.fillna({c: 0})

print("\n  Feature nulls filled. Target nulls left as-is (handled in Colab).")

# COMMAND ----------

# ── CELL 11: Write Gold v2 Delta + validate ───────────────────────────────

print("Writing Gold feature store v2...")

df_final.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .save(GOLD_FEATURE_STORE_V2)

df_check = spark.read.format("delta").load(GOLD_FEATURE_STORE_V2)

print("=" * 65)
print("  GOLD FEATURE STORE V2 — VALIDATION")
print("=" * 65)

print(f"\n  Rows     : {df_check.count():,}")
print(f"  Columns  : {len(df_check.columns)}")

dr = df_check.agg(
    spark_min("trade_date").alias("first"),
    spark_max("trade_date").alias("last")
).collect()[0]
print(f"  Range    : {dr['first']} → {dr['last']}")

# RSI validation — should reach 70+ during 2022 Russia spike
print(f"\n  RSI-14 validation (was capped at 64 in v1):")
(df_check
    .select("trade_date", "brent_close", "brent_rsi14")
    .orderBy(col("brent_rsi14").desc())
    .limit(5)
    .show(truncate=False))

# Vol regime distribution
print(f"  Vol regime (ternary) distribution:")
(df_check.groupBy("vol_regime_3").count()
    .orderBy("vol_regime_3").show(truncate=False))

# Target coverage
print(f"  Target null counts (last N days expected to be null):")
for t in ["xle_return_5d_fwd", "xom_return_5d_fwd", "fro_return_5d_fwd"]:
    n = df_check.filter(isnull(col(t))).count()
    print(f"    {t:<30}: {n} nulls")

# Equity price sanity
print(f"\n  Equity price ranges:")
(df_check
    .filter(col("xle_close") > 0)
    .agg(
        spark_min("xle_close").alias("xle_min"),
        spark_max("xle_close").alias("xle_max"),
        spark_min("fro_close").alias("fro_min"),
        spark_max("fro_close").alias("fro_max"),
        spark_min("rig_count_us").alias("rig_min"),
        spark_max("rig_count_us").alias("rig_max"),
    )
    .show(truncate=False))

print("=" * 65)

# COMMAND ----------

# ── CELL 12: Export CSV for Colab ─────────────────────────────────────────

print("Exporting to CSV...")

export_path = f"{EXPORTS_DIR}/gold_features_v2_csv"

(df_final
    .coalesce(1)
    .write
    .format("csv")
    .option("header", "true")
    .mode("overwrite")
    .save(export_path))

csv_files = [
    f.path for f in dbutils.fs.ls(export_path)
    if f.path.endswith(".csv")
]
print(f"Exported: {csv_files[0]}")
print(f"\nDownload:")
print(f"  Catalog → workspace → oil_intel → project_data")
print(f"  → exports → gold_features_v2_csv → .csv → Download")
print(f"  Rename to: gold_features_v2.csv")

# Quick pandas check
import pandas as pd

local = (csv_files[0].replace("dbfs:", "")
         if csv_files[0].startswith("dbfs:")
         else f"/dbfs{csv_files[0]}"
         if not csv_files[0].startswith("/dbfs")
         else csv_files[0])

df_pd = pd.read_csv(local)
print(f"\nCSV check:")
print(f"  Rows    : {len(df_pd):,}")
print(f"  Columns : {len(df_pd.columns)}")
print(f"  Nulls   : {df_pd.isnull().sum().sum():,}")
print(f"\n  Column list:")
for i, c in enumerate(df_pd.columns):
    tag = " ← TARGET" if c.endswith("_fwd") or c == "spy_return_5d" else ""
    tag = " ← DROPPED OLD" if c in ["next_day_return",
                                      "next_day_direction"] else tag
    print(f"  {i+1:>2}. {c}{tag}")

# COMMAND ----------

