# Databricks notebook source
# =============================================================================
# Notebook: 11_silver_eia_macro_opec.py
# Purpose : Build EIA daily (forward-filled with leakage guard),
#           macro daily (FRED rf rate), and OPEC flags.
# Runtime : ~3 minutes
# =============================================================================
# ── CELL 1: Imports and paths ─────────────────────────────────────────────

import builtins
import pandas as pd
from pyspark.sql import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import (
    col, lag, lead, lit, when, coalesce,
    to_date, datediff, abs as spark_abs,
    round as spark_round, avg, last,
    min as spark_min, max as spark_max,
    year as spark_year, month as spark_month,
    first, count
)
from pyspark.sql.window import Window

spark = SparkSession.builder.getOrCreate()

VOL_BASE           = "/Volumes/workspace/oil_intel/project_data"
BRONZE_EIA         = f"{VOL_BASE}/bronze/eia"
BRONZE_FRED        = f"{VOL_BASE}/bronze/fred"
BRONZE_OPEC        = f"{VOL_BASE}/bronze/opec_events"
SILVER_DATE_SPINE  = f"{VOL_BASE}/silver/date_spine"
SILVER_EIA_DAILY   = f"{VOL_BASE}/silver/eia_daily"
SILVER_MACRO_DAILY = f"{VOL_BASE}/silver/macro_daily"
SILVER_OPEC_FLAGS  = f"{VOL_BASE}/silver/opec_flags"

print("Paths configured.")

# COMMAND ----------

# ── CELL 2: Load all inputs ───────────────────────────────────────────────

df_eia   = spark.read.format("delta").load(BRONZE_EIA)
df_fred  = spark.read.format("delta").load(BRONZE_FRED)
df_opec  = spark.read.format("delta").load(BRONZE_OPEC)
df_spine = spark.read.format("delta").load(SILVER_DATE_SPINE)

print(f"EIA rows   : {df_eia.count():,}")
print(f"FRED rows  : {df_fred.count():,}")
print(f"OPEC rows  : {df_opec.count():,}")
print(f"Spine rows : {df_spine.count():,}")

print("\nEIA series available:")
(df_eia.groupBy("series_id", "series_name")
    .count().orderBy("series_id").show(truncate=False))

print("\nOPEC events sample:")
df_opec.select(
    "event_date", "event_type", "outcome", "cut_size_mbbld"
).orderBy("event_date").show(20, truncate=False)

# COMMAND ----------

# ── CELL 3: Build EIA daily with leakage guard ────────────────────────────
# EIA releases weekly inventory data every WEDNESDAY at 10:30am ET.
# CRITICAL leakage rule:
#   - Wednesday release date: safe to use FROM Wednesday onward
#   - Monday and Tuesday of the SAME week: must use PRIOR week's value
#   - This prevents the model from seeing data before it was public

print("Building EIA daily with Wednesday release leakage guard...")

# Pivot EIA from long to wide — one row per release date
series_ids = [row["series_id"] for row in
              df_eia.select("series_id").distinct().collect()]
print(f"Series to pivot: {series_ids}")

# Pivot to wide format
df_eia_wide = (df_eia
    .groupBy("period")
    .pivot("series_id", series_ids)
    .agg(first("value"))
    .withColumnRenamed("period", "release_date")
    .orderBy("release_date")
)

print(f"EIA wide rows: {df_eia_wide.count()}")
df_eia_wide.limit(3).show(truncate=False)

# COMMAND ----------

# ── CELL 4: Forward-fill EIA to daily with leakage guard ─────────────────

# Join EIA release dates to full date spine
# EIA reports on Wednesdays — each Wednesday's data covers
# the week ending that Wednesday

df_eia_dates = df_eia_wide.withColumn(
    "release_date", to_date(col("release_date"))
)

# Join spine to EIA — left join means non-release days get null
df_eia_joined = (df_spine
    .select("trade_date", "year", "month", "yyyymm",
            "is_trading_day", "day_of_week")
    .withColumn("trade_date_parsed", to_date(col("trade_date")))
    .join(
        df_eia_dates.withColumn(
            "trade_date_parsed", col("release_date")),
        on="trade_date_parsed",
        how="left"
    )
    .drop("trade_date_parsed", "release_date")
)

# Forward-fill using last known value
# But apply leakage guard: Mon(0) and Tue(1) use PRIOR week's value
# Wed(2) through Fri(4) use current week's value
w_ffill = Window.orderBy("trade_date").rowsBetween(
    Window.unboundedPreceding, 0
)

# First forward-fill all series
eia_cols = [c for c in df_eia_wide.columns if c != "release_date"]
df_eia_filled = df_eia_joined
for c in eia_cols:
    df_eia_filled = df_eia_filled.withColumn(
        c, last(col(c), ignorenulls=True).over(w_ffill)
    )

# Apply leakage guard — Mon/Tue use lagged (prior week) value
# We lag by 7 days to get the prior Wednesday's release
w_lag = Window.orderBy("trade_date")
for c in eia_cols:
    df_eia_filled = df_eia_filled.withColumn(
        f"{c}_prior",
        lag(c, 7).over(w_lag)
    ).withColumn(
        c,
        when(
            col("day_of_week").isin(0, 1),  # Mon=0, Tue=1
            col(f"{c}_prior")
        ).otherwise(col(c))
    ).drop(f"{c}_prior")

# Compute inventory surprise — actual change vs rolling 4-week avg change
# Only meaningful for stock series
w_4wk = Window.orderBy("trade_date").rowsBetween(-27, 0)
if "WCRSTUS1" in eia_cols:
    df_eia_filled = (df_eia_filled
        .withColumn("crude_stock_change_1w",
            col("WCRSTUS1") - lag("WCRSTUS1", 7).over(w_lag))
        .withColumn("crude_stock_change_4w_avg",
            avg("crude_stock_change_1w").over(w_4wk))
        .withColumn("inventory_surprise",
            col("crude_stock_change_1w") -
            col("crude_stock_change_4w_avg"))
    )

# Rename to friendly names
rename_map = {
    "WCRSTUS1": "us_crude_stocks",
    "WCSSTUS1": "spr_stocks",
    "WTTSTUS1": "total_petroleum_stocks",
    "WCRFPUS2": "us_production",
    "WCRRIUS2": "refinery_utilisation",
    "WCRIMUS2": "imports",
    "WCREXUS2": "exports",
}
for old_name, new_name in rename_map.items():
    if old_name in df_eia_filled.columns:
        df_eia_filled = df_eia_filled.withColumnRenamed(
            old_name, new_name)

# Net flow = production + imports - exports
if all(c in df_eia_filled.columns
       for c in ["us_production","imports","exports"]):
    df_eia_filled = df_eia_filled.withColumn(
        "net_supply_flow",
        col("us_production") + col("imports") - col("exports")
    )

total = df_eia_filled.count()
print(f"EIA daily rows: {total:,}  (expected: 2,556)")
print(f"Columns: {len(df_eia_filled.columns)}")

# COMMAND ----------

# ── CELL 5: Write EIA daily ───────────────────────────────────────────────

# Select final columns
eia_final_cols = [
    "trade_date", "year", "month", "yyyymm",
    "is_trading_day", "day_of_week",
]
# Add all renamed EIA columns
for c in ["us_crude_stocks","spr_stocks","total_petroleum_stocks",
          "us_production","refinery_utilisation","imports","exports",
          "net_supply_flow","crude_stock_change_1w",
          "crude_stock_change_4w_avg","inventory_surprise"]:
    if c in df_eia_filled.columns:
        eia_final_cols.append(c)

df_eia_silver = df_eia_filled.select(eia_final_cols)

df_eia_silver.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .save(SILVER_EIA_DAILY)

count = spark.read.format("delta").load(SILVER_EIA_DAILY).count()
print(f"EIA daily written: {count:,} rows → {SILVER_EIA_DAILY}")

# Quick validation
print("\nEIA daily sample (first 5 trading days):")
(spark.read.format("delta").load(SILVER_EIA_DAILY)
    .filter(col("is_trading_day") == 1)
    .select("trade_date", "us_crude_stocks", "us_production",
            "imports", "exports", "inventory_surprise")
    .orderBy("trade_date")
    .limit(5)
    .show(truncate=False))

# COMMAND ----------

# ── CELL 6: Build macro daily — FRED RF rate ─────────────────────────────

print("Building macro daily from FRED TB3MS...")

# FRED reports monthly — forward-fill to daily
df_fred_dated = (df_fred
    .withColumn("period_date", to_date(col("period")))
    .select("period_date", col("value").alias("tb3ms_pct"))
    .orderBy("period_date")
)

df_macro_joined = (df_spine
    .select("trade_date", "year", "month", "yyyymm",
            "is_trading_day", "is_weekend", "is_holiday")
    .withColumn("trade_date_parsed", to_date(col("trade_date")))
    .join(
        df_fred_dated.withColumn(
            "trade_date_parsed", col("period_date")),
        on="trade_date_parsed",
        how="left"
    )
    .drop("trade_date_parsed", "period_date")
)

w_ffill = Window.orderBy("trade_date").rowsBetween(
    Window.unboundedPreceding, 0
)

df_macro = (df_macro_joined
    .withColumn("tb3ms_pct",
        last(col("tb3ms_pct"), ignorenulls=True).over(w_ffill))
    # Daily risk-free rate = annual rate / 100 / 252
    .withColumn("rf_daily",
        spark_round(col("tb3ms_pct") / 100.0 / 252.0, 8))
)

print(f"Macro daily rows: {df_macro.count():,}")

df_macro.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .save(SILVER_MACRO_DAILY)

count = spark.read.format("delta").load(SILVER_MACRO_DAILY).count()
print(f"Macro daily written: {count:,} rows → {SILVER_MACRO_DAILY}")

print("\nMacro daily sample:")
(spark.read.format("delta").load(SILVER_MACRO_DAILY)
    .filter(col("is_trading_day") == 1)
    .select("trade_date", "tb3ms_pct", "rf_daily")
    .orderBy("trade_date")
    .limit(5)
    .show(truncate=False))

print("\nYearly average risk-free rate:")
(spark.read.format("delta").load(SILVER_MACRO_DAILY)
    .filter(col("is_trading_day") == 1)
    .groupBy("year")
    .agg(spark_round(avg("tb3ms_pct"), 3).alias("avg_tb3ms_pct"),
         spark_round(avg("rf_daily"), 8).alias("avg_rf_daily"))
    .orderBy("year")
    .show(truncate=False))

# COMMAND ----------

# ── CELL 7: Build OPEC flags ──────────────────────────────────────────────

print("Building OPEC flags...")

# Load OPEC events and parse dates
df_opec_dated = (df_opec
    .withColumn("event_date_parsed", to_date(col("event_date")))
    .select(
        col("event_date_parsed").alias("event_date"),
        col("outcome"),
        col("cut_size_mbbld"),
    )
    .filter(col("event_date").isNotNull())
    .orderBy("event_date")
)

print(f"OPEC events parsed: {df_opec_dated.count()}")
df_opec_dated.show(truncate=False)

# COMMAND ----------

# ── CELL 8: Join OPEC events to date spine ────────────────────────────────

# For each calendar day compute:
# 1. days_to_next_opec   — how many days until next OPEC meeting
# 2. days_since_opec     — how many days since last OPEC meeting
# 3. opec_week_flag      — 1 if within 7 days of any meeting
# 4. post_opec_flag      — 1 if within 3 days AFTER a meeting
# 5. opec_cut_flag       — 1 if most recent decision was a cut
#
# NOTE: days_to_next_opec uses pre-announced meeting dates.
# This is NOT leakage — OPEC announces meeting dates months in advance.

# Convert to pandas for the cross-join date math (small dataset)
opec_pd = df_opec_dated.toPandas()
opec_pd["event_date"] = pd.to_datetime(opec_pd["event_date"])
opec_dates = opec_pd["event_date"].tolist()

spine_pd = df_spine.select(
    "trade_date", "year", "month", "yyyymm",
    "is_trading_day", "is_weekend", "is_holiday"
).toPandas()
spine_pd["trade_date_dt"] = pd.to_datetime(spine_pd["trade_date"])

def compute_opec_flags(row, opec_dates, opec_pd):
    td = row["trade_date_dt"]

    future_dates = [d for d in opec_dates if d >= td]
    past_dates   = [d for d in opec_dates if d <= td]

    days_to_next = (builtins.min(future_dates) - td).days \
        if future_dates else 365
    days_since   = (td - builtins.max(past_dates)).days \
        if past_dates else 365

    opec_week_flag = 1 if (days_to_next <= 7 or days_since <= 7) else 0
    post_opec_flag = 1 if days_since <= 3 else 0

    # Most recent OPEC outcome
    past_events = opec_pd[opec_pd["event_date"] <= td]
    if len(past_events) > 0:
        last_outcome  = past_events.iloc[-1]["outcome"]
        last_cut_size = past_events.iloc[-1]["cut_size_mbbld"]
    else:
        last_outcome  = ""
        last_cut_size = 0.0

    opec_cut_flag  = 1 if last_outcome == "CUT"      else 0
    opec_hold_flag = 1 if last_outcome == "HOLD"     else 0
    opec_hike_flag = 1 if last_outcome == "INCREASE" else 0

    return pd.Series({
        "days_to_next_opec":  days_to_next,
        "days_since_opec":    days_since,
        "opec_week_flag":     opec_week_flag,
        "post_opec_flag":     post_opec_flag,
        "opec_cut_flag":      opec_cut_flag,
        "opec_hold_flag":     opec_hold_flag,
        "opec_hike_flag":     opec_hike_flag,
        "last_opec_outcome":  last_outcome,
        "last_cut_size_mbbld": float(last_cut_size)
                               if last_cut_size is not None else 0.0,
    })

print("Computing OPEC flags for all 2,556 dates...")
import warnings
warnings.filterwarnings("ignore")

opec_flags = spine_pd.apply(
    compute_opec_flags, axis=1,
    args=(opec_dates, opec_pd)
)
df_opec_flags_pd = pd.concat([spine_pd, opec_flags], axis=1)
df_opec_flags_pd = df_opec_flags_pd.drop(columns=["trade_date_dt"])

print(f"OPEC flags computed: {len(df_opec_flags_pd)} rows")
print(df_opec_flags_pd[["trade_date","days_to_next_opec",
                          "opec_week_flag","last_opec_outcome"
                          ]].head(8).to_string(index=False))

# COMMAND ----------

# ── CELL 9: Write OPEC flags ──────────────────────────────────────────────

opec_schema = StructType([
    StructField("trade_date",          StringType(),  True),
    StructField("year",                IntegerType(), True),
    StructField("month",               IntegerType(), True),
    StructField("yyyymm",              StringType(),  True),
    StructField("is_trading_day",      IntegerType(), True),
    StructField("is_weekend",          IntegerType(), True),
    StructField("is_holiday",          IntegerType(), True),
    StructField("days_to_next_opec",   IntegerType(), True),
    StructField("days_since_opec",     IntegerType(), True),
    StructField("opec_week_flag",      IntegerType(), True),
    StructField("post_opec_flag",      IntegerType(), True),
    StructField("opec_cut_flag",       IntegerType(), True),
    StructField("opec_hold_flag",      IntegerType(), True),
    StructField("opec_hike_flag",      IntegerType(), True),
    StructField("last_opec_outcome",   StringType(),  True),
    StructField("last_cut_size_mbbld", DoubleType(),  True),
])

# Coerce types
for c in ["days_to_next_opec","days_since_opec","opec_week_flag",
          "post_opec_flag","opec_cut_flag","opec_hold_flag",
          "opec_hike_flag","year","month","is_trading_day",
          "is_weekend","is_holiday"]:
    df_opec_flags_pd[c] = df_opec_flags_pd[c].fillna(0).astype(int)
df_opec_flags_pd["last_cut_size_mbbld"] = (
    df_opec_flags_pd["last_cut_size_mbbld"].fillna(0.0).astype(float))
df_opec_flags_pd["last_opec_outcome"] = (
    df_opec_flags_pd["last_opec_outcome"].fillna("").astype(str))
df_opec_flags_pd["trade_date"] = (
    df_opec_flags_pd["trade_date"].astype(str))
df_opec_flags_pd["yyyymm"] = (
    df_opec_flags_pd["yyyymm"].astype(str))

df_opec_spark = spark.createDataFrame(df_opec_flags_pd, schema=opec_schema)

df_opec_spark.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .save(SILVER_OPEC_FLAGS)

count = spark.read.format("delta").load(SILVER_OPEC_FLAGS).count()
print(f"OPEC flags written: {count:,} rows → {SILVER_OPEC_FLAGS}")

# COMMAND ----------

# ── CELL 10: Final validation — all three tables ──────────────────────────

print("=" * 60)
print("  NOTEBOOK 11 — FINAL VALIDATION")
print("=" * 60)

# EIA daily
df_eia_s = spark.read.format("delta").load(SILVER_EIA_DAILY)
eia_nulls = df_eia_s.filter(
    col("is_trading_day") == 1
).filter(col("us_crude_stocks").isNull()).count()
print(f"\n  EIA daily rows       : {df_eia_s.count():,}")
print(f"  Null crude stocks    : {eia_nulls}  "
      f"{'[PASS]' if eia_nulls == 0 else '[WARN]'}")
print(f"\n  EIA yearly avg crude stocks (Mbbl):")
(df_eia_s.filter(col("is_trading_day") == 1)
    .groupBy("year")
    .agg(spark_round(avg("us_crude_stocks"), 0).alias("avg_stocks_mbbl"),
         spark_round(avg("inventory_surprise"), 2)
             .alias("avg_inv_surprise"))
    .orderBy("year").show(truncate=False))

# Macro daily
df_mac = spark.read.format("delta").load(SILVER_MACRO_DAILY)
print(f"\n  Macro daily rows     : {df_mac.count():,}")
print(f"\n  RF rate by year:")
(df_mac.filter(col("is_trading_day") == 1)
    .groupBy("year")
    .agg(spark_round(avg("tb3ms_pct"), 3).alias("tb3ms_pct"))
    .orderBy("year").show(truncate=False))

# OPEC flags
df_opec_s = spark.read.format("delta").load(SILVER_OPEC_FLAGS)
print(f"\n  OPEC flags rows      : {df_opec_s.count():,}")
print(f"\n  OPEC outcome distribution:")
(df_opec_s.filter(col("is_trading_day") == 1)
    .groupBy("last_opec_outcome").count()
    .orderBy("count", ascending=False).show(truncate=False))

opec_week_days = df_opec_s.filter(
    (col("is_trading_day") == 1) &
    (col("opec_week_flag") == 1)
).count()
post_opec_days = df_opec_s.filter(
    (col("is_trading_day") == 1) &
    (col("post_opec_flag") == 1)
).count()
print(f"  OPEC week flag days  : {opec_week_days}")
print(f"  Post-OPEC flag days  : {post_opec_days}")

print(f"\n  Key OPEC events visible in data:")
(df_opec_s
    .filter(col("post_opec_flag") == 1)
    .select("trade_date", "last_opec_outcome",
            "last_cut_size_mbbld", "days_since_opec")
    .filter(col("last_cut_size_mbbld") > 1.0)
    .orderBy("trade_date")
    .show(10, truncate=False))

print("=" * 60)
print("  Silver layer COMPLETE if all three tables show 2,556 rows.")
print("  Proceed to Notebook 12 — Gold Feature Store.")
print("=" * 60)