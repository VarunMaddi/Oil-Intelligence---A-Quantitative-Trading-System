# Databricks notebook source
# =============================================================================
# Notebook: 09_silver_gaps_daily.py
# Purpose : Aggregate AIS gap events to daily dark fleet index per region.
#           AIS gaps = transponder switched off = potential sanctions evasion.
# Runtime : ~3 minutes
# =============================================================================
# ── CELL 1: Imports and paths ─────────────────────────────────────────────

import builtins
from pyspark.sql import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import (
    col, to_date, to_timestamp, lit, when, coalesce,
    count, countDistinct, avg, sum as spark_sum,
    min as spark_min, max as spark_max,
    round as spark_round, first,
    explode, sequence, datediff, expr
)

spark = SparkSession.builder.getOrCreate()

VOL_BASE            = "/Volumes/workspace/oil_intel/project_data"
BRONZE_AIS_GAPS     = f"{VOL_BASE}/bronze/gfw_ais_gaps"
SILVER_DATE_SPINE   = f"{VOL_BASE}/silver/date_spine"
SILVER_GAPS_DAILY   = f"{VOL_BASE}/silver/ais_gaps_daily"

print(f"Input  : {BRONZE_AIS_GAPS}")
print(f"Output : {SILVER_GAPS_DAILY}")

# COMMAND ----------

# ── CELL 2: Load and inspect ──────────────────────────────────────────────

df_gaps  = spark.read.format("delta").load(BRONZE_AIS_GAPS)
df_spine = (spark.read.format("delta").load(SILVER_DATE_SPINE)
    .select("trade_date", "year", "month", "yyyymm",
            "is_trading_day", "is_weekend", "is_holiday"))

print(f"AIS gaps rows  : {df_gaps.count():,}")
print(f"Date spine rows: {df_spine.count():,}")

print("\nSample gap rows:")
df_gaps.select(
    "event_id", "mmsi", "vessel_type", "flag",
    "start_ts", "end_ts",
    "off_lat", "off_lon", "on_lat", "on_lon",
    "gap_hours", "implied_dist_km", "positions_before",
    "region_eez"
).limit(5).show(truncate=False)

# COMMAND ----------

# ── CELL 2: Load and inspect ──────────────────────────────────────────────

df_gaps  = spark.read.format("delta").load(BRONZE_AIS_GAPS)
df_spine = (spark.read.format("delta").load(SILVER_DATE_SPINE)
    .select("trade_date", "year", "month", "yyyymm",
            "is_trading_day", "is_weekend", "is_holiday"))

print(f"AIS gaps rows  : {df_gaps.count():,}")
print(f"Date spine rows: {df_spine.count():,}")

print("\nSample gap rows:")
df_gaps.select(
    "event_id", "mmsi", "vessel_type", "flag",
    "start_ts", "end_ts",
    "off_lat", "off_lon", "on_lat", "on_lon",
    "gap_hours", "implied_dist_km", "positions_before",
    "region_eez"
).limit(5).show(truncate=False)

# COMMAND ----------

# ── CELL 3 (UPDATED): Parse, filter and classify gap events ───────────────

# EEZ codes confirmed from port visits crosswalk
MIDDLE_EAST_EEZ = ["8354", "8353", "8333", "8346"]
                   # OMN    YEM     IND     LKA (Arabian Sea / Indian Ocean)
WEST_AFRICA_EEZ = ["8474", "8473", "8400", "8396"]
                   # NGA    CIV     GHA     ZAF
BLACK_SEA_EEZ   = ["5690", "48950"]
                   # RUS Black Sea, RUS Baltic/Arctic
NORTH_SEA_EEZ   = ["5686"]
                   # NOR
US_GULF_EEZ     = ["8429"]
                   # MEX (Gulf of Mexico)
MEDITERRANEAN_EEZ = ["8490", "5693"]
                     # EGY    ESP

df_classified = (df_gaps
    .withColumn("start_date",
        to_date(to_timestamp(col("start_ts"))))
    .withColumn("end_date",
        to_date(to_timestamp(col("end_ts"))))
    .filter(
        (col("start_date") >= "2017-01-01") &
        (col("start_date") <= "2023-12-31")
    )
    .withColumn("gap_region",
        when(col("region_eez").isin(MIDDLE_EAST_EEZ),    "middle_east")
        .when(col("region_eez").isin(WEST_AFRICA_EEZ),    "west_africa")
        .when(col("region_eez").isin(BLACK_SEA_EEZ),      "black_sea")
        .when(col("region_eez").isin(NORTH_SEA_EEZ),      "north_sea")
        .when(col("region_eez").isin(US_GULF_EEZ),        "us_gulf")
        .when(col("region_eez").isin(MEDITERRANEAN_EEZ),  "mediterranean")
        .otherwise("other")
    )
    .withColumn("gap_severity",
        when(col("gap_hours").isNull(),          "unknown")
        .when(col("gap_hours") < 6,              "short")
        .when(col("gap_hours").between(6, 24),   "medium")
        .when(col("gap_hours").between(24, 168), "long")
        .when(col("gap_hours") > 168,            "extended")
        .otherwise("unknown")
    )
    .withColumn("is_dark_event",
        when(
            col("gap_hours").isNull() |
            (col("gap_hours") >= 24),
            lit(1)
        ).otherwise(lit(0))
    )
)

print(f"Filtered rows: {df_classified.count():,}")

print("\nGap region distribution:")
(df_classified.groupBy("gap_region").count()
    .orderBy("count", ascending=False).show(truncate=False))

print("\nGap severity distribution:")
(df_classified.groupBy("gap_severity").count()
    .orderBy("count", ascending=False).show(truncate=False))

# COMMAND ----------

# ── CELL 4: Expand gap events to daily rows ───────────────────────────────

print("Expanding gap events to daily rows...")

df_expanded = (df_classified
    .withColumn("end_date",
        when(col("end_date").isNull(), col("start_date"))
        .when(col("end_date") > "2023-12-31",
              to_date(lit("2023-12-31")))
        .otherwise(col("end_date"))
    )
    .withColumn("duration_days",
        datediff(col("end_date"), col("start_date")) + 1
    )
    # Cap at 90 days (extended dark fleet operations)
    .filter(col("duration_days") <= 90)
    .withColumn("active_dates",
        sequence(col("start_date"), col("end_date"),
                 expr("interval 1 day"))
    )
    .withColumn("active_date", explode(col("active_dates")))
    .withColumn("active_date",
        col("active_date").cast("string").substr(1, 10))
    .filter(
        (col("active_date") >= "2017-01-01") &
        (col("active_date") <= "2023-12-31")
    )
)

print(f"Expanded rows: {df_expanded.count():,}")

# COMMAND ----------

# ── CELL 5 (FIXED): Aggregate to daily ────────────────────────────────────

from pyspark.sql.functions import count as spark_count

print("Aggregating to daily gap counts...")

# Global daily
df_global = (df_expanded
    .groupBy("active_date")
    .agg(
        spark_count("event_id").alias("global_gap_count"),
        countDistinct("mmsi").alias("global_gap_vessels"),
        spark_sum("is_dark_event").alias("global_dark_events"),
        avg("gap_hours").alias("avg_gap_hours"),
        avg("implied_dist_km").alias("avg_implied_dist_km"),
    )
    .withColumnRenamed("active_date", "trade_date")
)

# Per-region daily
df_region = (df_expanded
    .filter(col("gap_region") != "other")
    .groupBy("active_date", "gap_region")
    .agg(
        spark_count("event_id").alias("gap_count"),
        countDistinct("mmsi").alias("gap_vessels"),
        spark_sum("is_dark_event").alias("dark_events"),
    )
    .withColumnRenamed("active_date", "trade_date")
)

# Pivot to wide
df_pivot_gap = (df_region
    .groupBy("trade_date")
    .pivot("gap_region", [
        "middle_east","west_africa","black_sea",
        "north_sea","us_gulf","mediterranean"
    ])
    .agg(first("gap_count"))
)
for r in ["middle_east","west_africa","black_sea",
          "north_sea","us_gulf","mediterranean"]:
    if r in df_pivot_gap.columns:
        df_pivot_gap = df_pivot_gap.withColumnRenamed(
            r, f"{r}_gap_count")

df_pivot_dark = (df_region
    .groupBy("trade_date")
    .pivot("gap_region", [
        "middle_east","west_africa","black_sea",
        "north_sea","us_gulf","mediterranean"
    ])
    .agg(first("dark_events"))
)
for r in ["middle_east","west_africa","black_sea",
          "north_sea","us_gulf","mediterranean"]:
    if r in df_pivot_dark.columns:
        df_pivot_dark = df_pivot_dark.withColumnRenamed(
            r, f"{r}_dark_events")

df_wide = (df_pivot_gap
    .join(df_pivot_dark, on="trade_date", how="left")
    .join(df_global,     on="trade_date", how="left")
)

print(f"Wide format rows: {df_wide.count():,}")

# COMMAND ----------

# ── CELL 6: Join to date spine and fill nulls ─────────────────────────────

df_final = df_spine.join(df_wide, on="trade_date", how="left")

count_cols = [c for c in df_final.columns
              if c.endswith(("_count", "_events", "_vessels"))]
num_cols   = [c for c in df_final.columns
              if c.endswith(("_hours", "_km"))]

for c in count_cols:
    df_final = df_final.fillna({c: 0})
for c in num_cols:
    df_final = df_final.fillna({c: 0.0})

# Total oil region dark fleet index
oil_dark_cols = [
    "middle_east_dark_events", "west_africa_dark_events",
    "black_sea_dark_events",   "north_sea_dark_events",
    "us_gulf_dark_events"
]
df_final = df_final.withColumn(
    "total_oil_dark_fleet_index",
    builtins.sum([col(c) for c in oil_dark_cols])
)

# Total oil region gap count
oil_gap_cols = [
    "middle_east_gap_count", "west_africa_gap_count",
    "black_sea_gap_count",   "north_sea_gap_count",
    "us_gulf_gap_count"
]
df_final = df_final.withColumn(
    "total_oil_region_gap_count",
    builtins.sum([col(c) for c in oil_gap_cols])
)

total = df_final.count()
print(f"Final rows: {total:,}  (expected: 2,556)")
print(f"Columns   : {len(df_final.columns)}")

# COMMAND ----------

# ── CELL 7: Write to Delta ────────────────────────────────────────────────

df_final.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .save(SILVER_GAPS_DAILY)

count = spark.read.format("delta").load(SILVER_GAPS_DAILY).count()
print(f"Written: {count:,} rows → {SILVER_GAPS_DAILY}")

# COMMAND ----------

# ── CELL 8: Validation ────────────────────────────────────────────────────

df = spark.read.format("delta").load(SILVER_GAPS_DAILY)

print("=" * 60)
print("  SILVER AIS GAPS DAILY — VALIDATION")
print("=" * 60)

total = df.count()
print(f"\n  Total rows : {total}  "
      f"{'[PASS]' if total == 2556 else '[FAIL]'}")

print(f"\n  Sample trading days:")
(df.filter(col("is_trading_day") == 1)
    .select(
        "trade_date",
        "global_gap_count",
        "global_dark_events",
        "middle_east_gap_count",
        "black_sea_gap_count",
        "total_oil_dark_fleet_index",
        "avg_gap_hours"
    )
    .orderBy("trade_date")
    .limit(10)
    .show(truncate=False))

print(f"\n  Yearly dark fleet index (oil regions):")
(df.filter(col("is_trading_day") == 1)
    .groupBy("year")
    .agg(
        spark_round(avg("global_gap_count"), 1)
            .alias("avg_daily_gaps"),
        spark_round(avg("total_oil_dark_fleet_index"), 1)
            .alias("avg_oil_dark_index"),
        spark_round(avg("black_sea_gap_count"), 2)
            .alias("avg_black_sea_gaps")
    )
    .orderBy("year")
    .show(truncate=False))

print("=" * 60)
print("  Key signal: black_sea_gap_count should spike in 2022-2023")
print("  after Russia-Ukraine war and sanctions on Russian crude.")
print("=" * 60)

# COMMAND ----------

# ── Diagnose: find what EEZ codes exist in gaps data ─────────────────────

VOL_BASE        = "/Volumes/workspace/oil_intel/project_data"
BRONZE_AIS_GAPS = f"{VOL_BASE}/bronze/gfw_ais_gaps"

df_gaps = spark.read.format("delta").load(BRONZE_AIS_GAPS)

# Check what region_eez values exist overall
print("All unique region_eez values in gaps data:")
(df_gaps
    .filter(col("region_eez") != "")
    .groupBy("region_eez").count()
    .orderBy("count", ascending=False)
    .limit(40)
    .show(truncate=False))

# Check specifically for Russian-flagged vessels
print("\nRussian flagged vessel gap events:")
(df_gaps
    .filter(col("flag") == "RUS")
    .groupBy("region_eez", "flag").count()
    .orderBy("count", ascending=False)
    .show(truncate=False))

# Check vessels operating near Novorossiysk/Primorsk coordinates
# Black Sea approx: lat 41-47, lon 28-42
print("\nGap events in Black Sea coordinates:")
(df_gaps
    .filter(
        col("off_lat").between(41, 47) &
        col("off_lon").between(28, 42)
    )
    .groupBy("region_eez", "flag").count()
    .orderBy("count", ascending=False)
    .show(20, truncate=False))

# COMMAND ----------

VOL_BASE = "/Volumes/workspace/oil_intel/project_data"

top_gap_eez = ["8487","8492","8480","8353","8464","8400","8396",
               "8322","5690","8323","8429","8348","8354","8343",
               "8474","8346","8490","8473","8333","8316",
               "5686","48950","5693"]

(spark.read.format("delta")
    .load(f"{VOL_BASE}/bronze/gfw_port_visits")
    .filter(
        col("region_eez").isin(top_gap_eez) &
        (col("start_port_country") != "")
    )
    .groupBy("region_eez", "start_port_country")
    .count()
    .orderBy("region_eez", "count", ascending=[True, False])
    .show(60, truncate=False))

# COMMAND ----------

