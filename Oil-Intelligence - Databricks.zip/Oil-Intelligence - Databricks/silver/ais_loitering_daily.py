# Databricks notebook source
# =============================================================================
# Notebook: 08_silver_loitering_daily.py
# Purpose : Aggregate loitering events to daily counts per region.
#           Loitering = vessels drifting slowly, often waiting for berth
#           or conducting STS transfers. High loitering = supply congestion.
# Runtime : ~5 minutes
# =============================================================================
# ── CELL 1: Imports and paths ─────────────────────────────────────────────

import builtins
from pyspark.sql import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import (
    col, to_date, to_timestamp, lit, when, coalesce,
    count, countDistinct, avg, sum as spark_sum,
    min as spark_min, max as spark_max,
    round as spark_round, year as spark_year,
    month as spark_month, substring, first,
    explode, sequence, datediff, expr
)
from pyspark.sql.window import Window

spark = SparkSession.builder.getOrCreate()

VOL_BASE                = "/Volumes/workspace/oil_intel/project_data"
BRONZE_LOITERING        = f"{VOL_BASE}/bronze/gfw_loitering"
SILVER_DATE_SPINE       = f"{VOL_BASE}/silver/date_spine"
SILVER_LOITERING_DAILY  = f"{VOL_BASE}/silver/ais_loitering_daily"

print(f"Input  : {BRONZE_LOITERING}")
print(f"Output : {SILVER_LOITERING_DAILY}")

# COMMAND ----------

# ── CELL 2: Load inputs ───────────────────────────────────────────────────

df_loit  = spark.read.format("delta").load(BRONZE_LOITERING)
df_spine = (spark.read.format("delta").load(SILVER_DATE_SPINE)
    .select("trade_date", "year", "month", "yyyymm",
            "is_trading_day", "is_weekend", "is_holiday"))

print(f"Loitering rows : {df_loit.count():,}")
print(f"Date spine rows: {df_spine.count():,}")

# Inspect actual loitering event structure
print("\nSample loitering rows:")
df_loit.select(
    "event_id", "mmsi", "vessel_type", "flag",
    "start_ts", "end_ts", "lat", "lon",
    "duration_hrs", "avg_speed_knots", "total_dist_km",
    "region_eez"
).limit(5).show(truncate=False)

# COMMAND ----------

# ── CELL 3: Parse and classify loitering events ───────────────────────────
# Classify each loitering event as:
# - terminal_congestion: near a known oil loading region (by EEZ)
# - open_water_sts: likely ship-to-ship transfer in open water
# - other: unclassified

# EEZ codes for key oil regions from GFW data
MIDDLE_EAST_EEZ  = ["8376","8441","8403","8492","8479","8453","8403",
                     "8492","8376","8384","8377"]
WEST_AFRICA_EEZ  = ["8492","8384","8385","8386","8387","8388","8389",
                     "8390","8391","8427","8428","8429"]
BLACK_SEA_EEZ    = ["8327","8328","8329","8330"]
NORTH_SEA_EEZ    = ["8367","8368","8369","8370","8371","8372","8373",
                     "8374","8375"]
US_GULF_EEZ      = ["8386","8387"]

df_classified = (df_loit
    .withColumn("start_date",
        to_date(to_timestamp(col("start_ts"))))
    .withColumn("end_date",
        to_date(to_timestamp(col("end_ts"))))
    .filter(
        (col("start_date") >= "2017-01-01") &
        (col("start_date") <= "2023-12-31")
    )
    # Classify by EEZ region
    .withColumn("loitering_region",
        when(col("region_eez").isin(MIDDLE_EAST_EEZ),  "middle_east")
        .when(col("region_eez").isin(WEST_AFRICA_EEZ),  "west_africa")
        .when(col("region_eez").isin(BLACK_SEA_EEZ),    "black_sea")
        .when(col("region_eez").isin(NORTH_SEA_EEZ),    "north_sea")
        .when(col("region_eez").isin(US_GULF_EEZ),      "us_gulf")
        .otherwise("other")
    )
    # Classify event type
    # STS transfers tend to have low speed + high distance (drifting)
    # Terminal congestion tends to be stationary near port coords
    .withColumn("event_class",
        when(
            (col("avg_speed_knots") < 0.5) &
            (col("total_dist_km") < 5),
            "stationary"
        ).when(
            (col("avg_speed_knots").between(0.5, 2.0)) &
            (col("total_dist_km") > 5),
            "slow_drift"
        ).otherwise("other")
    )
)

print(f"Filtered rows : {df_classified.count():,}")

print("\nLoitering region distribution:")
(df_classified.groupBy("loitering_region").count()
    .orderBy("count", ascending=False).show(truncate=False))

print("\nEvent class distribution:")
(df_classified.groupBy("event_class").count()
    .orderBy("count", ascending=False).show(truncate=False))

# COMMAND ----------

# ── CELL 4: Expand loitering events to daily rows ─────────────────────────
# Like port visits, a loitering event spanning multiple days contributes
# to each day it is active.

print("Expanding loitering events to daily rows...")

df_expanded = (df_classified
    .withColumn("end_date",
        when(col("end_date").isNull(), col("start_date"))
        .when(col("end_date") > "2023-12-31",
              to_date(lit("2023-12-31")))
        .otherwise(col("end_date"))
    )
    .withColumn("duration_days",
        datediff(col("end_date"), col("start_date")) + 1
    )
    # Cap at 60 days for loitering (some sanctions evasion events are long)
    .filter(col("duration_days") <= 60)
    .withColumn("active_dates",
        sequence(col("start_date"), col("end_date"),
                 expr("interval 1 day"))
    )
    .withColumn("active_date", explode(col("active_dates")))
    .withColumn("active_date",
        col("active_date").cast("string").substr(1, 10))
    .filter(
        (col("active_date") >= "2017-01-01") &
        (col("active_date") <= "2023-12-31")
    )
)

print(f"Expanded rows: {df_expanded.count():,}")

# COMMAND ----------

# ── CELL 5: Aggregate to daily ────────────────────────────────────────────

print("Aggregating to daily loitering counts...")

# Global daily loitering
df_global = (df_expanded
    .groupBy("active_date")
    .agg(
        count("event_id").alias("global_loitering_count"),
        countDistinct("mmsi").alias("global_loitering_vessels"),
        avg("duration_hrs").alias("avg_loitering_duration_hrs"),
        spark_sum(
            when(col("event_class") == "stationary", 1).otherwise(0)
        ).alias("stationary_count"),
        spark_sum(
            when(col("event_class") == "slow_drift", 1).otherwise(0)
        ).alias("slow_drift_count"),
    )
    .withColumnRenamed("active_date", "trade_date")
)

# Per-region daily loitering
df_region = (df_expanded
    .filter(col("loitering_region") != "other")
    .groupBy("active_date", "loitering_region")
    .agg(
        count("event_id").alias("loitering_count"),
        countDistinct("mmsi").alias("loitering_vessels"),
        avg("duration_hrs").alias("avg_duration_hrs"),
    )
    .withColumnRenamed("active_date", "trade_date")
)

# Pivot regions to wide
df_pivot_count = (df_region
    .groupBy("trade_date")
    .pivot("loitering_region", [
        "middle_east","west_africa","black_sea",
        "north_sea","us_gulf"
    ])
    .agg(first("loitering_count"))
)
for r in ["middle_east","west_africa","black_sea","north_sea","us_gulf"]:
    if r in df_pivot_count.columns:
        df_pivot_count = df_pivot_count.withColumnRenamed(
            r, f"{r}_loitering_count")

df_pivot_vessels = (df_region
    .groupBy("trade_date")
    .pivot("loitering_region", [
        "middle_east","west_africa","black_sea",
        "north_sea","us_gulf"
    ])
    .agg(first("loitering_vessels"))
)
for r in ["middle_east","west_africa","black_sea","north_sea","us_gulf"]:
    if r in df_pivot_vessels.columns:
        df_pivot_vessels = df_pivot_vessels.withColumnRenamed(
            r, f"{r}_loitering_vessels")

df_wide = (df_pivot_count
    .join(df_pivot_vessels, on="trade_date", how="left")
    .join(df_global,        on="trade_date", how="left")
)

print(f"Wide format rows: {df_wide.count():,}")

# COMMAND ----------

# ── CELL 6: Join to date spine and fill nulls ─────────────────────────────

df_final = df_spine.join(df_wide, on="trade_date", how="left")

count_cols = [c for c in df_final.columns
              if c.endswith(("_count", "_vessels"))]
dur_cols   = [c for c in df_final.columns
              if c.endswith("_hrs")]

for c in count_cols:
    df_final = df_final.fillna({c: 0})
for c in dur_cols:
    df_final = df_final.fillna({c: 0.0})

# Add total oil region loitering count
oil_loiter_cols = [
    "middle_east_loitering_count", "west_africa_loitering_count",
    "black_sea_loitering_count",   "north_sea_loitering_count",
    "us_gulf_loitering_count"
]
df_final = df_final.withColumn(
    "total_oil_region_loitering_count",
    builtins.sum([col(c) for c in oil_loiter_cols])
)

total = df_final.count()
print(f"Final rows: {total:,}  (expected: 2,556)")
print(f"Columns   : {len(df_final.columns)}")

# COMMAND ----------

# ── CELL 7: Write to Delta ────────────────────────────────────────────────

df_final.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .save(SILVER_LOITERING_DAILY)

count = spark.read.format("delta").load(SILVER_LOITERING_DAILY).count()
print(f"Written: {count:,} rows → {SILVER_LOITERING_DAILY}")

# COMMAND ----------

# ── CELL 8: Validation ────────────────────────────────────────────────────

df = spark.read.format("delta").load(SILVER_LOITERING_DAILY)

print("=" * 60)
print("  SILVER LOITERING DAILY — VALIDATION")
print("=" * 60)

total = df.count()
print(f"\n  Total rows         : {total}  "
      f"{'[PASS]' if total == 2556 else '[FAIL]'}")

print(f"\n  Sample trading days:")
(df.filter(col("is_trading_day") == 1)
    .select(
        "trade_date",
        "global_loitering_count",
        "global_loitering_vessels",
        "middle_east_loitering_count",
        "west_africa_loitering_count",
        "total_oil_region_loitering_count",
        "avg_loitering_duration_hrs"
    )
    .orderBy("trade_date")
    .limit(10)
    .show(truncate=False))

print(f"\n  Yearly average global loitering count:")
(df.filter(col("is_trading_day") == 1)
    .groupBy("year")
    .agg(
        spark_round(avg("global_loitering_count"), 1)
            .alias("avg_loitering_events"),
        spark_round(avg("total_oil_region_loitering_count"), 1)
            .alias("avg_oil_region_loitering")
    )
    .orderBy("year")
    .show(truncate=False))

print("=" * 60)
print("  Proceed to Notebook 09 if counts look reasonable.")
print("  Expected: 3-15 loitering events per day globally,")
print("  0-5 in oil regions.")
print("=" * 60)