# Databricks notebook source
# =============================================================================
# Notebook: 05_silver_date_spine.py
# Purpose : Create a complete trading-day calendar 2017-01-01 to 2023-12-31
#           Every Silver and Gold table joins to this spine.
# Runtime : ~2 minutes
# =============================================================================
# ── CELL 1: Imports and paths ─────────────────────────────────────────────

import pandas as pd
from pyspark.sql import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import (
    col, dayofweek, date_format, year as spark_year,
    month as spark_month, quarter, dayofmonth,
    weekofyear, to_date, lit, when
)

spark = SparkSession.builder.getOrCreate()

VOL_BASE         = "/Volumes/workspace/oil_intel/project_data"
SILVER_DATE_SPINE = f"{VOL_BASE}/silver/date_spine"

START_DATE = "2017-01-01"
END_DATE   = "2023-12-31"

print(f"Date spine: {START_DATE} → {END_DATE}")
print(f"Output    : {SILVER_DATE_SPINE}")

# COMMAND ----------

# ── CELL 2: Generate all calendar days ───────────────────────────────────

# Generate every calendar day in the range
all_days = pd.date_range(start=START_DATE, end=END_DATE, freq="D")
df_pd    = pd.DataFrame({"trade_date": all_days})

# Mark weekends — Brent trades Mon-Fri
df_pd["day_of_week"]  = df_pd["trade_date"].dt.dayofweek  # 0=Mon, 6=Sun
df_pd["is_trading_day"] = df_pd["day_of_week"].between(0, 4).astype(int)
df_pd["is_weekend"]     = (~df_pd["day_of_week"].between(0, 4)).astype(int)

# Known Brent futures non-trading days (UK/US market holidays 2017-2023)
# These are the days the CME/ICE exchange is closed for Brent futures
HOLIDAYS = {
    # 2017
    "2017-01-02", "2017-04-14", "2017-04-17", "2017-05-29",
    "2017-07-04", "2017-09-04", "2017-11-23", "2017-12-25", "2017-12-26",
    # 2018
    "2018-01-01", "2018-03-30", "2018-04-02", "2018-05-28",
    "2018-07-04", "2018-09-03", "2018-11-22", "2018-12-25", "2018-12-26",
    # 2019
    "2019-01-01", "2019-04-19", "2019-04-22", "2019-05-27",
    "2019-07-04", "2019-09-02", "2019-11-28", "2019-12-25", "2019-12-26",
    # 2020
    "2020-01-01", "2020-04-10", "2020-04-13", "2020-05-25",
    "2020-07-03", "2020-09-07", "2020-11-26", "2020-12-25",
    # 2021
    "2021-01-01", "2021-04-02", "2021-04-05", "2021-05-31",
    "2021-07-05", "2021-09-06", "2021-11-25", "2021-12-24",
    # 2022
    "2022-01-17", "2022-02-21", "2022-04-15", "2022-04-18",
    "2022-05-30", "2022-06-20", "2022-07-04", "2022-09-05",
    "2022-11-24", "2022-12-26",
    # 2023
    "2023-01-02", "2023-01-16", "2023-02-20", "2023-04-07",
    "2023-04-10", "2023-05-29", "2023-06-19", "2023-07-04",
    "2023-09-04", "2023-11-23", "2023-12-25",
}

df_pd["date_str"]   = df_pd["trade_date"].dt.strftime("%Y-%m-%d")
df_pd["is_holiday"] = df_pd["date_str"].isin(HOLIDAYS).astype(int)

# A row is a trading day only if it is a weekday AND not a holiday
df_pd["is_trading_day"] = (
    (df_pd["is_trading_day"] == 1) &
    (df_pd["is_holiday"] == 0)
).astype(int)

# Date components
df_pd["year"]          = df_pd["trade_date"].dt.year
df_pd["month"]         = df_pd["trade_date"].dt.month
df_pd["quarter"]       = df_pd["trade_date"].dt.quarter
df_pd["day_of_month"]  = df_pd["trade_date"].dt.day
df_pd["week_of_year"]  = df_pd["trade_date"].dt.isocalendar().week.astype(int)
df_pd["month_name"]    = df_pd["trade_date"].dt.strftime("%B")
df_pd["day_name"]      = df_pd["trade_date"].dt.strftime("%A")
df_pd["yyyymm"]        = df_pd["trade_date"].dt.strftime("%Y-%m")
df_pd["trade_date"]    = df_pd["date_str"]  # store as string YYYY-MM-DD

# Keep only needed columns
df_pd = df_pd[[
    "trade_date", "year", "month", "quarter",
    "day_of_month", "week_of_year", "day_of_week",
    "month_name", "day_name", "yyyymm",
    "is_trading_day", "is_weekend", "is_holiday",
]]

total_days    = len(df_pd)
trading_days  = df_pd["is_trading_day"].sum()
weekend_days  = df_pd["is_weekend"].sum()
holiday_days  = df_pd["is_holiday"].sum()

print(f"Total calendar days : {total_days}")
print(f"Trading days        : {trading_days}")
print(f"Weekend days        : {weekend_days}")
print(f"Holiday days        : {holiday_days}")
print(f"\nExpected trading days: ~1,750-1,810 for 2017-2023")
print(f"Sample:")
print(df_pd.head(8).to_string(index=False))

# COMMAND ----------

# ── CELL 3: Define schema and write to Delta ──────────────────────────────

date_spine_schema = StructType([
    StructField("trade_date",   StringType(),  False),
    StructField("year",         IntegerType(), True),
    StructField("month",        IntegerType(), True),
    StructField("quarter",      IntegerType(), True),
    StructField("day_of_month", IntegerType(), True),
    StructField("week_of_year", IntegerType(), True),
    StructField("day_of_week",  IntegerType(), True),
    StructField("month_name",   StringType(),  True),
    StructField("day_name",     StringType(),  True),
    StructField("yyyymm",       StringType(),  True),
    StructField("is_trading_day", IntegerType(), True),
    StructField("is_weekend",   IntegerType(), True),
    StructField("is_holiday",   IntegerType(), True),
])

df_spark = spark.createDataFrame(df_pd, schema=date_spine_schema)

df_spark.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .save(SILVER_DATE_SPINE)

count = spark.read.format("delta").load(SILVER_DATE_SPINE).count()
print(f"Date spine written: {count} rows → {SILVER_DATE_SPINE}")

# COMMAND ----------

# ── CELL 4: Validation ────────────────────────────────────────────────────

df = spark.read.format("delta").load(SILVER_DATE_SPINE)

total        = df.count()
trading      = df.filter(col("is_trading_day") == 1).count()
non_trading  = df.filter(col("is_trading_day") == 0).count()
holidays     = df.filter(col("is_holiday") == 1).count()

print("=" * 50)
print("  DATE SPINE VALIDATION")
print("=" * 50)
print(f"  Total rows         : {total}")
print(f"  Trading days       : {trading}")
print(f"  Non-trading days   : {non_trading}")
print(f"  Holidays           : {holidays}")

# Check no gaps
from pyspark.sql.functions import min as spark_min, max as spark_max
date_range = df.agg(
    spark_min("trade_date").alias("first"),
    spark_max("trade_date").alias("last")
).collect()[0]
print(f"\n  First date         : {date_range['first']}")
print(f"  Last date          : {date_range['last']}")

# Check each year
print(f"\n  Trading days per year:")
(df.filter(col("is_trading_day") == 1)
    .groupBy("year").count()
    .orderBy("year")
    .show(truncate=False))

# Check no duplicates
distinct = df.select("trade_date").distinct().count()
print(f"  Duplicate dates    : {total - distinct}")

checks_passed = 0
if 2550 <= total <= 2558:
    print(f"  [PASS] Total rows in expected range")
    checks_passed += 1
else:
    print(f"  [FAIL] Total rows {total} outside 2555-2558 range")

if 1750 <= trading <= 1810:
    print(f"  [PASS] Trading days in expected range")
    checks_passed += 1
else:
    print(f"  [FAIL] Trading days {trading} outside 1750-1810 range")

if date_range["first"] == "2017-01-01":
    print(f"  [PASS] Starts on 2017-01-01")
    checks_passed += 1
else:
    print(f"  [FAIL] First date is {date_range['first']}")

if date_range["last"] == "2023-12-31":
    print(f"  [PASS] Ends on 2023-12-31")
    checks_passed += 1
else:
    print(f"  [FAIL] Last date is {date_range['last']}")

if total - distinct == 0:
    print(f"  [PASS] No duplicate dates")
    checks_passed += 1
else:
    print(f"  [FAIL] {total - distinct} duplicate dates found")

print(f"\n  {checks_passed}/5 checks passed")
if checks_passed == 5:
    print("  Date spine COMPLETE — proceed to Notebook 06")
print("=" * 50)

# COMMAND ----------

