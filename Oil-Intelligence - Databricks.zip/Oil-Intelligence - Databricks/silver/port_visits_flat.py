# Databricks notebook source
# =============================================================================
# Notebook: 06_silver_port_visits_flat.py
# Purpose : Filter bronze port visits to confidence-4, join to oil terminals
#           to assign region labels, and write a clean flat Silver table.
# Runtime : ~15-20 minutes (15.6M rows)
# =============================================================================
# ── CELL 1: Imports and paths ─────────────────────────────────────────────

import pandas as pd
import builtins
from pyspark.sql import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import (
    col, to_date, to_timestamp, year as spark_year,
    month as spark_month, trim, upper, when, lit,
    substring, length, broadcast, coalesce,
    count, countDistinct, avg, min as spark_min,
    max as spark_max, round as spark_round
)
from delta.tables import DeltaTable

spark = SparkSession.builder.getOrCreate()

VOL_BASE                = "/Volumes/workspace/oil_intel/project_data"
BRONZE_PORT_VISITS      = f"{VOL_BASE}/bronze/gfw_port_visits"
SILVER_PORT_VISITS_FLAT = f"{VOL_BASE}/silver/port_visits_flat"
OIL_TERMINALS_CSV       = f"/Volumes/workspace/oil_intel/project_data/oil_terminals.csv"

print(f"Bronze input : {BRONZE_PORT_VISITS}")
print(f"Silver output: {SILVER_PORT_VISITS_FLAT}")
print(f"Terminals CSV: {OIL_TERMINALS_CSV}")

# COMMAND ----------

# ── CELL 2: Load and inspect oil_terminals.csv ────────────────────────────

# Verify file exists
try:
    dbutils.fs.ls(OIL_TERMINALS_CSV)
    print("oil_terminals.csv found.")
except Exception:
    raise FileNotFoundError(
        f"oil_terminals.csv not found at {OIL_TERMINALS_CSV}\n"
        f"Upload via: Catalog → oil_intel volume → Upload"
    )

df_terminals = pd.read_csv(OIL_TERMINALS_CSV)
print(f"\nTerminals loaded: {len(df_terminals)} rows")
print(f"Columns: {list(df_terminals.columns)}")
print(f"\n{df_terminals.to_string(index=False)}")

# COMMAND ----------

# ── CELL 3: Build terminal lookup with all known GFW name variants ─────────
# Each terminal row becomes multiple lookup keys — one per GFW name variant.
# This handles cases like BASRAH and AL-BASRAH OIL TERMINAL mapping to
# the same region.

terminal_lookup = {
    # Middle East — Saudi Arabia
    "RAS TANURA":                 ("middle_east", "SAU", "loading"),
    "JEDDAH":                     ("middle_east", "SAU", "loading"),
    # Middle East — Iran
    "KHARK":                      ("middle_east", "IRN", "loading"),
    "ASALUYEH":                   ("middle_east", "IRN", "loading"),
    "BANDAR IMAM KHOMEINI":       ("middle_east", "IRN", "loading"),
    # Middle East — Iraq
    "BASRAH":                     ("middle_east", "IRQ", "loading"),
    "AL-BASRAH OIL TERMINAL":     ("middle_east", "IRQ", "loading"),
    # Middle East — UAE
    "FUJAIRAH":                   ("middle_east", "ARE", "loading"),
    # Mediterranean — Egypt
    "SIDI KERIR":                 ("mediterranean", "EGY", "loading"),
    # West Africa — Nigeria
    "BONNY":                      ("west_africa", "NGA", "loading"),
    "BONNY TERMINAL":             ("west_africa", "NGA", "loading"),
    "FORCADOS TERMINAL":          ("west_africa", "NGA", "loading"),
    "ESCRAVOS":                   ("west_africa", "NGA", "loading"),
    "ESCRAVOS FIELD":             ("west_africa", "NGA", "loading"),
    # Black Sea — Russia
    "NOVOROSSIYSK":               ("black_sea", "RUS", "loading"),
    "PRIMORSK":                   ("black_sea", "RUS", "loading"),
    # North Sea — UK / Netherlands
    "SULLOM VOE":                 ("north_sea", "GBR", "loading"),
    "ROTTERDAM":                  ("north_sea", "NLD", "loading"),
    "ROTTERDAM BOTLEK":           ("north_sea", "NLD", "loading"),
    # US Gulf
    "HOUSTON":                    ("us_gulf", "USA", "loading"),
    "CORPUS CHRISTI":             ("us_gulf", "USA", "loading"),
}

# Convert to Spark broadcast DataFrame for join
lookup_rows = [
    {"port_name_key": k, "region": v[0], "terminal_country": v[1],
     "terminal_type": v[2]}
    for k, v in terminal_lookup.items()
]
df_lookup_pd = pd.DataFrame(lookup_rows)

lookup_schema = StructType([
    StructField("port_name_key",    StringType(), True),
    StructField("region",           StringType(), True),
    StructField("terminal_country", StringType(), True),
    StructField("terminal_type",    StringType(), True),
])

df_lookup = spark.createDataFrame(df_lookup_pd, schema=lookup_schema)

print(f"Terminal lookup entries: {df_lookup.count()}")
df_lookup.orderBy("region", "port_name_key").show(30, truncate=False)

# COMMAND ----------

# ── CELL 4: Load bronze, apply quality filters ────────────────────────────

print("Loading bronze port visits...")
df_bronze = spark.read.format("delta").load(BRONZE_PORT_VISITS)

total_bronze = df_bronze.count()
print(f"Bronze rows total   : {total_bronze:,}")

# Filter 1: confidence = 4 only
df_conf4 = df_bronze.filter(col("confidence") == 4)
conf4_count = df_conf4.count()
print(f"After confidence=4  : {conf4_count:,} "
      f"({builtins.round(conf4_count/total_bronze*100,1)}%)")

# Filter 2: within project window 2017-2023
df_filtered = df_conf4.withColumn(
    "start_date", to_date(to_timestamp(col("start_ts")))
).filter(
    (col("start_date") >= "2017-01-01") &
    (col("start_date") <= "2023-12-31")
)
window_count = df_filtered.count()
print(f"After date filter   : {window_count:,}")

# Filter 3: must have a start port name
df_filtered = df_filtered.filter(
    col("start_port_name").isNotNull() &
    (trim(col("start_port_name")) != "")
)
named_count = df_filtered.count()
print(f"After port name filter: {named_count:,}")

print(f"\nRows dropped: {total_bronze - named_count:,} "
      f"({builtins.round((1 - named_count/total_bronze)*100,1)}%)")

# COMMAND ----------

# ── CELL 5: Join to terminal lookup to assign regions ─────────────────────

print("Joining to terminal lookup...")

# Prepare join key — trim and upper to normalise
df_keyed = df_filtered.withColumn(
    "port_name_key", trim(upper(col("start_port_name")))
)

# Left join — non-terminal ports get null region (labelled "other")
df_joined = df_keyed.join(
    broadcast(df_lookup),
    on="port_name_key",
    how="left"
)

# Fill nulls for non-terminal ports
df_joined = df_joined.withColumn(
    "region",
    coalesce(col("region"), lit("other"))
).withColumn(
    "terminal_country",
    coalesce(col("terminal_country"), lit(""))
).withColumn(
    "terminal_type",
    coalesce(col("terminal_type"), lit("other"))
)

# Check region assignment
print("\nRegion distribution:")
(df_joined
    .groupBy("region").count()
    .orderBy("count", ascending=False)
    .show(15, truncate=False))

# COMMAND ----------

# ── CELL 6: Add derived columns and select final schema ───────────────────

df_silver = df_joined.select(
    # Identity
    col("event_id"),
    col("vessel_id"),
    col("mmsi"),
    col("vessel_name"),
    col("vessel_type"),
    col("flag"),

    # Timestamps — keep original string + parsed date
    col("start_ts"),
    col("end_ts"),
    col("start_date"),
    to_date(to_timestamp(col("end_ts"))).alias("end_date"),

    # Date components for grouping
    spark_year("start_date").alias("year"),
    spark_month("start_date").alias("month"),
    substring(col("start_ts"), 1, 7).alias("yyyymm"),

    # Port info
    col("start_port_name"),
    col("start_port_country"),
    col("start_port_lat"),
    col("start_port_lon"),
    col("end_port_name"),
    col("end_port_country"),

    # Region assignment from terminal lookup
    col("region"),
    col("terminal_country"),
    col("terminal_type"),

    # Visit metadata
    col("duration_hrs"),
    col("confidence"),
    col("visit_id"),
    col("region_eez"),
    col("next_port"),

    # Is this a known oil terminal visit?
    when(col("region") != "other", lit(1)).otherwise(lit(0))
        .alias("is_oil_terminal"),

    # Vessel category — bunker = tanker, cargo = bulk/container
    when(upper(col("vessel_type")).contains("BUNKER"), lit("tanker"))
        .when(upper(col("vessel_type")).contains("CARGO"), lit("cargo"))
        .otherwise(lit("other"))
        .alias("vessel_category"),

    col("ingested_at"),
)

total_silver = df_silver.count()
oil_terminal_visits = df_silver.filter(col("is_oil_terminal") == 1).count()
other_visits        = df_silver.filter(col("is_oil_terminal") == 0).count()

print(f"Silver rows total       : {total_silver:,}")
print(f"Oil terminal visits     : {oil_terminal_visits:,}")
print(f"Other port visits       : {other_visits:,}")
print(f"Terminal visit rate     : "
      f"{builtins.round(oil_terminal_visits/total_silver*100,1)}%")

# COMMAND ----------

# ── CELL 7: Write to Delta ────────────────────────────────────────────────

print("Writing silver port visits flat...")

df_silver.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .partitionBy("year", "month") \
    .save(SILVER_PORT_VISITS_FLAT)

count = spark.read.format("delta").load(SILVER_PORT_VISITS_FLAT).count()
print(f"Written: {count:,} rows → {SILVER_PORT_VISITS_FLAT}")
print(f"Partitioned by year and month for fast downstream queries.")

# COMMAND ----------

# ── CELL 8: Validation ────────────────────────────────────────────────────

df = spark.read.format("delta").load(SILVER_PORT_VISITS_FLAT)

print("=" * 60)
print("  SILVER PORT VISITS FLAT — VALIDATION")
print("=" * 60)

total = df.count()
print(f"\n  Total rows          : {total:,}")

# Check 1: all confidence = 4
non_conf4 = df.filter(col("confidence") != 4).count()
print(f"  Non-confidence-4    : {non_conf4}  "
      f"{'[PASS]' if non_conf4 == 0 else '[FAIL]'}")

# Check 2: date range
date_range = df.agg(
    spark_min("start_date").alias("first"),
    spark_max("start_date").alias("last")
).collect()[0]
print(f"  Date range          : {date_range['first']} → "
      f"{date_range['last']}")
date_ok = (str(date_range["first"]) >= "2017-01-01" and
           str(date_range["last"])  <= "2023-12-31")
print(f"  Within 2017-2023    : {'[PASS]' if date_ok else '[FAIL]'}")

# Check 3: region breakdown
print(f"\n  Region breakdown:")
(df.groupBy("region").count()
    .orderBy("count", ascending=False)
    .show(10, truncate=False))

# Check 4: oil terminal visits per region
print(f"  Oil terminal visits per region:")
(df.filter(col("is_oil_terminal") == 1)
    .groupBy("region", "start_port_name")
    .count()
    .orderBy("region", "count", ascending=[True, False])
    .show(30, truncate=False))

# Check 5: yearly visit counts at oil terminals
print(f"  Oil terminal visits per year:")
(df.filter(col("is_oil_terminal") == 1)
    .groupBy("year").count()
    .orderBy("year")
    .show(truncate=False))

# Check 6: no null event_ids
null_ids = df.filter(col("event_id").isNull() | (col("event_id") == "")).count()
print(f"  Null event_ids      : {null_ids}  "
      f"{'[PASS]' if null_ids == 0 else '[FAIL]'}")

# Check 7: sample rows from oil terminals
print(f"\n  Sample oil terminal visits:")
(df.filter(col("is_oil_terminal") == 1)
    .select("vessel_name", "flag", "vessel_type", "start_date",
            "start_port_name", "region", "duration_hrs")
    .orderBy("start_date")
    .limit(8)
    .show(truncate=False))

print("=" * 60)
print("  If region breakdown shows oil terminal visits across all")
print("  expected regions — proceed to Notebook 07.")
print("=" * 60)

# COMMAND ----------

