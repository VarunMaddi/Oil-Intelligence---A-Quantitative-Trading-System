# Databricks notebook source
# =============================================================================
# Notebook: 10_silver_market_daily.py
# Purpose : Align Brent and DXY to date spine, compute price features.
#           This table provides the price signal and prediction target.
# Runtime : ~2 minutes
# =============================================================================
# ── CELL 1: Imports and paths ─────────────────────────────────────────────

import builtins
from pyspark.sql import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import (
    col, lag, ln, when, lit, coalesce,
    round as spark_round, avg, stddev,
    min as spark_min, max as spark_max,
    last, first, isnan, isnull,
    year as spark_year, month as spark_month
)
from pyspark.sql.window import Window

spark = SparkSession.builder.getOrCreate()

VOL_BASE             = "/Volumes/workspace/oil_intel/project_data"
BRONZE_MARKET        = f"{VOL_BASE}/bronze/market"
SILVER_DATE_SPINE    = f"{VOL_BASE}/silver/date_spine"
SILVER_MARKET_DAILY  = f"{VOL_BASE}/silver/market_daily"

print(f"Input  : {BRONZE_MARKET}")
print(f"Output : {SILVER_MARKET_DAILY}")

# COMMAND ----------

# ── CELL 2: Load and pivot market data ───────────────────────────────────

df_market = spark.read.format("delta").load(BRONZE_MARKET)
df_spine  = spark.read.format("delta").load(SILVER_DATE_SPINE)

print(f"Market rows : {df_market.count():,}")
print(f"Spine rows  : {df_spine.count():,}")

# Pivot from long to wide — one row per date with brent and dxy columns
df_brent = (df_market
    .filter(col("ticker") == "BZ=F")
    .select(
        col("trade_date"),
        col("open").alias("brent_open"),
        col("high").alias("brent_high"),
        col("low").alias("brent_low"),
        col("close").alias("brent_close"),
        col("volume").alias("brent_volume"),
    )
)

df_dxy = (df_market
    .filter(col("ticker") == "DX-Y.NYB")
    .select(
        col("trade_date"),
        col("close").alias("dxy_close"),
    )
)

df_wide = df_brent.join(df_dxy, on="trade_date", how="outer")

print(f"\nWide format rows: {df_wide.count():,}")
print("Sample:")
df_wide.orderBy("trade_date").limit(5).show(truncate=False)

# COMMAND ----------

# ── CELL 3: Join to date spine ────────────────────────────────────────────

df_joined = (df_spine
    .join(df_wide, on="trade_date", how="left")
)

# Forward-fill prices for non-trading days and holidays
# Use last known value — prices don't move on weekends/holidays
w_ffill = Window.orderBy("trade_date").rowsBetween(
    Window.unboundedPreceding, 0
)

df_filled = (df_joined
    .withColumn("brent_close",
        last(col("brent_close"), ignorenulls=True).over(w_ffill))
    .withColumn("brent_open",
        last(col("brent_open"),  ignorenulls=True).over(w_ffill))
    .withColumn("brent_high",
        last(col("brent_high"),  ignorenulls=True).over(w_ffill))
    .withColumn("brent_low",
        last(col("brent_low"),   ignorenulls=True).over(w_ffill))
    .withColumn("brent_volume",
        last(col("brent_volume"),ignorenulls=True).over(w_ffill))
    .withColumn("dxy_close",
        last(col("dxy_close"),   ignorenulls=True).over(w_ffill))
)

print(f"After join and forward-fill: {df_filled.count():,} rows")

# Check nulls remaining after ffill
null_brent = df_filled.filter(col("brent_close").isNull()).count()
null_dxy   = df_filled.filter(col("dxy_close").isNull()).count()
print(f"Null brent_close after ffill: {null_brent}")
print(f"Null dxy_close after ffill  : {null_dxy}")

# COMMAND ----------

# ── CELL 4: Compute price features ───────────────────────────────────────

w_date = Window.orderBy("trade_date")

df_features = (df_filled

    # ── Daily log return ──────────────────────────────────────────────────
    .withColumn("brent_return_1d",
        ln(col("brent_close") /
           lag("brent_close", 1).over(w_date)))

    # ── DXY daily log return ──────────────────────────────────────────────
    .withColumn("dxy_return_1d",
        ln(col("dxy_close") /
           lag("dxy_close", 1).over(w_date)))

    # ── Moving averages ───────────────────────────────────────────────────
    .withColumn("brent_ma5",
        avg("brent_close").over(
            w_date.rowsBetween(-4, 0)))
    .withColumn("brent_ma10",
        avg("brent_close").over(
            w_date.rowsBetween(-9, 0)))
    .withColumn("brent_ma20",
        avg("brent_close").over(
            w_date.rowsBetween(-19, 0)))

    # ── Rolling volatility (20-day std of log returns) ────────────────────
    .withColumn("brent_vol_20d",
        stddev("brent_return_1d").over(
            w_date.rowsBetween(-19, 0)))

    # ── Contango proxy ────────────────────────────────────────────────────
    # MA5 < MA20 = contango (futures curve upward sloping = bearish)
    # MA5 > MA20 = backwardation (futures curve downward sloping = bullish)
    .withColumn("contango_flag",
        when(col("brent_ma5") < col("brent_ma20"), lit(1))
        .when(col("brent_ma5") > col("brent_ma20"), lit(-1))
        .otherwise(lit(0)))

    # ── Price momentum ────────────────────────────────────────────────────
    .withColumn("brent_momentum_5d",
        col("brent_close") - lag("brent_close", 5).over(w_date))
    .withColumn("brent_momentum_20d",
        col("brent_close") - lag("brent_close", 20).over(w_date))

    # ── RSI-like overbought/oversold signal (14-day) ──────────────────────
    # Simplified: ratio of up-days to total days in 14d window
    .withColumn("up_day",
        when(col("brent_return_1d") > 0, lit(1.0)).otherwise(lit(0.0)))
    .withColumn("brent_rsi14_proxy",
        avg("up_day").over(w_date.rowsBetween(-13, 0)) * 100)

    # ── Intraday range ────────────────────────────────────────────────────
    .withColumn("brent_intraday_range",
        col("brent_high") - col("brent_low"))

    # ── Price level normalised to 52-week range ───────────────────────────
    .withColumn("brent_52w_high",
        spark_max("brent_close").over(
            w_date.rowsBetween(-251, 0)))
    .withColumn("brent_52w_low",
        spark_min("brent_close").over(
            w_date.rowsBetween(-251, 0)))
    .withColumn("brent_52w_position",
        when(
            (col("brent_52w_high") - col("brent_52w_low")) > 0,
            (col("brent_close") - col("brent_52w_low")) /
            (col("brent_52w_high") - col("brent_52w_low"))
        ).otherwise(lit(0.5)))

    # ── PREDICTION TARGET — next trading day direction ────────────────────
    # Using lead() over ALL days then filter in Gold to trading days only
    # This avoids weekend/holiday leakage
    .withColumn("next_day_close",
        lag("brent_close", -1).over(w_date))
    .withColumn("next_day_return",
        ln(col("next_day_close") / col("brent_close")))
    .withColumn("next_day_direction",
        when(col("next_day_return") > 0, lit(1))
        .when(col("next_day_return") < 0, lit(0))
        .otherwise(lit(None).cast("integer")))
)

print(f"Features computed: {len(df_features.columns)} columns")
print(f"Rows: {df_features.count():,}")

# COMMAND ----------

# ── CELL 5: Select final columns ──────────────────────────────────────────

df_silver = df_features.select(
    # Date spine
    "trade_date", "year", "month", "quarter",
    "yyyymm", "day_of_week", "day_name",
    "is_trading_day", "is_weekend", "is_holiday",

    # Raw prices
    "brent_open", "brent_high", "brent_low",
    "brent_close", "brent_volume",
    "dxy_close",

    # Return features
    "brent_return_1d",
    "dxy_return_1d",

    # Moving averages
    "brent_ma5", "brent_ma10", "brent_ma20",

    # Volatility and momentum
    "brent_vol_20d",
    "brent_momentum_5d",
    "brent_momentum_20d",

    # Technical signals
    "contango_flag",
    "brent_rsi14_proxy",
    "brent_intraday_range",
    "brent_52w_position",

    # Prediction target
    "next_day_close",
    "next_day_return",
    "next_day_direction",
)

print(f"Final columns : {len(df_silver.columns)}")
print(f"Final rows    : {df_silver.count():,}")

# COMMAND ----------

# ── CELL 6: Write to Delta ────────────────────────────────────────────────

df_silver.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .save(SILVER_MARKET_DAILY)

count = spark.read.format("delta").load(SILVER_MARKET_DAILY).count()
print(f"Written: {count:,} rows → {SILVER_MARKET_DAILY}")

# COMMAND ----------

# ── CELL 7: Validation ────────────────────────────────────────────────────

df = spark.read.format("delta").load(SILVER_MARKET_DAILY)

print("=" * 60)
print("  SILVER MARKET DAILY — VALIDATION")
print("=" * 60)

total = df.count()
print(f"\n  Total rows         : {total}  "
      f"{'[PASS]' if total == 2556 else '[FAIL]'}")

# Price sanity
price_stats = (df
    .filter(col("is_trading_day") == 1)
    .agg(
        spark_min("brent_close").alias("min_brent"),
        spark_max("brent_close").alias("max_brent"),
        avg("brent_close").alias("avg_brent"),
        spark_min("dxy_close").alias("min_dxy"),
        spark_max("dxy_close").alias("max_dxy"),
    ).collect()[0])

print(f"\n  Brent close range  : "
      f"${price_stats['min_brent']:.2f} – "
      f"${price_stats['max_brent']:.2f}  "
      f"(avg ${price_stats['avg_brent']:.2f})")
brent_ok = (price_stats["min_brent"] > 10 and
            price_stats["max_brent"] < 200)
print(f"  Brent range valid  : {'[PASS]' if brent_ok else '[FAIL]'}")

print(f"\n  DXY range          : "
      f"{price_stats['min_dxy']:.2f} – "
      f"{price_stats['max_dxy']:.2f}")

# Target variable distribution
target_dist = (df
    .filter(col("is_trading_day") == 1)
    .groupBy("next_day_direction").count()
    .orderBy("next_day_direction")
    .collect())

print(f"\n  Target distribution (next_day_direction):")
for row in target_dist:
    d = row["next_day_direction"]
    n = row["count"]
    label = "UP (1)" if d == 1 else "DOWN (0)" if d == 0 else "NULL"
    print(f"    {label:<12}: {n:>5,}")

# Contango distribution
print(f"\n  Contango flag distribution:")
(df.filter(col("is_trading_day") == 1)
    .groupBy("contango_flag").count()
    .orderBy("contango_flag").show(truncate=False))

# Sample rows
print(f"\n  Sample trading day rows:")
(df.filter(col("is_trading_day") == 1)
    .select(
        "trade_date", "brent_close", "brent_return_1d",
        "brent_ma5", "brent_ma20", "brent_vol_20d",
        "contango_flag", "next_day_direction"
    )
    .orderBy("trade_date")
    .limit(8)
    .show(truncate=False))

# Yearly stats
print(f"\n  Yearly average Brent price:")
(df.filter(col("is_trading_day") == 1)
    .groupBy("year")
    .agg(
        spark_round(avg("brent_close"), 2).alias("avg_brent"),
        spark_round(avg("brent_vol_20d"), 4).alias("avg_vol_20d"),
        spark_round(avg("brent_rsi14_proxy"), 1).alias("avg_rsi14")
    )
    .orderBy("year")
    .show(truncate=False))

print("=" * 60)
print("  Proceed to Notebook 11 if price range and target")
print("  distribution look correct.")
print("=" * 60)