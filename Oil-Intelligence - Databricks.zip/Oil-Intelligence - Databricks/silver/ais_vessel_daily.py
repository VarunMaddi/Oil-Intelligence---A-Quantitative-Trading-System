# Databricks notebook source
# =============================================================================
# Notebook: 07_silver_vessel_daily.py
# Purpose : Aggregate port visit events into daily vessel counts per region.
#           This is the primary AIS supply signal for the Gold feature store.
# Runtime : ~8 minutes
# =============================================================================
# ── CELL 1: Imports and paths ─────────────────────────────────────────────

import builtins
from pyspark.sql import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import (
    col, to_date, lit, when, coalesce,
    count, countDistinct, avg, sum as spark_sum,
    min as spark_min, max as spark_max,
    round as spark_round, broadcast,
    year as spark_year, month as spark_month,
    explode, sequence, datediff, expr
)
from pyspark.sql.window import Window
from delta.tables import DeltaTable

spark = SparkSession.builder.getOrCreate()

VOL_BASE                = "/Volumes/workspace/oil_intel/project_data"
SILVER_PORT_VISITS_FLAT = f"{VOL_BASE}/silver/port_visits_flat"
SILVER_DATE_SPINE       = f"{VOL_BASE}/silver/date_spine"
SILVER_VESSEL_DAILY     = f"{VOL_BASE}/silver/ais_vessel_daily"

REGIONS = [
    "middle_east", "west_africa", "black_sea",
    "north_sea", "us_gulf", "mediterranean", "other"
]

print(f"Input  : {SILVER_PORT_VISITS_FLAT}")
print(f"Output : {SILVER_VESSEL_DAILY}")

# COMMAND ----------

# ── CELL 2: Load inputs ───────────────────────────────────────────────────

print("Loading silver port visits flat...")
df_pv = spark.read.format("delta").load(SILVER_PORT_VISITS_FLAT)

print("Loading date spine...")
df_spine = (spark.read.format("delta").load(SILVER_DATE_SPINE)
    .select("trade_date", "year", "month", "yyyymm",
            "is_trading_day", "is_weekend", "is_holiday"))

print(f"Port visits : {df_pv.count():,} rows")
print(f"Date spine  : {df_spine.count():,} rows")

# COMMAND ----------

# ── CELL 3: Expand visits across all active days ──────────────────────────
# A vessel visiting a port from 2017-01-01 to 2017-01-03 should contribute
# to the vessel count for all three days, not just the arrival day.
# We use sequence() to generate one row per active day per visit.

print("Expanding visits to daily rows...")

df_expanded = (df_pv
    .withColumn("start_date", to_date(col("start_date")))
    .withColumn("end_date",   to_date(col("end_date")))
    # Cap end_date to project window and fill nulls
    .withColumn("end_date",
        when(col("end_date").isNull(), col("start_date"))
        .when(col("end_date") > "2023-12-31", to_date(lit("2023-12-31")))
        .otherwise(col("end_date"))
    )
    # Only expand visits up to 30 days (avoids massive expansion for outliers)
    .withColumn("duration_days",
        datediff(col("end_date"), col("start_date")) + 1
    )
    .filter(col("duration_days") <= 30)
    .withColumn("active_dates",
        sequence(col("start_date"), col("end_date"), expr("interval 1 day"))
    )
    .withColumn("active_date", explode(col("active_dates")))
    .withColumn("active_date", col("active_date").cast("string").substr(1, 10))
    .filter(
        (col("active_date") >= "2017-01-01") &
        (col("active_date") <= "2023-12-31")
    )
)

print(f"Expanded rows: {df_expanded.count():,}")

# COMMAND ----------

# ── CELL 4: Aggregate to daily vessel counts per region ───────────────────

print("Aggregating to daily counts per region...")

# Global daily counts (all regions combined)
df_global_daily = (df_expanded
    .groupBy("active_date")
    .agg(
        countDistinct("vessel_id").alias("global_vessel_count"),
        countDistinct(
            when(col("vessel_category") == "tanker", col("vessel_id"))
        ).alias("global_tanker_count"),
        countDistinct(
            when(col("is_oil_terminal") == 1, col("vessel_id"))
        ).alias("global_terminal_vessel_count"),
        avg("duration_hrs").alias("avg_duration_hrs_global"),
        count("event_id").alias("global_visit_count"),
    )
    .withColumnRenamed("active_date", "trade_date")
)

# Per-region daily counts (oil terminals only)
df_region_daily = (df_expanded
    .filter(col("is_oil_terminal") == 1)
    .groupBy("active_date", "region")
    .agg(
        countDistinct("vessel_id").alias("vessel_count"),
        countDistinct(
            when(col("vessel_category") == "tanker", col("vessel_id"))
        ).alias("tanker_count"),
        count("event_id").alias("visit_count"),
        avg("duration_hrs").alias("avg_duration_hrs"),
    )
    .withColumnRenamed("active_date", "trade_date")
)

print("Global daily aggregation complete.")
print("Region daily aggregation complete.")

# COMMAND ----------

# ── CELL 5: Pivot regions to wide format and join to date spine ───────────
# Final table has one row per trading day with columns for each region.
# e.g. middle_east_vessel_count, west_africa_vessel_count, etc.

from pyspark.sql.functions import first

print("Pivoting regions to wide format...")

# Pivot vessel counts per region
df_pivot = (df_region_daily
    .groupBy("trade_date")
    .pivot("region", [
        "middle_east", "west_africa", "black_sea",
        "north_sea", "us_gulf", "mediterranean"
    ])
    .agg(first("vessel_count"))
)

# Rename pivoted columns
for region in ["middle_east", "west_africa", "black_sea",
               "north_sea", "us_gulf", "mediterranean"]:
    if region in df_pivot.columns:
        df_pivot = df_pivot.withColumnRenamed(
            region, f"{region}_vessel_count"
        )

# Also pivot visit counts
df_pivot_visits = (df_region_daily
    .groupBy("trade_date")
    .pivot("region", [
        "middle_east", "west_africa", "black_sea",
        "north_sea", "us_gulf", "mediterranean"
    ])
    .agg(first("visit_count"))
)
for region in ["middle_east", "west_africa", "black_sea",
               "north_sea", "us_gulf", "mediterranean"]:
    if region in df_pivot_visits.columns:
        df_pivot_visits = df_pivot_visits.withColumnRenamed(
            region, f"{region}_visit_count"
        )

# Also pivot avg duration
df_pivot_dur = (df_region_daily
    .groupBy("trade_date")
    .pivot("region", [
        "middle_east", "west_africa", "black_sea",
        "north_sea", "us_gulf", "mediterranean"
    ])
    .agg(first("avg_duration_hrs"))
)
for region in ["middle_east", "west_africa", "black_sea",
               "north_sea", "us_gulf", "mediterranean"]:
    if region in df_pivot_dur.columns:
        df_pivot_dur = df_pivot_dur.withColumnRenamed(
            region, f"{region}_avg_duration_hrs"
        )

# Join all pivots together
df_wide = (df_pivot
    .join(df_pivot_visits, on="trade_date", how="left")
    .join(df_pivot_dur,    on="trade_date", how="left")
    .join(df_global_daily, on="trade_date", how="left")
)

print(f"Wide format columns: {len(df_wide.columns)}")
print(f"Wide format rows   : {df_wide.count():,}")

# COMMAND ----------

# ── CELL 6: Join to date spine and fill nulls ─────────────────────────────

print("Joining to date spine...")

df_final = (df_spine
    .join(df_wide, on="trade_date", how="left")
)

# Fill nulls with 0 for count columns
count_cols = [c for c in df_final.columns
              if any(c.endswith(s) for s in
                     ["_count", "_visit_count"])]
dur_cols   = [c for c in df_final.columns
              if c.endswith("_avg_duration_hrs")]
global_dur = ["avg_duration_hrs_global"]

for c in count_cols:
    df_final = df_final.fillna({c: 0})
for c in dur_cols + global_dur:
    df_final = df_final.fillna({c: 0.0})

# Add total oil region vessel count (sum across all oil regions)
oil_region_count_cols = [
    "middle_east_vessel_count", "west_africa_vessel_count",
    "black_sea_vessel_count",   "north_sea_vessel_count",
    "us_gulf_vessel_count",     "mediterranean_vessel_count"
]
df_final = df_final.withColumn(
    "total_oil_region_vessel_count",
    builtins.sum([col(c) for c in oil_region_count_cols])
)

total = df_final.count()
print(f"Final rows: {total:,}  (expected: 2,556 — one per calendar day)")
print(f"Columns   : {len(df_final.columns)}")

# COMMAND ----------

# ── CELL 7: Write to Delta ────────────────────────────────────────────────

print("Writing silver vessel daily...")

df_final.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .save(SILVER_VESSEL_DAILY)

count = spark.read.format("delta").load(SILVER_VESSEL_DAILY).count()
print(f"Written: {count:,} rows → {SILVER_VESSEL_DAILY}")

# COMMAND ----------

# ── CELL 8: Validation ────────────────────────────────────────────────────

df = spark.read.format("delta").load(SILVER_VESSEL_DAILY)

print("=" * 60)
print("  SILVER VESSEL DAILY — VALIDATION")
print("=" * 60)

total = df.count()
print(f"\n  Total rows (calendar days) : {total}")

# Check 1: one row per date
distinct_dates = df.select("trade_date").distinct().count()
print(f"  Distinct dates             : {distinct_dates}")
print(f"  Duplicates                 : {total - distinct_dates}  "
      f"{'[PASS]' if total == distinct_dates else '[FAIL]'}")

# Check 2: coverage
print(f"\n  Date range:")
df.agg(
    spark_min("trade_date").alias("first"),
    spark_max("trade_date").alias("last")
).show(truncate=False)

# Check 3: non-zero vessel counts on trading days
trading_with_vessels = (df
    .filter(
        (col("is_trading_day") == 1) &
        (col("global_vessel_count") > 0)
    ).count())
trading_total = df.filter(col("is_trading_day") == 1).count()
print(f"  Trading days with vessel data: "
      f"{trading_with_vessels}/{trading_total}  "
      f"{'[PASS]' if trading_with_vessels > 1700 else '[WARN]'}")

# Check 4: sample of key regional counts
print(f"\n  Sample trading day vessel counts (first 10 trading days):")
(df.filter(col("is_trading_day") == 1)
    .select(
        "trade_date",
        "middle_east_vessel_count",
        "west_africa_vessel_count",
        "us_gulf_vessel_count",
        "black_sea_vessel_count",
        "global_vessel_count",
        "total_oil_region_vessel_count"
    )
    .orderBy("trade_date")
    .limit(10)
    .show(truncate=False))

# Check 5: yearly averages to confirm signal makes sense
print(f"  Yearly average Middle East vessel count (trading days):")
(df.filter(
        (col("is_trading_day") == 1) &
        (col("middle_east_vessel_count") > 0)
    )
    .groupBy("year")
    .agg(
        spark_round(avg("middle_east_vessel_count"), 1)
            .alias("avg_me_vessels"),
        spark_round(avg("total_oil_region_vessel_count"), 1)
            .alias("avg_total_oil_vessels")
    )
    .orderBy("year")
    .show(truncate=False))

print("=" * 60)
print("  Proceed to Notebook 08 if vessel counts look reasonable.")
print("=" * 60)

# COMMAND ----------

