# Databricks notebook source
# ── CELL 1 ────────────────────────────────────────────────────────────────

def get_param(name, default=""):
    try:
        return dbutils.widgets.get(name)
    except Exception:
        return default

YEAR_PARAM = get_param("YEAR", "")
assert YEAR_PARAM != "", "Pass YEAR as job parameter e.g. YEAR=2018"
YEAR = int(YEAR_PARAM)
assert 2017 <= YEAR <= 2023, f"YEAR must be 2017-2023"

GFW_TOKEN = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImtpZEtleSJ9.eyJkYXRhIjp7Im5hbWUiOiJBY2FkZW1pYyBSZXNlYXJjaCIsInVzZXJJZCI6NTg2MTUsImFwcGxpY2F0aW9uTmFtZSI6IkFjYWRlbWljIFJlc2VhcmNoIiwiaWQiOjUzMTksInR5cGUiOiJ1c2VyLWFwcGxpY2F0aW9uIn0sImlhdCI6MTc3NDk1NTEyNCwiZXhwIjoyMDkwMzE1MTI0LCJhdWQiOiJnZnciLCJpc3MiOiJnZncifQ.XsEQ6JGnll6VkPZi94EczSMI4ygq3KV_Kx3Vtl10UNhRpnIMOmOE3uv0ea3QWgRyx2GxQOKOXChZhDP_kdOvQErzVWP5mVAQoQjrqPMSKsaKaFzChPiC6BulB-ikC_KdjYH8O1eX3nV4Fz7q67E-QeHMc4grkj00wrK-EAwwmHmpKzgNjhufBZ6Q0GZcj1yYopMK6rD1VOQLuKEDKRG_Dixh1-hb2nZqjg-i2Ry-Hcb3Z_VODhpAP2Jja69utX30ELAB-eiG4wRzEdis8lE3o4l5oljBitjSjwsfbfJ857_wYB3ZUh5zUPd-2CtAJjGn6X22_qTzjjMGv9fKabplhpQYi-QyzOwt8B-Flgx0xflTjpYwGmHvbFOWHrsEmgH-jdjx5FDIpZ3a18Pt3y7zoClK3S0eJLcLaD6DE95kmoAvP_n7vgXDHNdTJn92kgQvR4V3wrVz4Snx7Bf73LquFA77g7fUc81DUg5AyT20vUwnhwirxJ3iXh-QUvGjR3FI"

assert len(GFW_TOKEN) > 20
print(f"Year: {YEAR}")
print(f"GFW : {GFW_TOKEN[:8]}...{GFW_TOKEN[-4:]}")

# COMMAND ----------

# ── CELL 2 ────────────────────────────────────────────────────────────────

import requests, time, json, pandas as pd, calendar
from datetime import datetime
from pyspark.sql import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql.window import Window
from delta.tables import DeltaTable
import builtins

spark = SparkSession.builder.getOrCreate()

CATALOG  = "workspace"
SCHEMA   = "oil_intel"
VOLUME   = "project_data"
VOL_BASE = f"/Volumes/{CATALOG}/{SCHEMA}/{VOLUME}"

BASE_URL     = "https://gateway.api.globalfishingwatch.org/v3"
HEADERS      = {
    "Authorization": f"Bearer {GFW_TOKEN}",
    "Content-Type":  "application/json"
}
DATASET      = "public-global-port-visits-c2-events:latest"
VESSEL_TYPES = ["BUNKER", "CARGO"]

# Shared output — all years write to same Delta table via MERGE
OUTPUT_PATH  = f"{VOL_BASE}/bronze/gfw_port_visits"

# Year-specific checkpoint — each job tracks its own progress
CHECKPOINT_PATH = f"{VOL_BASE}/checkpoints/bronze_pv_{YEAR}.json"

# Only this year's months
START_YEAR = YEAR
END_YEAR   = YEAR

print(f"Output     : {OUTPUT_PATH}")
print(f"Checkpoint : {CHECKPOINT_PATH}")

# COMMAND ----------

# ── CELL 3: Schema ────────────────────────────────────────────────────────

bronze_schema = StructType([
    StructField("event_id",           StringType(),  True),
    StructField("vessel_id",          StringType(),  True),
    StructField("mmsi",               StringType(),  True),
    StructField("vessel_name",        StringType(),  True),
    StructField("vessel_type",        StringType(),  True),
    StructField("flag",               StringType(),  True),
    StructField("next_port",          StringType(),  True),
    StructField("start_ts",           StringType(),  True),
    StructField("end_ts",             StringType(),  True),
    StructField("lat",                DoubleType(),  True),
    StructField("lon",                DoubleType(),  True),
    StructField("start_port_name",    StringType(),  True),
    StructField("start_port_country", StringType(),  True),
    StructField("start_port_lat",     DoubleType(),  True),
    StructField("start_port_lon",     DoubleType(),  True),
    StructField("end_port_name",      StringType(),  True),
    StructField("end_port_country",   StringType(),  True),
    StructField("end_port_lat",       DoubleType(),  True),
    StructField("end_port_lon",       DoubleType(),  True),
    StructField("duration_hrs",       DoubleType(),  True),
    StructField("confidence",         IntegerType(), True),
    StructField("visit_id",           StringType(),  True),
    StructField("region_eez",         StringType(),  True),
    StructField("source",             StringType(),  True),
    StructField("ingested_at",        StringType(),  True),
])

print(f"Schema: {len(bronze_schema.fields)} columns")

# COMMAND ----------

# ── CELL 4: All functions ─────────────────────────────────────────────────

def load_checkpoint():
    try:
        raw = dbutils.fs.head(CHECKPOINT_PATH, 100000)
        return set(json.loads(raw))
    except Exception:
        return set()

def save_checkpoint(completed_set):
    dbutils.fs.mkdirs(f"{VOL_BASE}/checkpoints/")
    dbutils.fs.put(
        CHECKPOINT_PATH,
        json.dumps(sorted(list(completed_set))),
        overwrite=True
    )

# ── fetch_events_paginated: fixed 422 retry + ChunkedEncodingError ────────

def fetch_events_paginated(dataset, vessel_types, start_date,
                            end_date, batch_size=200, max_retries=5):
    from requests.exceptions import ChunkedEncodingError

    all_events = []
    offset     = 0
    page       = 0

    while True:
        params = {
            "datasets[0]": dataset,
            "start-date":  start_date,
            "end-date":    end_date,
            "limit":       batch_size,
            "offset":      offset,
        }
        for i, vt in enumerate(vessel_types):
            params[f"vessel-types[{i}]"] = vt

        response = None
        success  = False

        for attempt in range(max_retries):
            try:
                response = requests.get(
                    f"{BASE_URL}/events",
                    headers=HEADERS,
                    params=params,
                    timeout=45
                )

                if response.status_code == 200:
                    success = True
                    break

                elif response.status_code == 429:
                    wait_s = int(response.headers.get("Retry-After", 60))
                    print(f"    Rate limit. Waiting {wait_s}s...")
                    time.sleep(wait_s)

                elif response.status_code == 422:
                    # Transient GFW error — retry with backoff
                    wait_s = 30 * (attempt + 1)
                    print(f"    422 transient page {page}. "
                          f"Attempt {attempt+1}/{max_retries}. "
                          f"Waiting {wait_s}s...")
                    time.sleep(wait_s)

                elif response.status_code in (500, 502, 503, 504):
                    wait_s = 15 * (attempt + 1)
                    print(f"    Server error {response.status_code}. "
                          f"Attempt {attempt+1}/{max_retries}. "
                          f"Waiting {wait_s}s...")
                    time.sleep(wait_s)

                else:
                    print(f"    Unknown {response.status_code}: "
                          f"{response.text[:100]}")
                    time.sleep(10)

            except requests.exceptions.Timeout:
                wait_s = 20 * (attempt + 1)
                print(f"    Timeout attempt {attempt+1}/{max_retries}. "
                      f"Waiting {wait_s}s...")
                time.sleep(wait_s)

            except ChunkedEncodingError:
                wait_s = 30 * (attempt + 1)
                print(f"    ChunkedEncodingError page {page}. "
                      f"Attempt {attempt+1}/{max_retries}. "
                      f"Waiting {wait_s}s...")
                time.sleep(wait_s)

            except requests.exceptions.ConnectionError:
                wait_s = 20 * (attempt + 1)
                print(f"    Connection error attempt {attempt+1}. "
                      f"Waiting {wait_s}s...")
                time.sleep(wait_s)

        if not success:
            print(f"    Max retries exceeded page {page} "
                  f"offset {offset}. Stopping this month.")
            break

        batch = response.json().get("entries", [])
        all_events.extend(batch)
        page += 1

        if page % 10 == 0:
            print(f"    Page {page:>4} | offset {offset:>7} | "
                  f"total fetched: {len(all_events):>8,}")

        if len(batch) < batch_size:
            break

        offset   += batch_size
        time.sleep(1.2)

    return all_events

# ── parse_port_visit: unchanged ───────────────────────────────────────────

def parse_port_visit(event):
    vessel    = event.get("vessel",     {})
    pv        = event.get("port_visit", {})
    start_anc = pv.get("startAnchorage", {}) or {}
    end_anc   = pv.get("endAnchorage",   {}) or {}
    position  = event.get("position",    {}) or {}
    regions   = event.get("regions",     {}) or {}

    raw_dur = pv.get("durationHrs")
    if raw_dur is not None:
        try:
            raw_dur = float(raw_dur)
            if raw_dur > 8760:
                raw_dur = raw_dur / 3600.0
        except (TypeError, ValueError):
            raw_dur = None

    try:
        confidence = int(pv.get("confidence", 0) or 0)
    except (TypeError, ValueError):
        confidence = 0

    eez_list   = regions.get("eez", [])
    region_eez = str(eez_list[0]) if eez_list else ""

    return {
        "event_id":           str(event.get("id", "")),
        "vessel_id":          str(vessel.get("id", "")),
        "mmsi":               str(vessel.get("ssvid", "")),
        "vessel_name":        str(vessel.get("name", "")),
        "vessel_type":        str(vessel.get("type", "")),
        "flag":               str(vessel.get("flag", "")),
        "next_port":          str(vessel.get("nextPort", "") or ""),
        "start_ts":           str(event.get("start", "")),
        "end_ts":             str(event.get("end", "")),
        "lat":                float(position["lat"]) if position.get("lat") else None,
        "lon":                float(position["lon"]) if position.get("lon") else None,
        "start_port_name":    str(start_anc.get("name", "") or ""),
        "start_port_country": str(start_anc.get("flag", "") or ""),
        "start_port_lat":     float(start_anc["lat"]) if start_anc.get("lat") else None,
        "start_port_lon":     float(start_anc["lon"]) if start_anc.get("lon") else None,
        "end_port_name":      str(end_anc.get("name", "") or ""),
        "end_port_country":   str(end_anc.get("flag", "") or ""),
        "end_port_lat":       float(end_anc["lat"]) if end_anc.get("lat") else None,
        "end_port_lon":       float(end_anc["lon"]) if end_anc.get("lon") else None,
        "duration_hrs":       raw_dur,
        "confidence":         confidence,
        "visit_id":           str(pv.get("visitId", "") or ""),
        "region_eez":         region_eez,
        "source":             "GFW_EVENTS_V3",
        "ingested_at":        datetime.utcnow().isoformat(),
    }

# ── write_month_to_delta: now returns (rows_written, is_complete) ─────────
# Months with < 50,000 rows are NOT checkpointed — they retry next run.
# Normal range is 150,000 - 220,000 rows per month.

def write_month_to_delta(rows, year_month_str, min_expected=50000):
    if not rows:
        print(f"    No rows for {year_month_str}.")
        return 0, False

    parsed = [parse_port_visit(e) for e in rows]
    df_pd  = pd.DataFrame(parsed).drop_duplicates(subset=["event_id"])
    row_count = len(df_pd)

    # Guard against truncated months from 422 errors
    if row_count < min_expected:
        print(f"    WARNING: only {row_count:,} rows — "
              f"expected ~150k-220k. "
              f"NOT checkpointing — will retry next run.")
        # Still write what we have so partial data is not lost,
        # but return is_complete=False so checkpoint is skipped
        if row_count > 0:
            _write_df(df_pd)
        return row_count, False

    _write_df(df_pd)
    return row_count, True

def _write_df(df_pd):
    """Internal: coerce types and write/merge DataFrame to Delta."""
    float_cols = ["lat", "lon", "duration_hrs",
                  "start_port_lat", "start_port_lon",
                  "end_port_lat",   "end_port_lon"]
    for c in float_cols:
        df_pd[c] = pd.to_numeric(df_pd[c], errors="coerce")

    df_pd["confidence"] = (
        pd.to_numeric(df_pd["confidence"], errors="coerce")
          .fillna(0).astype(int)
    )

    str_cols = ["event_id", "vessel_id", "mmsi", "vessel_name",
                "vessel_type", "flag", "next_port", "start_ts", "end_ts",
                "start_port_name", "start_port_country",
                "end_port_name", "end_port_country",
                "visit_id", "region_eez", "source", "ingested_at"]
    for c in str_cols:
        df_pd[c] = df_pd[c].fillna("").astype(str)

    df_spark = spark.createDataFrame(df_pd, schema=bronze_schema)

    if not DeltaTable.isDeltaTable(spark, OUTPUT_PATH):
        (df_spark.write.format("delta").mode("overwrite")
            .option("overwriteSchema", "true").save(OUTPUT_PATH))
    else:
        (DeltaTable.forPath(spark, OUTPUT_PATH)
            .alias("existing")
            .merge(df_spark.alias("incoming"),
                   "existing.event_id = incoming.event_id")
            .whenMatchedUpdateAll()
            .whenNotMatchedInsertAll()
            .execute())

print("All functions defined.")
print("  load_checkpoint()")
print("  save_checkpoint()")
print("  fetch_events_paginated()  ← 422 retry + ChunkedEncodingError fixed")
print("  parse_port_visit()")
print("  write_month_to_delta()    ← returns (rows, is_complete)")
print("  _write_df()")

# COMMAND ----------

# ── CELL 5: Month list for this year only ─────────────────────────────────

all_months = []
for month in range(1, 13):
    last_day = calendar.monthrange(YEAR, month)[1]
    all_months.append({
        "key":   f"{YEAR}-{month:02d}",
        "start": f"{YEAR}-{month:02d}-01",
        "end":   f"{YEAR}-{month:02d}-{last_day:02d}",
    })

print(f"Year {YEAR} — {len(all_months)} months to process")
for m in all_months:
    print(f"  {m['key']}  ({m['start']} → {m['end']})")

# COMMAND ----------

# ── CELL 6: Checkpoint status ─────────────────────────────────────────────

completed = load_checkpoint()
remaining = [m for m in all_months if m["key"] not in completed]

print(f"Year {YEAR} status:")
print(f"  Completed : {len(completed)}/12")
print(f"  Remaining : {len(remaining)}/12")
if completed:
    print(f"  Last done : {sorted(completed)[-1]}")
if remaining:
    print(f"  Next      : {remaining[0]['key']}")
else:
    print(f"  YEAR {YEAR} COMPLETE")

# COMMAND ----------

# ── CELL 7: Ingestion loop ────────────────────────────────────────────────

import builtins

completed      = load_checkpoint()
remaining      = [m for m in all_months if m["key"] not in completed]
session_rows   = 0
session_months = 0
skipped_months = []

print(f"Year {YEAR} — {len(remaining)} months remaining")
print("─" * 55)

for i, month in enumerate(remaining):
    key, start, end = month["key"], month["start"], month["end"]
    print(f"\n[{i+1:>2}/{len(remaining)}]  {key}  ({start} → {end})")

    t0         = time.time()
    raw_events = fetch_events_paginated(
        DATASET, VESSEL_TYPES, start, end,
        batch_size=200, max_retries=5
    )

    rows_written, is_complete = write_month_to_delta(raw_events, key)
    elapsed = builtins.round(time.time() - t0, 1)

    if is_complete:
        completed.add(key)
        save_checkpoint(completed)
        print(f"    {len(raw_events):>8,} events | "
              f"{rows_written:>8,} written | "
              f"{elapsed:>6.1f}s | checkpoint saved")
    else:
        skipped_months.append(key)
        print(f"    {len(raw_events):>8,} events | "
              f"{rows_written:>8,} written | "
              f"{elapsed:>6.1f}s | NOT checkpointed — will retry")

    session_rows   += rows_written
    session_months += 1

    time.sleep(2)

print(f"\n{'='*55}")
print(f"  YEAR {YEAR} SESSION COMPLETE")
print(f"  Months processed this session : {session_months}")
print(f"  Rows written this session     : {session_rows:,}")
print(f"  Total checkpointed            : {len(completed)}/12")

if skipped_months:
    print(f"\n  Months NOT checkpointed (will retry): {skipped_months}")
    print(f"  Re-run this job to retry these months.")

if len(completed) == 12:
    print(f"\n  YEAR {YEAR} FULLY INGESTED")
else:
    print(f"  {12 - len(completed)} months remain — re-run job to continue")
print(f"{'='*55}")