# Databricks notebook source
# ── CELL 1: Credentials ───────────────────────────────────────────────────

EIA_KEY   = "your-api-key"
FRED_KEY  = "your-api-key"

# COMMAND ----------

# ── CELL 2: Imports and paths ─────────────────────────────────────────────

import requests
import time
import json
import pandas as pd
import builtins
from datetime import datetime

from pyspark.sql import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import col
from delta.tables import DeltaTable

spark = SparkSession.builder.getOrCreate()

VOL_BASE = "/Volumes/workspace/oil_intel/project_data"

BRONZE_MARKET = f"{VOL_BASE}/bronze/market"
BRONZE_EIA    = f"{VOL_BASE}/bronze/eia"
BRONZE_FRED   = f"{VOL_BASE}/bronze/fred"
BRONZE_OPEC   = f"{VOL_BASE}/bronze/opec_events"

START = "2017-01-01"
END   = "2023-12-31"

print("Paths configured.")
print(f"  Market : {BRONZE_MARKET}")
print(f"  EIA    : {BRONZE_EIA}")
print(f"  FRED   : {BRONZE_FRED}")
print(f"  OPEC   : {BRONZE_OPEC}")

# COMMAND ----------

# ── CELL 2b: Install missing packages ────────────────────────────────────

import subprocess

packages = ["yfinance", "pandas_datareader"]

for pkg in packages:
    print(f"Installing {pkg}...")
    result = subprocess.run(
        ["pip", "install", pkg, "-q"],
        capture_output=True, text=True
    )
    if result.returncode == 0:
        print(f"  {pkg} installed successfully")
    else:
        print(f"  {pkg} error: {result.stderr[:200]}")

# Verify
import yfinance as yf
print(f"\nyfinance version: {yf.__version__}")
print("Ready to pull market data.")

# COMMAND ----------

# ── CELL 3: Market data — Brent + DXY via yfinance ───────────────────────

import yfinance as yf

print("Downloading market data from Yahoo Finance...")

tickers = {
    "BZ=F":     "brent",
    "DX-Y.NYB": "dxy",
}

market_schema = StructType([
    StructField("trade_date",      StringType(), True),
    StructField("open",            DoubleType(), True),
    StructField("high",            DoubleType(), True),
    StructField("low",             DoubleType(), True),
    StructField("close",           DoubleType(), True),
    StructField("volume",          DoubleType(), True),
    StructField("ticker",          StringType(), True),
    StructField("instrument_name", StringType(), True),
    StructField("source",          StringType(), True),
    StructField("ingested_at",     StringType(), True),
])

dfs = []
for ticker, name in tickers.items():
    print(f"  Pulling {ticker} ({name})...")
    df = yf.download(
        ticker,
        start=START,
        end=END,
        auto_adjust=True,
        progress=False
    )
    df = df.reset_index()

    # yfinance returns MultiIndex columns sometimes — flatten
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = [c[0].lower() if c[1] == "" else c[0].lower()
                      for c in df.columns]
    else:
        df.columns = [c.lower().replace(" ", "_") for c in df.columns]

    # Rename date column
    date_col = [c for c in df.columns if "date" in c.lower()]
    if date_col:
        df = df.rename(columns={date_col[0]: "trade_date"})

    df["ticker"]          = ticker
    df["instrument_name"] = name
    df["source"]          = "YFINANCE"
    df["ingested_at"]     = datetime.utcnow().isoformat()
    df["trade_date"]      = df["trade_date"].astype(str)

    # Ensure volume column exists
    if "volume" not in df.columns:
        df["volume"] = 0.0
    df["volume"] = pd.to_numeric(df["volume"], errors="coerce").fillna(0.0)

    # Keep only schema columns
    keep = ["trade_date","open","high","low","close","volume",
            "ticker","instrument_name","source","ingested_at"]
    df = df[[c for c in keep if c in df.columns]]

    # Fill any missing schema columns
    for c in keep:
        if c not in df.columns:
            df[c] = None

    dfs.append(df)
    print(f"    {len(df)} rows pulled ({df['trade_date'].min()} "
          f"→ {df['trade_date'].max()})")
    time.sleep(1)

df_market = pd.concat(dfs, ignore_index=True)
print(f"\n  Total market rows: {len(df_market):,}")
print(df_market.head(3).to_string())

# COMMAND ----------

# ── CELL 4: Write market data to Delta ───────────────────────────────────

# Coerce numeric columns
for c in ["open", "high", "low", "close", "volume"]:
    df_market[c] = pd.to_numeric(df_market[c], errors="coerce")
for c in ["trade_date","ticker","instrument_name","source","ingested_at"]:
    df_market[c] = df_market[c].fillna("").astype(str)

df_spark = spark.createDataFrame(df_market, schema=market_schema)

df_spark.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .save(BRONZE_MARKET)

count = spark.read.format("delta").load(BRONZE_MARKET).count()
print(f"Market data written: {count:,} rows → {BRONZE_MARKET}")

# Quick check
print("\nTicker coverage:")
(spark.read.format("delta").load(BRONZE_MARKET)
    .groupBy("ticker", "instrument_name")
    .agg(
        {"trade_date": "count", "close": "avg"}
    )
    .show(truncate=False))

# COMMAND ----------

# ── CELL 6: EIA — 8 weekly series ────────────────────────────────────────

EIA_BASE   = "https://api.eia.gov/v2/petroleum/sum/sndw/data/"

SERIES_MAP = {
    "WCRSTUS1": "us_crude_stocks_mbbl",
    "WCSSTUS1": "spr_stocks_mbbl",
    "WTTSTUS1": "total_petroleum_stocks_mbbl",
    "WCRFPUS2": "us_production_mbbld",
    "WCRRIUS2": "refinery_utilisation_pct",
    "WCRIMUS2": "imports_mbbld",
    "WCREXUS2": "exports_mbbld",
}

eia_schema = StructType([
    StructField("period",      StringType(), True),
    StructField("series_id",   StringType(), True),
    StructField("series_name", StringType(), True),
    StructField("value",       DoubleType(), True),
    StructField("units",       StringType(), True),
    StructField("source",      StringType(), True),
    StructField("ingested_at", StringType(), True),
])

print("Pulling EIA data...")
all_eia = []

for series_id, series_name in SERIES_MAP.items():
    params = {
        "api_key":            EIA_KEY,
        "frequency":          "weekly",
        "data[0]":            "value",
        "facets[series][]":   series_id,
        "start":              START,
        "end":                END,
        "sort[0][column]":    "period",
        "sort[0][direction]": "asc",
        "length":             5000,
    }

    r = requests.get(EIA_BASE, params=params, timeout=30)

    if r.status_code != 200:
        print(f"  ERROR {r.status_code} for {series_id}: {r.text[:100]}")
        continue

    data = r.json().get("response", {}).get("data", [])

    for row in data:
        val = row.get("value")
        all_eia.append({
            "period":      str(row.get("period", "")),
            "series_id":   series_id,
            "series_name": series_name,
            "value":       float(val) if val is not None else None,
            "units":       str(row.get("units", "")),
            "source":      "EIA_API_V2",
            "ingested_at": datetime.utcnow().isoformat(),
        })

    print(f"  {series_id:<12} {series_name:<35} {len(data):>4} rows")
    time.sleep(0.5)

df_eia = pd.DataFrame(all_eia)
print(f"\nTotal EIA rows: {len(df_eia):,}")

# COMMAND ----------

# ── CELL 7: Write EIA to Delta ────────────────────────────────────────────

df_eia["value"] = pd.to_numeric(df_eia["value"], errors="coerce")
for c in ["period","series_id","series_name","units","source","ingested_at"]:
    df_eia[c] = df_eia[c].fillna("").astype(str)

df_eia_spark = spark.createDataFrame(df_eia, schema=eia_schema)

exists = DeltaTable.isDeltaTable(spark, BRONZE_EIA)
if not exists:
    df_eia_spark.write.format("delta").mode("overwrite") \
        .option("overwriteSchema","true") \
        .partitionBy("series_id").save(BRONZE_EIA)
else:
    (DeltaTable.forPath(spark, BRONZE_EIA).alias("e")
        .merge(df_eia_spark.alias("n"),
               "e.period = n.period AND e.series_id = n.series_id")
        .whenMatchedUpdateAll()
        .whenNotMatchedInsertAll()
        .execute())

count = spark.read.format("delta").load(BRONZE_EIA).count()
print(f"EIA written: {count:,} rows → {BRONZE_EIA}")

print("\nSeries coverage:")
(spark.read.format("delta").load(BRONZE_EIA)
    .groupBy("series_id", "series_name")
    .count()
    .orderBy("series_id")
    .show(truncate=False))

# COMMAND ----------

# ── CELL 8: FRED — TB3MS risk-free rate ──────────────────────────────────

print("Pulling FRED TB3MS (3-month T-bill rate)...")

fred_schema = StructType([
    StructField("period",      StringType(), True),
    StructField("series_id",   StringType(), True),
    StructField("series_name", StringType(), True),
    StructField("value",       DoubleType(), True),
    StructField("units",       StringType(), True),
    StructField("source",      StringType(), True),
    StructField("ingested_at", StringType(), True),
])

r = requests.get(
    "https://api.stlouisfed.org/fred/series/observations",
    params={
        "api_key":           FRED_KEY,
        "series_id":         "TB3MS",
        "observation_start": START,
        "observation_end":   END,
        "file_type":         "json",
        "frequency":         "m",
    },
    timeout=30
)

print(f"Status: {r.status_code}")
obs = r.json().get("observations", [])

fred_rows = []
for o in obs:
    val = o.get("value", ".")
    fred_rows.append({
        "period":      str(o.get("date", "")),
        "series_id":   "TB3MS",
        "series_name": "3_month_tbill_rate_pct",
        "value":       float(val) if val != "." else None,
        "units":       "percent_annual",
        "source":      "FRED_API",
        "ingested_at": datetime.utcnow().isoformat(),
    })

df_fred = pd.DataFrame(fred_rows)
print(f"FRED rows: {len(df_fred)}")
print(df_fred.tail(5).to_string())

# COMMAND ----------

# ── CELL 9: Write FRED to Delta ───────────────────────────────────────────

df_fred["value"] = pd.to_numeric(df_fred["value"], errors="coerce")
for c in ["period","series_id","series_name","units","source","ingested_at"]:
    df_fred[c] = df_fred[c].fillna("").astype(str)

spark.createDataFrame(df_fred, schema=fred_schema) \
    .write.format("delta").mode("overwrite") \
    .option("overwriteSchema","true").save(BRONZE_FRED)

count = spark.read.format("delta").load(BRONZE_FRED).count()
print(f"FRED written: {count} rows → {BRONZE_FRED}")
print(f"Expected: ~84 rows (monthly 2017-2023)")

# COMMAND ----------

# ── CELL 10: OPEC events — upload CSV first, then load ───────────────────
# If you haven't uploaded opec_events.csv yet:
#   Catalog → workspace → oil_intel → project_data volume
#   → Upload → select opec_events.csv
#   It lands at /Volumes/workspace/oil_intel/project_data/opec_events.csv

opec_schema = StructType([
    StructField("event_date",     StringType(), True),
    StructField("event_type",     StringType(), True),
    StructField("location",       StringType(), True),
    StructField("outcome",        StringType(), True),
    StructField("cut_size_mbbld", DoubleType(), True),
    StructField("notes",          StringType(), True),
    StructField("source",         StringType(), True),
    StructField("ingested_at",    StringType(), True),
])

OPEC_CSV_PATH = f"{VOL_BASE}/opec_events.csv"

# Check file exists
try:
    dbutils.fs.ls(OPEC_CSV_PATH)
    print(f"Found: {OPEC_CSV_PATH}")
except Exception:
    raise FileNotFoundError(
        f"opec_events.csv not found at {OPEC_CSV_PATH}\n"
        f"Upload it via: Catalog → oil_intel volume → Upload"
    )

df_opec = pd.read_csv(f"/Volumes/workspace/oil_intel/project_data/opec_events.csv")
df_opec["source"]       = "MANUAL_OPEC_WEBSITE"
df_opec["ingested_at"]  = datetime.utcnow().isoformat()
df_opec["event_date"]   = df_opec["event_date"].astype(str)
df_opec["cut_size_mbbld"] = pd.to_numeric(
    df_opec.get("cut_size_mbbld", pd.Series(dtype=float)),
    errors="coerce"
)

for c in ["event_type","location","outcome","notes","source","ingested_at"]:
    if c in df_opec.columns:
        df_opec[c] = df_opec[c].fillna("").astype(str)
    else:
        df_opec[c] = ""

print(f"OPEC rows loaded: {len(df_opec)}")
print(df_opec[["event_date","outcome","cut_size_mbbld"]].to_string())

# COMMAND ----------

# ── CELL 11: Write OPEC to Delta ──────────────────────────────────────────

spark.createDataFrame(df_opec, schema=opec_schema) \
    .write.format("delta").mode("overwrite") \
    .option("overwriteSchema","true").save(BRONZE_OPEC)

count = spark.read.format("delta").load(BRONZE_OPEC).count()
print(f"OPEC written: {count} rows → {BRONZE_OPEC}")
print(f"Expected: 37 rows")

# COMMAND ----------

# ── CELL 12: Bronze layer completion check ────────────────────────────────

tables = {
    "GFW port visits": f"{VOL_BASE}/bronze/gfw_port_visits",
    "Market (Brent+DXY)": BRONZE_MARKET,
    "EIA inventory":    BRONZE_EIA,
    "FRED T-bill":      BRONZE_FRED,
    "OPEC events":      BRONZE_OPEC,
}

print("=" * 58)
print("  BRONZE LAYER STATUS")
print("=" * 58)
print(f"  {'Table':<25} {'Rows':>12}  Status")
print(f"  {'─'*50}")

all_ok = True
for name, path in tables.items():
    try:
        n      = spark.read.format("delta").load(path).count()
        status = "OK" if n > 0 else "EMPTY"
        if n == 0:
            all_ok = False
    except Exception as ex:
        n, status = 0, f"MISSING"
        all_ok = False
    print(f"  {name:<25} {n:>12,}  {status}")

print("=" * 58)
if all_ok:
    print("  All Bronze tables populated.")
    print("  GFW re-ingestion still running for 2017-08/09.")
    print("  Once that completes → start Phase 2 Silver.")
else:
    print("  Fix missing tables before Silver.")
print("=" * 58)

# COMMAND ----------

