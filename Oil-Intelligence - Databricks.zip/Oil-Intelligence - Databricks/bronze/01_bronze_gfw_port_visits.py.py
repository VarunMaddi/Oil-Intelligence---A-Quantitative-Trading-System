# Databricks notebook source
# ── CELL 1: Credentials ───────────────────────────────────────────────────

GFW_TOKEN = "add-your-api-key"
EIA_KEY   = "add-your-api-key"
FRED_KEY  = "add-your-api-key"


# COMMAND ----------

# ── CELL 2: Imports and all path constants ────────────────────────────────

import requests
import time
import json
import pandas as pd
import calendar
from datetime import datetime

from pyspark.sql import SparkSession
from pyspark.sql.types import (
    StructType, StructField,
    StringType, DoubleType, IntegerType
)
from pyspark.sql.functions import (
    col, to_date, to_timestamp,
    min as spark_min, max as spark_max,
    year as spark_year, month as spark_month,
    avg, percentile_approx,
    round as spark_round, count,
    isnull, row_number
)
from pyspark.sql.window import Window
from delta.tables import DeltaTable

spark = SparkSession.builder.getOrCreate()

# ── Volume path ───────────────────────────────────────────────────────────
CATALOG  = "workspace"
SCHEMA   = "oil_intel"
VOLUME   = "project_data"
VOL_BASE = f"/Volumes/{CATALOG}/{SCHEMA}/{VOLUME}"

# ── API config ────────────────────────────────────────────────────────────
BASE_URL     = "https://gateway.api.globalfishingwatch.org/v3"
HEADERS      = {
    "Authorization": f"Bearer {GFW_TOKEN}",
    "Content-Type":  "application/json"
}
DATASET      = "public-global-port-visits-c2-events:latest"
VESSEL_TYPES = ["BUNKER", "CARGO"]

# ── Bronze paths ──────────────────────────────────────────────────────────
BRONZE_PORT_VISITS = f"{VOL_BASE}/bronze/gfw_port_visits"
BRONZE_LOITERING   = f"{VOL_BASE}/bronze/gfw_loitering"
BRONZE_AIS_GAPS    = f"{VOL_BASE}/bronze/gfw_ais_gaps"
BRONZE_MARKET      = f"{VOL_BASE}/bronze/market"
BRONZE_EIA         = f"{VOL_BASE}/bronze/eia"
BRONZE_FRED        = f"{VOL_BASE}/bronze/fred"
BRONZE_OPEC        = f"{VOL_BASE}/bronze/opec_events"

# ── Silver paths ──────────────────────────────────────────────────────────
SILVER_DATE_SPINE       = f"{VOL_BASE}/silver/date_spine"
SILVER_PORT_VISITS_FLAT = f"{VOL_BASE}/silver/port_visits_flat"
SILVER_VESSEL_DAILY     = f"{VOL_BASE}/silver/ais_vessel_daily"
SILVER_LOITERING_DAILY  = f"{VOL_BASE}/silver/ais_loitering_daily"
SILVER_GAPS_DAILY       = f"{VOL_BASE}/silver/ais_gaps_daily"
SILVER_MARKET_DAILY     = f"{VOL_BASE}/silver/market_daily"
SILVER_EIA_DAILY        = f"{VOL_BASE}/silver/eia_daily"
SILVER_MACRO_DAILY      = f"{VOL_BASE}/silver/macro_daily"
SILVER_OPEC_FLAGS       = f"{VOL_BASE}/silver/opec_flags"

# ── Gold paths ────────────────────────────────────────────────────────────
GOLD_FEATURE_STORE    = f"{VOL_BASE}/gold/feature_store"
GOLD_PREDICTIONS      = f"{VOL_BASE}/gold/predictions"
GOLD_SIGNALS          = f"{VOL_BASE}/gold/signals"
GOLD_BACKTEST_DAILY   = f"{VOL_BASE}/gold/backtest_daily"
GOLD_PERF_METRICS     = f"{VOL_BASE}/gold/performance_metrics"
GOLD_BACKTEST_SUMMARY = f"{VOL_BASE}/gold/backtest_summary"

# ── Checkpoint paths ──────────────────────────────────────────────────────
CKPT_PORT_VISITS = f"{VOL_BASE}/checkpoints/bronze_port_visits.json"
CKPT_LOITERING   = f"{VOL_BASE}/checkpoints/bronze_loitering.json"
CKPT_AIS_GAPS    = f"{VOL_BASE}/checkpoints/bronze_ais_gaps.json"

# ── Exports ───────────────────────────────────────────────────────────────
EXPORTS_DIR = f"{VOL_BASE}/exports"

# ── This notebook ─────────────────────────────────────────────────────────
OUTPUT_PATH     = BRONZE_PORT_VISITS
CHECKPOINT_PATH = CKPT_PORT_VISITS

# ── Date range ────────────────────────────────────────────────────────────
START_YEAR = 2017
END_YEAR   = 2023

print("Imports and paths configured.")
print(f"  VOL_BASE    : {VOL_BASE}")
print(f"  OUTPUT_PATH : {OUTPUT_PATH}")
print(f"  CHECKPOINT  : {CHECKPOINT_PATH}")
print(f"  Date range  : {START_YEAR} → {END_YEAR}")

# COMMAND ----------

# ── CELL 3: Create directory structure + storage tests ────────────────────

# Step 1 — confirm volume is reachable
try:
    dbutils.fs.ls(VOL_BASE)
    print(f"Volume confirmed : {VOL_BASE}")
except Exception as e:
    raise Exception(
        f"Volume not found at {VOL_BASE}\n"
        f"Error: {e}\n"
        f"Check Catalog → workspace → oil_intel → project_data exists."
    )

# Step 2 — create subdirectory structure
dirs = [
    f"{VOL_BASE}/bronze",
    f"{VOL_BASE}/silver",
    f"{VOL_BASE}/gold",
    f"{VOL_BASE}/checkpoints",
    f"{VOL_BASE}/exports",
]

print("\nCreating directories:")
for d in dirs:
    dbutils.fs.mkdirs(d)
    print(f"  OK  {d}")

# Step 3 — plain file write test
test_file = f"{VOL_BASE}/checkpoints/_test.txt"
dbutils.fs.put(test_file, "hello", overwrite=True)
content   = dbutils.fs.head(test_file)
dbutils.fs.rm(test_file)
assert "hello" in content, "File write test failed"
print("\nFile write test        PASSED")

# Step 4 — Spark Delta write test
(spark.createDataFrame([("test", 1)], ["a", "b"])
    .write.format("delta")
    .mode("overwrite")
    .save(f"{VOL_BASE}/checkpoints/_delta_test"))

n = spark.read.format("delta") \
    .load(f"{VOL_BASE}/checkpoints/_delta_test").count()

dbutils.fs.rm(f"{VOL_BASE}/checkpoints/_delta_test", recurse=True)
assert n == 1, "Spark Delta write test failed"
print("Spark Delta write test PASSED")

print(f"\nAll storage ready.")
print(f"Base path: {VOL_BASE}")

# COMMAND ----------

# ── CELL 4: Quick API connectivity test ───────────────────────────────────
# Confirms GFW token and dataset name are valid before the long ingestion.
# Fix any errors here — do not proceed to Cell 5+ if this fails.

test_params = {
    "datasets[0]":     DATASET,
    "vessel-types[0]": "BUNKER",
    "start-date":      "2022-06-01",
    "end-date":        "2022-06-03",
    "limit":           3,
    "offset":          0,
}

r = requests.get(
    f"{BASE_URL}/events",
    headers=HEADERS,
    params=test_params,
    timeout=20
)

print(f"Status : {r.status_code}")

if r.status_code == 200:
    data    = r.json()
    total   = data.get("total", 0)
    entries = data.get("entries", [])
    print(f"Total events in test window : {total:,}")
    print(f"Entries returned            : {len(entries)}")
    if entries:
        e = entries[0]
        print(f"\nTop-level keys  : {list(e.keys())}")
        if "vessel" in e:
            print(f"vessel keys     : {list(e['vessel'].keys())}")
        pv_key = "port_visit" if "port_visit" in e else "portVisit"
        if pv_key in e:
            print(f"{pv_key} keys : {list(e[pv_key].keys())}")
    print("\nConnectivity test PASSED — safe to proceed to Cell 5.")

elif r.status_code == 401:
    raise Exception(
        "401 Unauthorized — GFW_TOKEN is wrong or expired.\n"
        "Re-check Cell 1 and paste the correct token."
    )
elif r.status_code == 403:
    raise Exception(
        "403 Forbidden — dataset name may be wrong "
        "or your account tier does not include it."
    )
elif r.status_code == 422:
    raise Exception(f"422 Unprocessable — {r.text[:400]}")
else:
    raise Exception(f"Unexpected {r.status_code}: {r.text[:300]}")

# COMMAND ----------

# ── CELL 5: Bronze schema ─────────────────────────────────────────────────

bronze_schema = StructType([
    StructField("event_id",           StringType(),  nullable=True),
    StructField("vessel_id",          StringType(),  nullable=True),
    StructField("mmsi",               StringType(),  nullable=True),
    StructField("vessel_name",        StringType(),  nullable=True),
    StructField("vessel_type",        StringType(),  nullable=True),
    StructField("flag",               StringType(),  nullable=True),
    StructField("next_port",          StringType(),  nullable=True),
    StructField("start_ts",           StringType(),  nullable=True),
    StructField("end_ts",             StringType(),  nullable=True),
    StructField("lat",                DoubleType(),  nullable=True),
    StructField("lon",                DoubleType(),  nullable=True),
    StructField("start_port_name",    StringType(),  nullable=True),
    StructField("start_port_country", StringType(),  nullable=True),
    StructField("start_port_lat",     DoubleType(),  nullable=True),
    StructField("start_port_lon",     DoubleType(),  nullable=True),
    StructField("end_port_name",      StringType(),  nullable=True),
    StructField("end_port_country",   StringType(),  nullable=True),
    StructField("end_port_lat",       DoubleType(),  nullable=True),
    StructField("end_port_lon",       DoubleType(),  nullable=True),
    StructField("duration_hrs",       DoubleType(),  nullable=True),
    StructField("confidence",         IntegerType(), nullable=True),
    StructField("visit_id",           StringType(),  nullable=True),
    StructField("region_eez",         StringType(),  nullable=True),
    StructField("source",             StringType(),  nullable=True),
    StructField("ingested_at",        StringType(),  nullable=True),
])

print(f"Schema defined — {len(bronze_schema.fields)} columns.")
for f in bronze_schema.fields:
    print(f"  {f.name:<26} {str(f.dataType)}")

# COMMAND ----------

# ── CELL 6: Core functions ────────────────────────────────────────────────

# ── 6a: Checkpoint helpers ────────────────────────────────────────────────

def load_checkpoint():
    """
    Load set of completed month keys from Volume.
    Returns empty set on first run — the except is expected and harmless.
    """
    try:
        raw = dbutils.fs.head(CHECKPOINT_PATH, 100000)
        return set(json.loads(raw))
    except Exception:
        return set()

def save_checkpoint(completed_set):
    """Persist completed months to Volume checkpoint file."""
    dbutils.fs.mkdirs(f"{VOL_BASE}/checkpoints/")
    dbutils.fs.put(
        CHECKPOINT_PATH,
        json.dumps(sorted(list(completed_set))),
        overwrite=True
    )

# ── 6b: Pagination fetcher ────────────────────────────────────────────────

def fetch_events_paginated(dataset, vessel_types, start_date,
                            end_date, batch_size=200, max_retries=3):
    """
    Fetch all events for a date range using offset pagination.
    Handles 429 rate limits, 5xx server errors, timeouts,
    and connection drops with automatic retry.
    Returns list of raw event dicts.
    """
    all_events = []
    offset     = 0
    page       = 0

    while True:
        params = {
            "datasets[0]": dataset,
            "start-date":  start_date,
            "end-date":    end_date,
            "limit":       batch_size,
            "offset":      offset,
        }
        for i, vt in enumerate(vessel_types):
            params[f"vessel-types[{i}]"] = vt

        response = None
        for attempt in range(max_retries):
            try:
                response = requests.get(
                    f"{BASE_URL}/events",
                    headers=HEADERS,
                    params=params,
                    timeout=30
                )
                if response.status_code == 200:
                    break
                elif response.status_code == 429:
                    wait_s = int(response.headers.get("Retry-After", 60))
                    print(f"    Rate limit (429). Waiting {wait_s}s...")
                    time.sleep(wait_s)
                elif response.status_code in (500, 502, 503, 504):
                    wait_s = 10 * (attempt + 1)
                    print(f"    Server error {response.status_code}. "
                          f"Attempt {attempt+1}/{max_retries}. "
                          f"Waiting {wait_s}s...")
                    time.sleep(wait_s)
                else:
                    print(f"    Unrecoverable {response.status_code}: "
                          f"{response.text[:200]}")
                    return all_events

            except requests.exceptions.Timeout:
                print(f"    Timeout — attempt {attempt+1}/{max_retries}. "
                      f"Waiting 15s...")
                time.sleep(15)

            except requests.exceptions.ConnectionError as ex:
                print(f"    Connection error: {ex}. "
                      f"Attempt {attempt+1}/{max_retries}. Waiting 20s...")
                time.sleep(20)

        if response is None or response.status_code != 200:
            print(f"    Max retries exceeded on page {page}. Stopping.")
            break

        batch = response.json().get("entries", [])
        all_events.extend(batch)
        page += 1

        if page % 10 == 0:
            print(f"    Page {page:>4} | offset {offset:>7} | "
                  f"total fetched: {len(all_events):>8,}")

        if len(batch) < batch_size:
            break

        offset   += batch_size
        time.sleep(1.2)

    return all_events

# ── 6c: Parser — matches REAL GFW v3 field structure from Cell 4 ──────────
# Real structure confirmed:
#   top level  : start, end, id, type, position, regions, vessel, port_visit
#   vessel     : id, name, ssvid, flag, type, nextPort
#   port_visit : visitId, confidence, durationHrs,
#                startAnchorage, intermediateAnchorage, endAnchorage
#   anchorage  : id, name, flag, lat, lon, atDock, anchorageId

def parse_port_visit(event):
    """
    Flatten one GFW port visit event into a flat row dict.
    Field names confirmed from live API response in Cell 4.
    Port info lives in port_visit.startAnchorage and endAnchorage.
    """
    vessel     = event.get("vessel", {})
    pv         = event.get("port_visit", {})
    start_anc  = pv.get("startAnchorage",        {}) or {}
    end_anc    = pv.get("endAnchorage",           {}) or {}
    position   = event.get("position",            {}) or {}
    regions    = event.get("regions",             {}) or {}

    # ── Vessel fields ─────────────────────────────────────────────────────
    vessel_id   = str(vessel.get("id",    ""))
    mmsi        = str(vessel.get("ssvid", ""))
    vessel_name = str(vessel.get("name",  ""))
    vessel_type = str(vessel.get("type",  ""))
    flag        = str(vessel.get("flag",  ""))
    next_port   = str(vessel.get("nextPort", "") or "")

    # ── Timestamps ────────────────────────────────────────────────────────
    start_ts = str(event.get("start", ""))
    end_ts   = str(event.get("end",   ""))

    # ── Event centroid position ───────────────────────────────────────────
    lat = position.get("lat")
    lon = position.get("lon")

    # ── Start anchorage (where vessel first anchored / arrived) ──────────
    start_port_name    = str(start_anc.get("name", "")    or "")
    start_port_country = str(start_anc.get("flag", "")    or "")
    start_port_lat     = start_anc.get("lat")
    start_port_lon     = start_anc.get("lon")

    # ── End anchorage (where vessel was when it departed) ─────────────────
    end_port_name    = str(end_anc.get("name", "") or "")
    end_port_country = str(end_anc.get("flag", "") or "")
    end_port_lat     = end_anc.get("lat")
    end_port_lon     = end_anc.get("lon")

    # ── Port visit fields ─────────────────────────────────────────────────
    visit_id = str(pv.get("visitId", "")    or "")

    raw_dur = pv.get("durationHrs")
    if raw_dur is not None:
        try:
            raw_dur = float(raw_dur)
            if raw_dur > 8760:          # sanity: > 1yr in hours = seconds
                raw_dur = raw_dur / 3600.0
        except (TypeError, ValueError):
            raw_dur = None

    try:
        confidence = int(pv.get("confidence", 0) or 0)
    except (TypeError, ValueError):
        confidence = 0

    # ── Regions — grab first EEZ if available ────────────────────────────
    eez_list   = regions.get("eez", [])
    region_eez = str(eez_list[0]) if eez_list else ""

    return {
        "event_id":           str(event.get("id", "")),
        "vessel_id":          vessel_id,
        "mmsi":               mmsi,
        "vessel_name":        vessel_name,
        "vessel_type":        vessel_type,
        "flag":               flag,
        "next_port":          next_port,
        "start_ts":           start_ts,
        "end_ts":             end_ts,
        "lat":                float(lat) if lat is not None else None,
        "lon":                float(lon) if lon is not None else None,
        "start_port_name":    start_port_name,
        "start_port_country": start_port_country,
        "start_port_lat":     float(start_port_lat) if start_port_lat else None,
        "start_port_lon":     float(start_port_lon) if start_port_lon else None,
        "end_port_name":      end_port_name,
        "end_port_country":   end_port_country,
        "end_port_lat":       float(end_port_lat) if end_port_lat else None,
        "end_port_lon":       float(end_port_lon) if end_port_lon else None,
        "duration_hrs":       raw_dur,
        "confidence":         confidence,
        "visit_id":           visit_id,
        "region_eez":         region_eez,
        "source":             "GFW_EVENTS_V3",
        "ingested_at":        datetime.utcnow().isoformat(),
    }

# ── 6d: Single-month Delta writer ─────────────────────────────────────────

def write_month_to_delta(rows, year_month_str):
    """
    Parse, deduplicate and MERGE one month of raw events into Delta.
    Returns count of rows written.
    """
    if not rows:
        print(f"    No rows for {year_month_str} — skipping write.")
        return 0

    parsed = [parse_port_visit(e) for e in rows]
    df_pd  = pd.DataFrame(parsed).drop_duplicates(subset=["event_id"])

    # Type coercions
    float_cols = ["lat", "lon", "duration_hrs",
                  "start_port_lat", "start_port_lon",
                  "end_port_lat",   "end_port_lon"]
    for c in float_cols:
        df_pd[c] = pd.to_numeric(df_pd[c], errors="coerce")

    df_pd["confidence"] = (
        pd.to_numeric(df_pd["confidence"], errors="coerce")
          .fillna(0).astype(int)
    )

    str_cols = ["event_id","vessel_id","mmsi","vessel_name","vessel_type",
                "flag","next_port","start_ts","end_ts",
                "start_port_name","start_port_country",
                "end_port_name","end_port_country",
                "visit_id","region_eez","source","ingested_at"]
    for c in str_cols:
        df_pd[c] = df_pd[c].fillna("").astype(str)

    df_spark = spark.createDataFrame(df_pd, schema=bronze_schema)

    if not DeltaTable.isDeltaTable(spark, OUTPUT_PATH):
        (df_spark.write
            .format("delta")
            .mode("overwrite")
            .option("overwriteSchema", "true")
            .save(OUTPUT_PATH))
    else:
        (DeltaTable.forPath(spark, OUTPUT_PATH)
            .alias("existing")
            .merge(df_spark.alias("incoming"),
                   "existing.event_id = incoming.event_id")
            .whenMatchedUpdateAll()
            .whenNotMatchedInsertAll()
            .execute())

    return len(df_pd)

print("All functions defined:")
print("  load_checkpoint()")
print("  save_checkpoint()")
print("  fetch_events_paginated()")
print("  parse_port_visit()  ← updated for real GFW v3 field names")
print("  write_month_to_delta()")

# COMMAND ----------

# ── CELL 6e: Parser test — verify against the real API response ───────────
# Fetches one real event and prints every parsed field.
# Confirm values look correct before starting the full ingestion loop.

print("Fetching one real event to test parser...\n")

r = requests.get(
    f"{BASE_URL}/events",
    headers=HEADERS,
    params={
        "datasets[0]":     DATASET,
        "vessel-types[0]": "BUNKER",
        "start-date":      "2022-06-01",
        "end-date":        "2022-06-03",
        "limit":           1,
        "offset":          0,
    },
    timeout=20
)

raw_event  = r.json()["entries"][0]
parsed_row = parse_port_visit(raw_event)

print("=== RAW EVENT (key fields) ===")
print(f"  id         : {raw_event.get('id')}")
print(f"  start      : {raw_event.get('start')}")
print(f"  end        : {raw_event.get('end')}")
pv = raw_event.get("port_visit", {})
sa = pv.get("startAnchorage", {})
ea = pv.get("endAnchorage",   {})
print(f"  confidence : {pv.get('confidence')}")
print(f"  durationHrs: {pv.get('durationHrs')}")
print(f"  startAnc   : {sa}")
print(f"  endAnc     : {ea}")
v = raw_event.get("vessel", {})
print(f"  vessel     : {v}")

print("\n=== PARSED ROW ===")
for k, val in parsed_row.items():
    print(f"  {k:<26} = {repr(val)}")

# Validation checks
print("\n=== VALIDATION ===")
checks = [
    ("event_id not empty",       parsed_row["event_id"] != ""),
    ("mmsi not empty",           parsed_row["mmsi"] != ""),
    ("start_ts not empty",       parsed_row["start_ts"] != ""),
    ("start_port_name not empty",parsed_row["start_port_name"] != ""),
    ("duration_hrs is float",    isinstance(parsed_row["duration_hrs"],
                                  (float, type(None)))),
    ("confidence is int",        isinstance(parsed_row["confidence"], int)),
]
all_ok = True
for label, result in checks:
    status = "OK" if result else "FAIL"
    print(f"  {status}  {label}")
    if not result:
        all_ok = False

if all_ok:
    print("\nParser test PASSED — proceed to Cell 7.")
else:
    print("\nParser test FAILED — fix parse_port_visit() before continuing.")

# COMMAND ----------

# ── CELL 7: Build full month list ─────────────────────────────────────────

all_months = []
for year in range(START_YEAR, END_YEAR + 1):
    for month in range(1, 13):
        last_day = calendar.monthrange(year, month)[1]
        all_months.append({
            "key":   f"{year}-{month:02d}",
            "start": f"{year}-{month:02d}-01",
            "end":   f"{year}-{month:02d}-{last_day:02d}",
        })

print(f"Total months : {len(all_months)}")
print(f"First        : {all_months[0]['key']}  "
      f"({all_months[0]['start']} → {all_months[0]['end']})")
print(f"Last         : {all_months[-1]['key']}  "
      f"({all_months[-1]['start']} → {all_months[-1]['end']})")

# COMMAND ----------

# ── CELL 7a: Checkpoint status ────────────────────────────────────────────
# Run this before 7b every session to confirm where you are.
# "Already completed: 0" on first run is correct — not an error.

completed = load_checkpoint()
remaining = [m for m in all_months if m["key"] not in completed]

print(f"Total months      : {len(all_months)}")
print(f"Already completed : {len(completed)}")
print(f"Remaining         : {len(remaining)}")

if completed:
    done = sorted(completed)
    print(f"First completed   : {done[0]}")
    print(f"Last completed    : {done[-1]}")
    try:
        current_rows = spark.read.format("delta").load(OUTPUT_PATH).count()
        print(f"Rows in Delta     : {current_rows:,}")
    except Exception:
        print("Delta table not yet created.")

if remaining:
    print(f"\nNext to process   : {remaining[0]['key']}")
    print(f"Will end at       : {remaining[-1]['key']}")
else:
    print("\nAll 84 months complete — skip to Cell 8.")

# COMMAND ----------

# ── CELL 7b: Main ingestion loop ──────────────────────────────────────────
# One month at a time. Writes to Delta immediately. Saves checkpoint.
# Stop and restart any time — completed months are always skipped.

completed      = load_checkpoint()
remaining      = [m for m in all_months if m["key"] not in completed]

session_rows   = 0
session_months = 0

print(f"Starting ingestion — {len(remaining)} months remaining")
print(f"Estimated time    : ~{len(remaining) * 4} minutes")
print("─" * 60)

for i, month in enumerate(remaining):
    key   = month["key"]
    start = month["start"]
    end   = month["end"]

    print(f"\n[{i+1:>3}/{len(remaining)}]  {key}  ({start} → {end})")

    t0 = time.time()

    raw_events = fetch_events_paginated(
        dataset      = DATASET,
        vessel_types = VESSEL_TYPES,
        start_date   = start,
        end_date     = end,
        batch_size   = 200,
        max_retries  = 3
    )

    rows_written = write_month_to_delta(raw_events, key)

    completed.add(key)
    save_checkpoint(completed)

    elapsed        = round(time.time() - t0, 1)
    session_rows   += rows_written
    session_months += 1

    print(f"    {len(raw_events):>8,} events  |  "
          f"{rows_written:>8,} rows written  |  "
          f"{elapsed:>5.1f}s  |  checkpoint saved")

    # Yearly summary every 12 months
    if session_months % 12 == 0:
        try:
            total_so_far = spark.read.format("delta").load(OUTPUT_PATH).count()
        except Exception:
            total_so_far = 0
        print(f"\n  ── Year boundary ──────────────────────────────────────")
        print(f"  Rows in Delta so far        : {total_so_far:,}")
        print(f"  Months this session         : {session_months}")
        print(f"  Total months done           : {len(completed)}/84")
        print(f"  ────────────────────────────────────────────────────────\n")

    time.sleep(2)

# ── Session summary ───────────────────────────────────────────────────────
print("\n" + "=" * 60)
print("  SESSION COMPLETE")
print("=" * 60)
print(f"  Months this session   : {session_months}")
print(f"  Rows this session     : {session_rows:,}")
print(f"  Total months done     : {len(completed)}/84")
print(f"  Months remaining      : {84 - len(completed)}")

if len(completed) == 84:
    final = spark.read.format("delta").load(OUTPUT_PATH).count()
    print(f"\n  ALL 84 MONTHS COMPLETE")
    print(f"  Final row count : {final:,}")
    print("  Proceed to Cell 8.")
else:
    print(f"\n  {84 - len(completed)} months remaining.")
    print("  Restart cluster → re-run Cells 1,2,6,7,7a → run 7b again.")
    print("  Checkpoint will skip completed months automatically.")

# COMMAND ----------

