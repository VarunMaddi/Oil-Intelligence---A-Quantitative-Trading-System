# Databricks notebook source
# ── CELL 1: Setup ─────────────────────────────────────────────────────────

import json
from pyspark.sql import SparkSession
from pyspark.sql.functions import (
    col, count, countDistinct, to_date, to_timestamp,
    year as spark_year, month as spark_month,
    min as spark_min, max as spark_max,
    avg, sum as spark_sum, when, isnull,
    percentile_approx, round as spark_round
)
import builtins

spark = SparkSession.builder.getOrCreate()

VOL_BASE    = "/Volumes/workspace/oil_intel/project_data"
OUTPUT_PATH = f"{VOL_BASE}/bronze/gfw_port_visits"

print("Setup complete.")
print(f"Validating: {OUTPUT_PATH}")

# COMMAND ----------

# ── CELL 2: Checkpoint completeness across all years ─────────────────────
# Confirms all 84 months are marked done in their respective checkpoints.

print("=" * 60)
print("  CHECKPOINT COMPLETENESS CHECK")
print("=" * 60)

all_keys = set()
for year in range(2017, 2024):
    for month in range(1, 13):
        all_keys.add(f"{year}-{month:02d}")

total_completed = set()
all_complete    = True

for year in range(2017, 2024):
    ckpt = f"{VOL_BASE}/checkpoints/bronze_pv_{year}.json"
    try:
        raw       = dbutils.fs.head(ckpt, 100000)
        completed = set(json.loads(raw))
        done      = len(completed)
        missing   = [f"{year}-{m:02d}" for m in range(1,13)
                     if f"{year}-{m:02d}" not in completed]
        bar       = "█" * done + "░" * (12 - done)
        total_completed |= completed
        status = "COMPLETE" if done == 12 else f"INCOMPLETE — missing: {missing}"
        if done < 12:
            all_complete = False
    except Exception:
        bar, status, done = "░"*12, "NO CHECKPOINT FOUND", 0
        all_complete = False

    print(f"  {year}  [{bar}]  {done}/12  {status}")

# Also check sequential job checkpoint
try:
    raw = dbutils.fs.head(
        f"{VOL_BASE}/checkpoints/bronze_port_visits.json", 100000)
    seq_done = set(json.loads(raw))
    print(f"\n  Sequential job checkpoint : {len(seq_done)}/84 months")
except Exception:
    print(f"\n  Sequential job checkpoint : not found")

print(f"\n  Total unique months across all checkpoints : "
      f"{len(total_completed)}/84")
print(f"\n  {'ALL CHECKPOINTS COMPLETE' if all_complete else 'SOME MONTHS MISSING — see above'}")
print("=" * 60)

# COMMAND ----------

# ── CELL 3: Delta table row count and date coverage ───────────────────────

df = spark.read.format("delta").load(OUTPUT_PATH)
total_rows = df.count()

df_dated = df.withColumn(
    "start_date", to_date(to_timestamp(col("start_ts")))
)

date_range = df_dated.agg(
    spark_min("start_date").alias("earliest"),
    spark_max("start_date").alias("latest")
).collect()[0]

print("=" * 60)
print("  DELTA TABLE OVERVIEW")
print("=" * 60)
print(f"  Total rows      : {total_rows:,}")
print(f"  Earliest event  : {date_range['earliest']}")
print(f"  Latest event    : {date_range['latest']}")
print(f"  Columns         : {len(df.columns)}")

# Expected range
expected_min = 14_000_000
expected_max = 20_000_000
status = "OK" if expected_min <= total_rows <= expected_max else "UNEXPECTED"
print(f"\n  Expected range  : {expected_min:,} – {expected_max:,} rows")
print(f"  Status          : {status}")
print("=" * 60)

# COMMAND ----------

# ── CELL 4: Yearly event counts — detect incomplete years ─────────────────
# Any year with significantly fewer events than others is suspicious.
# Normal range: 2,000,000 – 2,600,000 rows per year.

print("=" * 60)
print("  YEARLY ROW COUNTS")
print("=" * 60)
print(f"  {'Year':<6} {'Rows':>12}  {'Status'}")
print(f"  {'─'*40}")

year_counts = (df_dated
    .withColumn("yr", spark_year("start_date"))
    .groupBy("yr").count()
    .orderBy("yr")
    .collect())

for row in year_counts:
    yr    = row["yr"]
    n     = row["count"]
    flag  = ""
    if n < 1_500_000:
        flag = "  ← LOW — possible incomplete months"
    elif n > 3_000_000:
        flag = "  ← HIGH — check for duplicates"
    print(f"  {yr:<6} {n:>12,}{flag}")

print("=" * 60)

# COMMAND ----------

# ── CELL 5: Monthly counts — find suspiciously low months ─────────────────
# Any month under 50,000 rows was likely truncated by a 422 error.
# These need to be removed from checkpoint and re-ingested.

print("=" * 60)
print("  MONTHLY ROW COUNTS — flagging low months")
print("=" * 60)

monthly = (df_dated
    .withColumn("yr",  spark_year("start_date"))
    .withColumn("mo",  spark_month("start_date"))
    .withColumn("yrmo", col("start_ts").substr(1, 7))
    .groupBy("yr", "mo", "yrmo").count()
    .orderBy("yr", "mo")
    .collect())

low_months = []
print(f"  {'Month':<10} {'Rows':>12}  Status")
print(f"  {'─'*40}")

for row in monthly:
    yrmo = row["yrmo"]
    n    = row["count"]
    if n < 50_000:
        flag = "  ← INCOMPLETE — needs re-ingestion"
        low_months.append(yrmo)
    elif n < 100_000:
        flag = "  ← LOW — verify"
    else:
        flag = ""
    print(f"  {yrmo:<10} {n:>12,}{flag}")

print(f"\n  Total months found in data : {len(monthly)}")
if low_months:
    print(f"\n  INCOMPLETE MONTHS DETECTED : {low_months}")
    print("  Run the checkpoint cleanup cell and re-ingest these months.")
else:
    print("\n  No incomplete months detected.")
print("=" * 60)

# COMMAND ----------

# ── CELL 6: Duplicate check ───────────────────────────────────────────────
# event_id must be unique. Any duplicates = MERGE logic has a bug.

total      = df.count()
distinct   = df.select("event_id").distinct().count()
duplicates = total - distinct

print("=" * 60)
print("  DUPLICATE CHECK")
print("=" * 60)
print(f"  Total rows        : {total:,}")
print(f"  Distinct event_id : {distinct:,}")
print(f"  Duplicates        : {duplicates:,}")

if duplicates == 0:
    print("  Status            : CLEAN — no duplicates")
elif duplicates < 10000:
    print("  Status            : MINOR — run dedup cell below")
else:
    print("  Status            : SIGNIFICANT — investigate before Silver")
print("=" * 60)

# COMMAND ----------

# ── CELL 7: Null rates on critical columns ────────────────────────────────

print("=" * 60)
print("  NULL RATE CHECK")
print("=" * 60)
print(f"  {'Column':<26} {'Nulls':>10} {'%':>7}  Threshold  Status")
print(f"  {'─'*65}")

checks = {
    "event_id":           0,
    "vessel_id":          5,
    "mmsi":               10,
    "start_ts":           1,
    "end_ts":             5,
    "start_port_name":    20,
    "lat":                15,
    "lon":                15,
    "duration_hrs":       40,
    "confidence":         5,
}

from pyspark.sql.types import StringType
for c, warn_pct in checks.items():
    dtype = df.schema[c].dataType
    if isinstance(dtype, StringType):
        n = df.filter(isnull(col(c)) | (col(c) == "")).count()
    else:
        n = df.filter(isnull(col(c))).count()
    pct    = builtins.round(n / total * 100, 1)
    status = "WARN" if pct > warn_pct else "OK"
    print(f"  {c:<26} {n:>10,} {pct:>6.1f}%  <{warn_pct}%      {status}")

print("=" * 60)

# COMMAND ----------

# ── CELL 8: Key loading terminal presence check ───────────────────────────
# These ports must appear in the data for the Silver joins to work.
# If any are missing or have very low counts, update oil_terminals.csv.

KEY_PORTS = [
    "Ras Tanura", "KHARK", "Basra", "Fujairah",
    "Jeddah", "Sidi Kerir",
    "Bonny", "Forcados", "Escravos",
    "Novorossiysk", "Primorsk",
    "Sullom", "Rotterdam", "Houston",
    "Corpus Christi",
]

ports_pd = (df
    .select("start_port_name", "start_port_country")
    .distinct()
    .toPandas())

print("=" * 60)
print("  KEY LOADING TERMINAL CHECK")
print("=" * 60)
print(f"  Total distinct ports in data: {len(ports_pd):,}\n")
print(f"  {'Search term':<22} Result")
print(f"  {'─'*55}")

missing_ports = []
for term in KEY_PORTS:
    matches = ports_pd[
        ports_pd["start_port_name"].str.contains(term, case=False, na=False)
    ]
    if len(matches) == 0:
        print(f"  {term:<22} NOT FOUND ← update oil_terminals.csv")
        missing_ports.append(term)
    else:
        names = ", ".join(
            f"{r['start_port_name']} ({r['start_port_country']})"
            for _, r in matches.head(2).iterrows()
        )
        print(f"  {term:<22} {names}")

if missing_ports:
    print(f"\n  {len(missing_ports)} terminals not found — "
          f"check full port list below")
else:
    print(f"\n  All key terminals confirmed in data.")
print("=" * 60)

# COMMAND ----------

# ── CELL 9: Confidence distribution ──────────────────────────────────────
# Confidence 4 events are what Silver will filter to.
# Confirm there are enough confidence-4 events to build features from.

print("=" * 60)
print("  CONFIDENCE DISTRIBUTION")
print("=" * 60)

conf_counts = (df
    .groupBy("confidence").count()
    .orderBy("confidence")
    .collect())

conf4_count = 0
for row in conf_counts:
    pct = builtins.round(row["count"] / total * 100, 1)
    print(f"  Confidence {row['confidence']} : {row['count']:>12,}  ({pct}%)")
    if row["confidence"] == 4:
        conf4_count = row["count"]

conf4_pct = builtins.round(conf4_count / total * 100, 1)
print(f"\n  Confidence-4 rows : {conf4_count:,} ({conf4_pct}%)")
status = "OK" if conf4_pct > 15 else "LOW — Silver may have sparse features"
print(f"  Status            : {status}")
print("=" * 60)

# COMMAND ----------

# ── CELL 10: Duration statistics ──────────────────────────────────────────
# Average port stay duration in hours. A realistic tanker port stay
# at a loading terminal is 24-96 hours. Extreme values indicate
# parsing errors (duration in seconds rather than hours).

print("=" * 60)
print("  DURATION STATISTICS (confidence=4 events)")
print("=" * 60)

(df
    .filter((col("confidence") == 4) & col("duration_hrs").isNotNull())
    .agg(
        spark_round(avg("duration_hrs"),                    2).alias("avg_hrs"),
        percentile_approx("duration_hrs", 0.05).alias("p5_hrs"),
        percentile_approx("duration_hrs", 0.25).alias("p25_hrs"),
        percentile_approx("duration_hrs", 0.50).alias("p50_hrs"),
        percentile_approx("duration_hrs", 0.75).alias("p75_hrs"),
        percentile_approx("duration_hrs", 0.95).alias("p95_hrs"),
        percentile_approx("duration_hrs", 0.99).alias("p99_hrs"),
    )
    .show(truncate=False))

print("  Expected: avg ~40-80hrs, p50 ~24-48hrs, p99 < 1000hrs")
print("  If p99 > 8760 (1 year in hours) — duration parsing bug exists")
print("=" * 60)

# COMMAND ----------

# ── CELL 11: Vessel type breakdown ────────────────────────────────────────

print("=" * 60)
print("  VESSEL TYPE BREAKDOWN")
print("=" * 60)
(df.groupBy("vessel_type").count()
    .orderBy("count", ascending=False)
    .show(15, truncate=False))
print("  Expected: BUNKER and CARGO dominate (these are your tanker types)")
print("=" * 60)

# COMMAND ----------

# ── CELL 12: Top 30 ports by event count ──────────────────────────────────

print("=" * 60)
print("  TOP 30 PORTS")
print("=" * 60)
(df.groupBy("start_port_name", "start_port_country")
    .count()
    .orderBy("count", ascending=False)
    .show(30, truncate=False))
print("  Expected: Fujairah, Rotterdam, Singapore, Houston, Ras Tanura")
print("  in top positions. Empty port names are anchorage-only events.")
print("=" * 60)

# COMMAND ----------

# ── CELL 13: 5 sample rows — visual sanity check ──────────────────────────

print("Sample rows — verify fields look realistic:\n")
(df.filter((col("confidence") == 4) & (col("start_port_name") != ""))
    .select("mmsi", "flag", "vessel_type", "start_ts", "end_ts",
            "start_port_name", "start_port_country",
            "duration_hrs", "confidence")
    .orderBy("start_ts")
    .limit(5)
    .show(truncate=False))

# COMMAND ----------

# ── CELL 14: Final validation summary ────────────────────────────────────

print("=" * 60)
print("  FINAL VALIDATION SUMMARY")
print("=" * 60)

checks_passed = 0
checks_total  = 6
issues        = []

# Check 1: row count
if 14_000_000 <= total_rows <= 20_000_000:
    print(f"  [PASS] Row count: {total_rows:,}")
    checks_passed += 1
else:
    print(f"  [FAIL] Row count {total_rows:,} outside expected range")
    issues.append("Row count outside expected range")

# Check 2: date range
if str(date_range["earliest"]) <= "2017-02-01" and \
   str(date_range["latest"])   >= "2023-11-01":
    print(f"  [PASS] Date range: {date_range['earliest']} → "
          f"{date_range['latest']}")
    checks_passed += 1
else:
    print(f"  [FAIL] Date range incomplete: "
          f"{date_range['earliest']} → {date_range['latest']}")
    issues.append("Date range incomplete")

# Check 3: duplicates
if duplicates == 0:
    print(f"  [PASS] No duplicates")
    checks_passed += 1
else:
    print(f"  [FAIL] {duplicates:,} duplicate event_ids")
    issues.append(f"{duplicates:,} duplicates")

# Check 4: low months
if not low_months:
    print(f"  [PASS] No incomplete months")
    checks_passed += 1
else:
    print(f"  [FAIL] Incomplete months: {low_months}")
    issues.append(f"Incomplete months: {low_months}")

# Check 5: key terminals
if not missing_ports:
    print(f"  [PASS] All key loading terminals present")
    checks_passed += 1
else:
    print(f"  [FAIL] Missing terminals: {missing_ports}")
    issues.append(f"Missing terminals: {missing_ports}")

# Check 6: confidence-4 coverage
if conf4_pct > 15:
    print(f"  [PASS] Confidence-4 events: {conf4_pct}%")
    checks_passed += 1
else:
    print(f"  [FAIL] Confidence-4 events only {conf4_pct}% — too low")
    issues.append("Low confidence-4 coverage")

print(f"\n  {checks_passed}/{checks_total} checks passed")

if checks_passed == checks_total:
    print("\n  ALL CHECKS PASSED")
    print("  Bronze GFW port visits table is ready for Phase 2 (Silver).")
else:
    print(f"\n  {checks_total - checks_passed} ISSUES TO FIX:")
    for issue in issues:
        print(f"    - {issue}")
    print("\n  Fix issues before proceeding to Silver layer.")

print("=" * 60)

# COMMAND ----------

# Find Kharg Island exact spelling in GFW data
df = spark.read.format("delta").load(OUTPUT_PATH)

kharg_matches = (df
    .filter(
        col("start_port_name").contains("Kharg") |
        col("start_port_name").contains("kharg") |
        col("start_port_name").contains("Karg") |
        col("start_port_name").contains("Island") &
            col("start_port_country").contains("IR")
    )
    .select("start_port_name", "start_port_country")
    .distinct()
    .orderBy("start_port_name")
)

print("Kharg-related matches:")
kharg_matches.show(20, truncate=False)

# Also search all Iranian ports
print("\nAll Iranian ports (country=IR or IRN):")
(df
    .filter(
        col("start_port_country").isin("IR", "IRN", "Iran")
    )
    .select("start_port_name", "start_port_country")
    .groupBy("start_port_name", "start_port_country")
    .count()
    .orderBy("count", ascending=False)
    .show(20, truncate=False))

# COMMAND ----------

