# Databricks notebook source
# ── CELL 1: Credentials ───────────────────────────────────────────────────

GFW_TOKEN = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImtpZEtleSJ9.eyJkYXRhIjp7Im5hbWUiOiJBY2FkZW1pYyBSZXNlYXJjaCIsInVzZXJJZCI6NTg2MTUsImFwcGxpY2F0aW9uTmFtZSI6IkFjYWRlbWljIFJlc2VhcmNoIiwiaWQiOjUzMTksInR5cGUiOiJ1c2VyLWFwcGxpY2F0aW9uIn0sImlhdCI6MTc3NDk1NTEyNCwiZXhwIjoyMDkwMzE1MTI0LCJhdWQiOiJnZnciLCJpc3MiOiJnZncifQ.XsEQ6JGnll6VkPZi94EczSMI4ygq3KV_Kx3Vtl10UNhRpnIMOmOE3uv0ea3QWgRyx2GxQOKOXChZhDP_kdOvQErzVWP5mVAQoQjrqPMSKsaKaFzChPiC6BulB-ikC_KdjYH8O1eX3nV4Fz7q67E-QeHMc4grkj00wrK-EAwwmHmpKzgNjhufBZ6Q0GZcj1yYopMK6rD1VOQLuKEDKRG_Dixh1-hb2nZqjg-i2Ry-Hcb3Z_VODhpAP2Jja69utX30ELAB-eiG4wRzEdis8lE3o4l5oljBitjSjwsfbfJ857_wYB3ZUh5zUPd-2CtAJjGn6X22_qTzjjMGv9fKabplhpQYi-QyzOwt8B-Flgx0xflTjpYwGmHvbFOWHrsEmgH-jdjx5FDIpZ3a18Pt3y7zoClK3S0eJLcLaD6DE95kmoAvP_n7vgXDHNdTJn92kgQvR4V3wrVz4Snx7Bf73LquFA77g7fUc81DUg5AyT20vUwnhwirxJ3iXh-QUvGjR3FI"
assert len(GFW_TOKEN) > 20
print(f"Token: {GFW_TOKEN[:8]}...{GFW_TOKEN[-4:]}")

# COMMAND ----------

# ── CELL 2: Imports and paths ─────────────────────────────────────────────

import requests, time, json, pandas as pd, calendar, builtins
from datetime import datetime
from requests.exceptions import ChunkedEncodingError
from pyspark.sql import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql.window import Window
from delta.tables import DeltaTable

spark = SparkSession.builder.getOrCreate()

CATALOG  = "workspace"
SCHEMA   = "oil_intel"
VOLUME   = "project_data"
VOL_BASE = f"/Volumes/{CATALOG}/{SCHEMA}/{VOLUME}"

BASE_URL     = "https://gateway.api.globalfishingwatch.org/v3"
HEADERS      = {"Authorization": f"Bearer {GFW_TOKEN}",
                "Content-Type":  "application/json"}
DATASET      = "public-global-loitering-events:latest"   # ← different
VESSEL_TYPES = ["BUNKER", "CARGO"]

OUTPUT_PATH     = f"{VOL_BASE}/bronze/gfw_loitering"     # ← different
CHECKPOINT_PATH = f"{VOL_BASE}/checkpoints/bronze_loitering.json"  # ← different

START_YEAR = 2017
END_YEAR   = 2023

print(f"Dataset    : {DATASET}")
print(f"Output     : {OUTPUT_PATH}")
print(f"Checkpoint : {CHECKPOINT_PATH}")

# COMMAND ----------

# ── CELL 3: Schema ────────────────────────────────────────────────────────

bronze_schema = StructType([
    StructField("event_id",        StringType(), True),
    StructField("vessel_id",       StringType(), True),
    StructField("mmsi",            StringType(), True),
    StructField("vessel_name",     StringType(), True),
    StructField("vessel_type",     StringType(), True),
    StructField("flag",            StringType(), True),
    StructField("start_ts",        StringType(), True),
    StructField("end_ts",          StringType(), True),
    StructField("lat",             DoubleType(), True),
    StructField("lon",             DoubleType(), True),
    StructField("duration_hrs",    DoubleType(), True),
    StructField("avg_speed_knots", DoubleType(), True),
    StructField("total_dist_km",   DoubleType(), True),
    StructField("loitering_hours", DoubleType(), True),
    StructField("region_eez",      StringType(), True),
    StructField("source",          StringType(), True),
    StructField("ingested_at",     StringType(), True),
])

print(f"Schema: {len(bronze_schema.fields)} columns")

# COMMAND ----------

# ── CELL 4: All functions ─────────────────────────────────────────────────

def load_checkpoint():
    try:
        raw = dbutils.fs.head(CHECKPOINT_PATH, 100000)
        return set(json.loads(raw))
    except Exception:
        return set()

def save_checkpoint(completed_set):
    dbutils.fs.mkdirs(f"{VOL_BASE}/checkpoints/")
    dbutils.fs.put(
        CHECKPOINT_PATH,
        json.dumps(sorted(list(completed_set))),
        overwrite=True
    )

def fetch_events_paginated(dataset, vessel_types, start_date,
                            end_date, batch_size=200, max_retries=5):
    all_events, offset, page = [], 0, 0
    while True:
        params = {
            "datasets[0]": dataset,
            "start-date":  start_date,
            "end-date":    end_date,
            "limit":       batch_size,
            "offset":      offset,
        }
        for i, vt in enumerate(vessel_types):
            params[f"vessel-types[{i}]"] = vt

        response = None
        success  = False
        for attempt in range(max_retries):
            try:
                response = requests.get(
                    f"{BASE_URL}/events", headers=HEADERS,
                    params=params, timeout=45
                )
                if response.status_code == 200:
                    success = True
                    break
                elif response.status_code == 429:
                    wait_s = int(response.headers.get("Retry-After", 60))
                    print(f"    Rate limit. Waiting {wait_s}s...")
                    time.sleep(wait_s)
                elif response.status_code == 422:
                    wait_s = 30 * (attempt + 1)
                    print(f"    422 transient page {page}. "
                          f"Attempt {attempt+1}/{max_retries}. "
                          f"Waiting {wait_s}s...")
                    time.sleep(wait_s)
                elif response.status_code in (500, 502, 503, 504):
                    wait_s = 15 * (attempt + 1)
                    print(f"    Server error {response.status_code}. "
                          f"Attempt {attempt+1}/{max_retries}...")
                    time.sleep(wait_s)
                else:
                    print(f"    Unknown {response.status_code}: "
                          f"{response.text[:100]}")
                    time.sleep(10)
            except requests.exceptions.Timeout:
                time.sleep(20 * (attempt + 1))
                print(f"    Timeout attempt {attempt+1}/{max_retries}...")
            except ChunkedEncodingError:
                wait_s = 30 * (attempt + 1)
                print(f"    ChunkedEncodingError page {page}. "
                      f"Attempt {attempt+1}/{max_retries}. "
                      f"Waiting {wait_s}s...")
                time.sleep(wait_s)
            except requests.exceptions.ConnectionError:
                time.sleep(20 * (attempt + 1))
                print(f"    Connection error attempt {attempt+1}...")

        if not success:
            print(f"    Max retries exceeded page {page}. Stopping.")
            break

        batch = response.json().get("entries", [])
        all_events.extend(batch)
        page += 1
        if page % 10 == 0:
            print(f"    Page {page:>4} | offset {offset:>7} | "
                  f"total fetched: {len(all_events):>8,}")
        if len(batch) < batch_size:
            break
        offset   += batch_size
        time.sleep(1.2)

    return all_events


def parse_loitering(event):
    """
    Parse a GFW loitering event.
    Loitering sub-object contains duration, speed, distance.
    """
    vessel   = event.get("vessel",    {}) or {}
    lo       = event.get("loitering", {}) or {}
    position = event.get("position",  {}) or {}
    regions  = event.get("regions",   {}) or {}

    # Duration — may be in loitering sub-object or top level
    raw_dur = (lo.get("durationHrs") or
               lo.get("duration_hrs") or
               event.get("durationHrs"))
    if raw_dur is not None:
        try:
            raw_dur = float(raw_dur)
            if raw_dur > 8760:
                raw_dur = raw_dur / 3600.0
        except (TypeError, ValueError):
            raw_dur = None

    # Speed
    try:
        avg_speed = float(lo.get("avgSpeed",
                          lo.get("avg_speed", 0)) or 0)
    except (TypeError, ValueError):
        avg_speed = 0.0

    # Distance
    try:
        total_dist = float(lo.get("totalDistanceKm",
                           lo.get("total_distance_km", 0)) or 0)
    except (TypeError, ValueError):
        total_dist = 0.0

    eez_list   = regions.get("eez", [])
    region_eez = str(eez_list[0]) if eez_list else ""

    return {
        "event_id":        str(event.get("id", "")),
        "vessel_id":       str(vessel.get("id", "")),
        "mmsi":            str(vessel.get("ssvid", "")),
        "vessel_name":     str(vessel.get("name", "")),
        "vessel_type":     str(vessel.get("type", "")),
        "flag":            str(vessel.get("flag", "")),
        "start_ts":        str(event.get("start", "")),
        "end_ts":          str(event.get("end", "")),
        "lat":             float(position["lat"]) if position.get("lat") else None,
        "lon":             float(position["lon"]) if position.get("lon") else None,
        "duration_hrs":    raw_dur,
        "avg_speed_knots": avg_speed,
        "total_dist_km":   total_dist,
        "loitering_hours": raw_dur,
        "region_eez":      region_eez,
        "source":          "GFW_EVENTS_V3",
        "ingested_at":     datetime.utcnow().isoformat(),
    }


def write_month_to_delta(rows, year_month_str, min_expected=500):
    """Lower threshold for loitering — ~3,000-8,000 events/month expected."""
    if not rows:
        return 0, False

    parsed    = [parse_loitering(e) for e in rows]
    df_pd     = pd.DataFrame(parsed).drop_duplicates(subset=["event_id"])
    row_count = len(df_pd)

    if row_count < min_expected:
        print(f"    WARNING: only {row_count:,} rows — "
              f"expected >500. NOT checkpointing.")
        if row_count > 0:
            _write_df(df_pd)
        return row_count, False

    _write_df(df_pd)
    return row_count, True


def _write_df(df_pd):
    float_cols = ["lat", "lon", "duration_hrs",
                  "avg_speed_knots", "total_dist_km", "loitering_hours"]
    for c in float_cols:
        df_pd[c] = pd.to_numeric(df_pd[c], errors="coerce")

    str_cols = ["event_id","vessel_id","mmsi","vessel_name",
                "vessel_type","flag","start_ts","end_ts",
                "region_eez","source","ingested_at"]
    for c in str_cols:
        df_pd[c] = df_pd[c].fillna("").astype(str)

    df_spark = spark.createDataFrame(df_pd, schema=bronze_schema)

    for attempt in range(5):
        try:
            if not DeltaTable.isDeltaTable(spark, OUTPUT_PATH):
                (df_spark.write.format("delta").mode("overwrite")
                    .option("overwriteSchema","true").save(OUTPUT_PATH))
            else:
                (DeltaTable.forPath(spark, OUTPUT_PATH)
                    .alias("existing")
                    .merge(df_spark.alias("incoming"),
                           "existing.event_id = incoming.event_id")
                    .whenMatchedUpdateAll()
                    .whenNotMatchedInsertAll()
                    .execute())
            return
        except Exception as e:
            if "ConcurrentAppendException" in str(e) or \
               "DELTA_CONCURRENT_APPEND" in str(e):
                print(f"    ConcurrentAppend retry {attempt+1}/5...")
                time.sleep(30 * (attempt + 1))
            else:
                raise

print("All functions defined.")

# COMMAND ----------

# ── CELL 5: Month list ────────────────────────────────────────────────────

all_months = []
for year in range(START_YEAR, END_YEAR + 1):
    for month in range(1, 13):
        last_day = calendar.monthrange(year, month)[1]
        all_months.append({
            "key":   f"{year}-{month:02d}",
            "start": f"{year}-{month:02d}-01",
            "end":   f"{year}-{month:02d}-{last_day:02d}",
        })

print(f"Total months: {len(all_months)}")

# COMMAND ----------

# ── CELL 6: Checkpoint status ─────────────────────────────────────────────

completed = load_checkpoint()
remaining = [m for m in all_months if m["key"] not in completed]
print(f"Completed : {len(completed)}/84")
print(f"Remaining : {len(remaining)}/84")
if remaining:
    print(f"Next      : {remaining[0]['key']}")

# COMMAND ----------

# ── CELL 7: Ingestion loop ────────────────────────────────────────────────

completed      = load_checkpoint()
remaining      = [m for m in all_months if m["key"] not in completed]
session_rows   = 0
session_months = 0
skipped        = []

print(f"Loitering ingestion — {len(remaining)} months remaining")
print("─" * 55)

for i, month in enumerate(remaining):
    key, start, end = month["key"], month["start"], month["end"]
    print(f"\n[{i+1:>3}/{len(remaining)}]  {key}  ({start} → {end})")

    t0         = time.time()
    raw_events = fetch_events_paginated(
        DATASET, VESSEL_TYPES, start, end,
        batch_size=200, max_retries=5
    )

    rows_written, is_complete = write_month_to_delta(raw_events, key)
    elapsed = builtins.round(time.time() - t0, 1)

    if is_complete:
        completed.add(key)
        save_checkpoint(completed)
        print(f"    {len(raw_events):>7,} events | "
              f"{rows_written:>7,} written | "
              f"{elapsed:>6.1f}s | checkpoint saved")
    else:
        skipped.append(key)
        print(f"    {len(raw_events):>7,} events | "
              f"{rows_written:>7,} written | "
              f"{elapsed:>6.1f}s | NOT checkpointed")

    session_rows   += rows_written
    session_months += 1
    time.sleep(2)

print(f"\n{'='*55}")
print(f"  SESSION COMPLETE")
print(f"  Months this session  : {session_months}")
print(f"  Rows this session    : {session_rows:,}")
print(f"  Total checkpointed   : {len(completed)}/84")
if skipped:
    print(f"  Skipped (retry next) : {skipped}")
if len(completed) == 84:
    total = spark.read.format("delta").load(OUTPUT_PATH).count()
    print(f"\n  ALL DONE — {total:,} total loitering rows")
else:
    print(f"  {84-len(completed)} months remain — re-run job to continue")
print(f"{'='*55}")