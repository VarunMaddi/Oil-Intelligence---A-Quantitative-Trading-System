# Databricks notebook source
# ── CELL 1: Credentials ───────────────────────────────────────────────────

GFW_TOKEN = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImtpZEtleSJ9.eyJkYXRhIjp7Im5hbWUiOiJBY2FkZW1pYyBSZXNlYXJjaCIsInVzZXJJZCI6NTg2MTUsImFwcGxpY2F0aW9uTmFtZSI6IkFjYWRlbWljIFJlc2VhcmNoIiwiaWQiOjUzMTksInR5cGUiOiJ1c2VyLWFwcGxpY2F0aW9uIn0sImlhdCI6MTc3NDk1NTEyNCwiZXhwIjoyMDkwMzE1MTI0LCJhdWQiOiJnZnciLCJpc3MiOiJnZncifQ.XsEQ6JGnll6VkPZi94EczSMI4ygq3KV_Kx3Vtl10UNhRpnIMOmOE3uv0ea3QWgRyx2GxQOKOXChZhDP_kdOvQErzVWP5mVAQoQjrqPMSKsaKaFzChPiC6BulB-ikC_KdjYH8O1eX3nV4Fz7q67E-QeHMc4grkj00wrK-EAwwmHmpKzgNjhufBZ6Q0GZcj1yYopMK6rD1VOQLuKEDKRG_Dixh1-hb2nZqjg-i2Ry-Hcb3Z_VODhpAP2Jja69utX30ELAB-eiG4wRzEdis8lE3o4l5oljBitjSjwsfbfJ857_wYB3ZUh5zUPd-2CtAJjGn6X22_qTzjjMGv9fKabplhpQYi-QyzOwt8B-Flgx0xflTjpYwGmHvbFOWHrsEmgH-jdjx5FDIpZ3a18Pt3y7zoClK3S0eJLcLaD6DE95kmoAvP_n7vgXDHNdTJn92kgQvR4V3wrVz4Snx7Bf73LquFA77g7fUc81DUg5AyT20vUwnhwirxJ3iXh-QUvGjR3FI"
assert len(GFW_TOKEN) > 20
print(f"Token: {GFW_TOKEN[:8]}...{GFW_TOKEN[-4:]}")

# COMMAND ----------

# ── CELL 2: Imports and paths ─────────────────────────────────────────────

import requests, time, json, pandas as pd, builtins
from datetime import datetime
from requests.exceptions import ChunkedEncodingError
from pyspark.sql import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import *
from delta.tables import DeltaTable

spark = SparkSession.builder.getOrCreate()

VOL_BASE    = "/Volumes/workspace/oil_intel/project_data"
OUTPUT_PATH = f"{VOL_BASE}/bronze/gfw_port_visits"
BASE_URL    = "https://gateway.api.globalfishingwatch.org/v3"
HEADERS     = {"Authorization": f"Bearer {GFW_TOKEN}",
               "Content-Type":  "application/json"}
DATASET      = "public-global-port-visits-c2-events:latest"
VESSEL_TYPES = ["BUNKER", "CARGO"]

# Only these 2 months
TARGET_MONTHS = [
    {"key": "2017-08", "start": "2017-08-01", "end": "2017-08-31"},
    {"key": "2017-09", "start": "2017-09-01", "end": "2017-09-30"},
]

print("Target months:")
for m in TARGET_MONTHS:
    print(f"  {m['key']}  ({m['start']} → {m['end']})")

# COMMAND ----------

# ── CELL 3: Schema ────────────────────────────────────────────────────────

bronze_schema = StructType([
    StructField("event_id",           StringType(),  True),
    StructField("vessel_id",          StringType(),  True),
    StructField("mmsi",               StringType(),  True),
    StructField("vessel_name",        StringType(),  True),
    StructField("vessel_type",        StringType(),  True),
    StructField("flag",               StringType(),  True),
    StructField("next_port",          StringType(),  True),
    StructField("start_ts",           StringType(),  True),
    StructField("end_ts",             StringType(),  True),
    StructField("lat",                DoubleType(),  True),
    StructField("lon",                DoubleType(),  True),
    StructField("start_port_name",    StringType(),  True),
    StructField("start_port_country", StringType(),  True),
    StructField("start_port_lat",     DoubleType(),  True),
    StructField("start_port_lon",     DoubleType(),  True),
    StructField("end_port_name",      StringType(),  True),
    StructField("end_port_country",   StringType(),  True),
    StructField("end_port_lat",       DoubleType(),  True),
    StructField("end_port_lon",       DoubleType(),  True),
    StructField("duration_hrs",       DoubleType(),  True),
    StructField("confidence",         IntegerType(), True),
    StructField("visit_id",           StringType(),  True),
    StructField("region_eez",         StringType(),  True),
    StructField("source",             StringType(),  True),
    StructField("ingested_at",        StringType(),  True),
])
print("Schema defined.")

# COMMAND ----------

# ── CELL 4: Functions ─────────────────────────────────────────────────────

def fetch_events_paginated(dataset, vessel_types, start_date,
                            end_date, batch_size=200, max_retries=5):
    all_events, offset, page = [], 0, 0
    while True:
        params = {
            "datasets[0]": dataset,
            "start-date":  start_date,
            "end-date":    end_date,
            "limit":       batch_size,
            "offset":      offset,
        }
        for i, vt in enumerate(vessel_types):
            params[f"vessel-types[{i}]"] = vt

        response = None
        success  = False
        for attempt in range(max_retries):
            try:
                response = requests.get(
                    f"{BASE_URL}/events", headers=HEADERS,
                    params=params, timeout=45
                )
                if response.status_code == 200:
                    success = True
                    break
                elif response.status_code == 429:
                    wait_s = int(response.headers.get("Retry-After", 60))
                    print(f"    Rate limit. Waiting {wait_s}s...")
                    time.sleep(wait_s)
                elif response.status_code == 422:
                    wait_s = 30 * (attempt + 1)
                    print(f"    422 transient page {page}. "
                          f"Attempt {attempt+1}/{max_retries}. "
                          f"Waiting {wait_s}s...")
                    time.sleep(wait_s)
                elif response.status_code in (500, 502, 503, 504):
                    wait_s = 15 * (attempt + 1)
                    print(f"    Server error {response.status_code}. "
                          f"Attempt {attempt+1}/{max_retries}...")
                    time.sleep(wait_s)
                else:
                    print(f"    Unknown {response.status_code}: "
                          f"{response.text[:100]}")
                    time.sleep(10)
            except requests.exceptions.Timeout:
                print(f"    Timeout attempt {attempt+1}/{max_retries}...")
                time.sleep(20 * (attempt + 1))
            except ChunkedEncodingError:
                print(f"    ChunkedEncodingError page {page}. "
                      f"Attempt {attempt+1}/{max_retries}. "
                      f"Waiting {30*(attempt+1)}s...")
                time.sleep(30 * (attempt + 1))
            except requests.exceptions.ConnectionError:
                print(f"    Connection error attempt {attempt+1}...")
                time.sleep(20 * (attempt + 1))

        if not success:
            print(f"    Max retries exceeded page {page}. Stopping.")
            break

        batch = response.json().get("entries", [])
        all_events.extend(batch)
        page += 1
        if page % 10 == 0:
            print(f"    Page {page:>4} | offset {offset:>7} | "
                  f"total fetched: {len(all_events):>8,}")
        if len(batch) < batch_size:
            break
        offset   += batch_size
        time.sleep(1.2)

    return all_events


def parse_port_visit(event):
    vessel    = event.get("vessel",     {})
    pv        = event.get("port_visit", {})
    start_anc = pv.get("startAnchorage", {}) or {}
    end_anc   = pv.get("endAnchorage",   {}) or {}
    position  = event.get("position",    {}) or {}
    regions   = event.get("regions",     {}) or {}

    raw_dur = pv.get("durationHrs")
    if raw_dur is not None:
        try:
            raw_dur = float(raw_dur)
            if raw_dur > 8760:
                raw_dur = raw_dur / 3600.0
        except (TypeError, ValueError):
            raw_dur = None

    try:
        confidence = int(pv.get("confidence", 0) or 0)
    except (TypeError, ValueError):
        confidence = 0

    eez_list   = regions.get("eez", [])
    region_eez = str(eez_list[0]) if eez_list else ""

    return {
        "event_id":           str(event.get("id", "")),
        "vessel_id":          str(vessel.get("id", "")),
        "mmsi":               str(vessel.get("ssvid", "")),
        "vessel_name":        str(vessel.get("name", "")),
        "vessel_type":        str(vessel.get("type", "")),
        "flag":               str(vessel.get("flag", "")),
        "next_port":          str(vessel.get("nextPort", "") or ""),
        "start_ts":           str(event.get("start", "")),
        "end_ts":             str(event.get("end", "")),
        "lat":                float(position["lat"]) if position.get("lat") else None,
        "lon":                float(position["lon"]) if position.get("lon") else None,
        "start_port_name":    str(start_anc.get("name", "") or ""),
        "start_port_country": str(start_anc.get("flag", "") or ""),
        "start_port_lat":     float(start_anc["lat"]) if start_anc.get("lat") else None,
        "start_port_lon":     float(start_anc["lon"]) if start_anc.get("lon") else None,
        "end_port_name":      str(end_anc.get("name", "") or ""),
        "end_port_country":   str(end_anc.get("flag", "") or ""),
        "end_port_lat":       float(end_anc["lat"]) if end_anc.get("lat") else None,
        "end_port_lon":       float(end_anc["lon"]) if end_anc.get("lon") else None,
        "duration_hrs":       raw_dur,
        "confidence":         confidence,
        "visit_id":           str(pv.get("visitId", "") or ""),
        "region_eez":         region_eez,
        "source":             "GFW_EVENTS_V3",
        "ingested_at":        datetime.utcnow().isoformat(),
    }


def merge_to_delta(df_pd):
    float_cols = ["lat", "lon", "duration_hrs",
                  "start_port_lat", "start_port_lon",
                  "end_port_lat",   "end_port_lon"]
    for c in float_cols:
        df_pd[c] = pd.to_numeric(df_pd[c], errors="coerce")
    df_pd["confidence"] = (
        pd.to_numeric(df_pd["confidence"], errors="coerce")
          .fillna(0).astype(int))
    str_cols = ["event_id","vessel_id","mmsi","vessel_name","vessel_type",
                "flag","next_port","start_ts","end_ts","start_port_name",
                "start_port_country","end_port_name","end_port_country",
                "visit_id","region_eez","source","ingested_at"]
    for c in str_cols:
        df_pd[c] = df_pd[c].fillna("").astype(str)

    df_spark = spark.createDataFrame(df_pd, schema=bronze_schema)

    for attempt in range(5):
        try:
            (DeltaTable.forPath(spark, OUTPUT_PATH)
                .alias("existing")
                .merge(df_spark.alias("incoming"),
                       "existing.event_id = incoming.event_id")
                .whenMatchedUpdateAll()
                .whenNotMatchedInsertAll()
                .execute())
            return
        except Exception as e:
            if "ConcurrentAppendException" in str(e) or \
               "DELTA_CONCURRENT_APPEND" in str(e):
                print(f"    ConcurrentAppend attempt {attempt+1}/5. "
                      f"Waiting {30*(attempt+1)}s...")
                time.sleep(30 * (attempt + 1))
            else:
                raise

print("All functions defined.")

# COMMAND ----------

# ── CELL 5: Re-ingest 2017-08 and 2017-09 ────────────────────────────────

MIN_EXPECTED = 50_000

for month in TARGET_MONTHS:
    key, start, end = month["key"], month["start"], month["end"]
    print(f"\n{'='*55}")
    print(f"  Re-ingesting {key}  ({start} → {end})")
    print(f"{'='*55}")

    t0 = time.time()

    raw_events = fetch_events_paginated(
        DATASET, VESSEL_TYPES, start, end,
        batch_size=200, max_retries=5
    )

    print(f"\n  Fetched  : {len(raw_events):,} events")

    if len(raw_events) < MIN_EXPECTED:
        print(f"  WARNING  : still below {MIN_EXPECTED:,} threshold")
        print(f"  Writing partial data but NOT marking complete")
        print(f"  Try re-running this cell again later")

    parsed = [parse_port_visit(e) for e in raw_events]
    df_pd  = pd.DataFrame(parsed).drop_duplicates(subset=["event_id"])

    print(f"  Parsed   : {len(df_pd):,} unique rows")
    print(f"  Merging into Delta...")

    merge_to_delta(df_pd)

    elapsed = builtins.round(time.time() - t0, 1)
    print(f"  Done     : {elapsed}s")

    # Verify rows now in Delta for this month
    verify_count = (spark.read.format("delta").load(OUTPUT_PATH)
        .filter(col("start_ts").startswith(key))
        .count())
    print(f"  Verified : {verify_count:,} rows in Delta for {key}")

    if verify_count >= MIN_EXPECTED:
        print(f"  Status   : COMPLETE")
    else:
        print(f"  Status   : STILL INCOMPLETE — re-run cell")

    time.sleep(5)

print(f"\n{'='*55}")
print("Re-ingestion complete. Run Cell 6 to verify final counts.")
print(f"{'='*55}")

# COMMAND ----------

# ── CELL 6: Final verification of the two months ─────────────────────────

print("Final row counts for re-ingested months:\n")

total = spark.read.format("delta").load(OUTPUT_PATH).count()

for month in TARGET_MONTHS:
    key = month["key"]
    n = (spark.read.format("delta").load(OUTPUT_PATH)
         .filter(col("start_ts").startswith(key))
         .count())
    status = "COMPLETE" if n >= 50_000 else "STILL INCOMPLETE"
    print(f"  {key} : {n:>10,} rows  [{status}]")

print(f"\n  Total rows in Delta : {total:,}")
print()
print("If both months show COMPLETE, run the full validation notebook")
print("(Cell 14) — should now show 6/6 passes.")